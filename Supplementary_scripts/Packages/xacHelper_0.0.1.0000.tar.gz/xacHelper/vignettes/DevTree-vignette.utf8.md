% \VignetteIndexEntry{Monocle: Differential expression and time-series analysis for single-cell RNA-Seq and qPCR experiments.} 
% \VignetteEngine{knitr::knitr}
% \VignetteDepends{} 
% \VignettePackage{monocle}
\documentclass[10pt,oneside]{article}

\newcommand{\thetitle}{Differential analysis of transcript counts in single cells}

%\usepackage[pdftitle={\thetitle},pdfauthor={Wolfgang Huber}]{whbiocvignette}
\usepackage{whbiocvignette}
% \usepackage{times}
%\usepackage{hyperref}
%\usepackage{verbatim}
%\usepackage{graphicx}
%\usepackage{fancybox}
%\usepackage{color}

\title{\textsf{\textbf{\thetitle}}}
\author{Xiaojie Qiu\\[1em]University of Washington,\\ Seattle, Washington, USA\\
\texttt{xqiu@uw.edu} 
\and
\author{Cole Trapnell\\[1em]University of Washington,\\ Seattle, Washington, USA\\
\texttt{coletrap@uw.edu} }

\begin{document}

<<include=FALSE, eval=TRUE>>=
library(Biobase)
library(knitr)
library(reshape2)
library(ggplot2)
library(lmtest)
library(MASS)
library(DESeq)
library(reshape2)
library(DESeq2)
library(fitdistrplus)
library(VGAM)
library(pscl)
library(zoo) #calcualting the AUC
library(VennDiagram)
library(monocle)
library(stringr)
library(limma)
library(reshape2)
library(plyr)
library(modeest)
library(MASS)
library(mixsmsn)
library(doMC)
library(data.table)
library(boot)
library(testthat)
require(pheatmap)
# require(heatmap.2)
library(gplots)
library(RColorBrewer)
library(piano)
library(ggdendro)
nm_theme <- function() {
  theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
    theme(panel.border = element_blank(), axis.line = element_line()) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + 
    theme(panel.background = element_rect(fill='white')) + 
    #theme(text = element_text(size=6)) + 
  theme(axis.text.y=element_text(size=6)) + 
  theme(axis.text.x=element_text(size=6)) +
	theme(axis.title.y=element_text(size=6)) + 
	theme(axis.title.x=element_text(size=6)) +
	theme(panel.border = element_blank(), axis.line = element_line(size = .1), axis.ticks = element_line(size = .1)) +
	theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
	theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) +
	theme(legend.position = "none") +
	theme(strip.text.x = element_text(colour="black", size=6)) + 
	theme(strip.text.y = element_text(colour="black", size=6)) + 
	theme(legend.title = element_text(colour="black", size = 6)) + 
	theme(legend.text = element_text(colour="black", size = 6)) + 
	theme(plot.margin=unit(c(0,0,0,0), "lines")) 
}
@ %def

\maketitle

\begin{abstract}
This vigenetee is an accompanying file for the paper "Differential analysis of transcript counts in single cells". All figures in the paper can be generated through this vigenettee. For more details about those figures, especially the methodologies behind them, please refer to the paper \cite{xiaojie_cole}
\end{abstract}

\tableofcontents

<<init_monocle, include=FALSE, cache=TRUE, eval=TRUE>>=
#load all data from the package

data_list <- str_split_fixed(dir('./data'), "\\.rd", 2)[,1]
data(list = data_list)

@ %def 

\section{Introduction}
In order to ensure the reproducibility of our work, we provide detailed R code to give all the figures presented in the paper based on the R package. For the purpose of time, we load the pre-computated objects but we also provides the code that can be used to generate the same data.

\section{Main figures}

We provide the code first for making the figure presented in the main text.

\subsection{Figure 1: Differential analysis of mRNAs levels in single cells.}

<<generate_fig1a, eval=T>>=
#not run
transcript_num <- 38919
test <- exprs(absolute_cds)[1:38919, ] #filter out the spike-in trnascripts
mode <-apply(test, 2, function(x) mlv(round(x)[round(x) > .1], method = "mfv")$M) #calculate the mode of transcript counts
ggplot(data = data.frame(mode = mode), aes(x = mode)) + geom_bar(fill = I('red'), size = .5) + geom_vline(x = 1, linetype = 'longdash', color = I('blue'), size = .2) + 
    xlab('Mode of transcript counts') + ylab('Cell number') + scale_x_continuous(breaks = 1:10) #make figure 1.a
@ %def

<<generate_fig1b, eval=TRUE>>=
quake_all_modes <- estimate_t(exprs(isoform_count_cds), return_all = T) 

three_cell_iso_df <- data.frame(Cell_id = rep(row.names(quake_all_modes)[c(1, 9, 14)], each = nrow(isoform_count_cds)), 
                log10_FPKM = log10(c(exprs(isoform_count_cds)[, 1], exprs(isoform_count_cds)[, 9], exprs(isoform_count_cds)[, 14])), 
                Cell_mode = rep(log10(quake_all_modes[c(1, 9, 14), 1]), each = nrow(isoform_count_cds)))

qplot(x = log10_FPKM, geom = 'histogram', data = three_cell_iso_df[, ], binwidth = .05, color = I('red'))  +
  geom_vline(aes(xintercept=log10(Cell_mode)), color = 'blue') + facet_wrap(~Cell_id) + xlim(-3, 5) + monocle_theme_opts() + xlab('log10 FPKM') + ylab('Isoform counts') + nm_theme()

@ %def

<<generate_fig1c, eval=TRUE>>=
#generate molModels
molModels <- esApply(ercc_controls, 2, function(cell_exprs, input.ERCC.annotation) {
  
  #print (cell_exprs)
	spike_df <- input.ERCC.annotation 
	spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
	colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
	spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23))
	spike_df$rounded_numMolecules <- round(spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23)))
	# print (mean(spike_df$rounded_numMolecules))
	
	spike_df <- subset(spike_df, FPKM >= 1e-10)
	spike_df$log_fpkm <- log10(spike_df$FPKM)
	spike_df$log_numMolecules <- log10(spike_df$numMolecules)
	
	print (paste("geometric mean of log numMol ", mean(spike_df$log_numMolecules), "geometric mean of log FPKM ", mean(spike_df$log_fpkm)))

	molModel <- tryCatch({
		#molModel <- vgam (rounded_numMolecules ~ sm.ns(log_fpkm, df=3), data=spike_df, family=negbinomial(zero=NULL))
		molModel <- rlm(log_numMolecules ~ log_fpkm, data=spike_df)
		
			#
			# 		    qp <- qplot(FPKM, numMolecules, data=spike_df, log="xy") +
			# 			geom_abline(color="green") +
			# geom_smooth(aes(y=10^log_numMolecules), method="lm") +
			# geom_smooth(aes(y=10^log_numMolecules), method="rlm", color="red") +
			# geom_line(aes(y=10^predict(molModel,type="response")))
			# print(qp)
			molModel
		}, 
		error = function(e) { print(e); NULL })
	molModel
}, input.ERCC.annotation)

#transcript counts corresponding to the mode of FPKM values
test <- mapply(function(cell_dmode, model) {
    predict(model, newdata = data.frame(log_fpkm = log10(cell_dmode)), type = 'response')
}, as.list(estimate_t(exprs(isoform_count_cds)[1:119469, ])), molModels)

df <- pData(absolute_cds)
df$mode_transcript <- 10^test
df$estimate_mode <- estimate_t(exprs(isoform_count_cds))

#make figure 1b
qplot(ceiling(mode_transcript), fill = I('red'), data = df) + geom_vline(x = 1, linetype = 'longdash', color = I('blue'), size = .1) + xlab('Transcript counts correspond to \n mode of log10(FPKM) in cells') + ylab('gene number') + nm_theme()
@ %def 

<<generate_fig1d, eval=TRUE>>=
qplot(pData(absolute_cds)$endogenous_RNA[pData(absolute_cds)$endogenous_RNA > 1e3], 
      pData(mc_adj_cds)$endogenous_RNA[pData(absolute_cds)$endogenous_RNA > 1e3], log="xy", color=pData(absolute_cds)$Time[pData(absolute_cds)$endogenous_RNA > 1e3], size = I(1)) + 
     geom_smooth(method="lm", color="black", size = .1) + geom_abline(color="red") +  
    xlab("Total mRNA (spike-in)") +
    ylab("Total mRNA (alogrithm)") + 
    scale_color_discrete(name = "Time points") +  nm_theme()
@ %def

<<generate_fig1e, eval=TRUE>>= 
ggplot(aes(factor(Type), value,  fill = data_type), data = melt(df3.1)) + geom_bar(position = position_dodge(width=0.5), stat = 'identity') + #facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
    ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank())

#make the figure 1e: 
ggplot(aes(Type, value,  fill = data_type), data = melt(df3.1)) + geom_bar(position = 'dodge', stat = 'identity') + #facet_wrap(~variable) +
ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) +
xlab('') + ggtitle('') + nm_theme() + theme(strip.background = element_blank(), strip.text.x = element_blank())

@ %def

\subsection{Figure 2: Differential analysis on branched single cell trajectories is robust and highly accurate.}
<<generate_fig2a, eval=TRUE>>=
plot_spanning_tree(AT12_cds_subset_all_gene, color_by="Time", show_backbone=T, show_cell_names = F) + nm_theme()
@ %def 

<<generate_fig2b, eval=TRUE>>=
example_ids <- row.names(subset(fData(absolute_cds), gene_short_name %in% 
                              c('Sftpc', 'Pdpn', 'Cav1', 'Cd36')))

plot_genes_branched_pseudotime(abs_AT12_cds_subset_all_gene[example_ids ], trend_formula = '~sm.ns(Pseudotime, df = 3)*Lineage', normalize = F, stretch = T, lineage_labels = c('AT1', 'AT2'), cell_size = 2, ncol = 2) + nm_theme() + ylab('Transcript counts')
@ %def 

<<generate_fig2c, eval=TRUE>>=
#generate the data for relative_abs_AT12_cds_subset_quake_gene_df: 

cole_plot_heatmap(AT12_cds_subset_all_gene[row.names(relative_abs_AT12_cds_subset_quake_gene[relative_abs_AT12_cds_subset_quake_gene[, 'qval'] <= 0.1, ]), colnames(AT12_cds_subset_all_gene)], file = 'relative_abs_AT12_cds_subset_quake_gene_df', useVST = T, label_by_short_name = F,  relative = T, cores = detectCores())
load('relative_abs_AT12_cds_subset_quake_gene_df')
hclust_method <- "ward"
dist_method <- "correlation"
cole_make_heatmap(str_logfc_df, dist_method = dist_method, hclust_method = hclust_method, fc_limit = 3)

@ %def 

<<generate_fig2d, eval=TRUE>>=
#number of AT1/AT2 genes based on the ABC score: 
branch_gene_ABCs <- abs_AT12_cds_subset_all_gene_ABCs[row.names(relative_abs_AT12_cds_subset_all_gene[relative_abs_AT12_cds_subset_all_gene[, 'qval'] <= 0.1, ]), ]

AT1_gene_num <- sum(branch_gene_ABCs[, 1] > 0, na.rm = T)
AT2_gene_num <- sum(branch_gene_ABCs[, 1] < 0, na.rm = T)

Lineage_gene_num <- c(AT1_gene_num, AT2_gene_num)
names(Lineage_gene_num) <- c("AT1", "AT2")

qplot(c('AT1', 'AT2'), Lineage_gene_num, stat = 'identity', geom = 'bar', fill = c('29B34A', '6F94CC')) + 
    xlab('Lineages') + ylab('Gene number') +  scale_fill_manual(name = "", values = c("#29B34A", '#6F94CC'), labels = c("AT1", "AT2")) + 
    nm_theme()

@ %def 

<<generate_fig2e, eval=TRUE>>=
ABCs <- abs_AT12_cds_subset_all_gene_ABCs[!is.na(abs_AT12_cds_subset_all_gene_ABCs$ABCs), 1]
names(ABCs) <- fData(absolute_cds[!is.na(abs_AT12_cds_subset_all_gene_ABCs$ABCs), ])$gene_short_name
pval <- abs_AT12_cds_subset_all_gene_res[row.names(absolute_cds[!is.na(abs_AT12_cds_subset_all_gene_ABCs$ABCs), ]), 'pval']
pval[is.na(pval)] <- 1
names(pval) <- names(ABCs)

#size
gsaRes_go <- runGSA(pval, ABCs, gsc = mouse_go_gsc, ncpus = 50) 
save(gsaRes_go, file = 'gsaRes_ABCs')
gasRes <- auto_make_enrichment("gsaRes_ABCs", 15, F, F, F)
#go: cell cycle genes
gasRes[[1]] + nm_theme()

@ %def 

\section{Supplementary figures}

\subsection{Supplementary figure 1: Concordance of four approaches for differential expression analysis in single cell RNA-Seq}
<<supplementary_figure_1a, eval = TRUE>>=
element_all <- c(names(std_permutate_pval[which(std_permutate_pval < .01)]), names(default_deseq_p[default_deseq_p < 0.01]), names(monocle_p[monocle_p < 0.01]), names(scde_p[scde_p < 0.01]))
sets_all <- c(rep(paste('Permutation test', sep = ''), length(which(std_permutate_pval < .01))),
              rep(paste('DESeq', sep = ''), length(default_deseq_p[default_deseq_p < 0.01])), 
              rep(paste('Monocle', sep = ''), length(monocle_p[monocle_p < 0.01])), 
              rep(paste('SCDE', sep = ''), length(scde_p[scde_p < 0.01])))

venneuler_venn(element_all, sets_all)

table(sets_all)
@ %def

<<supplementary_figure_1b, eval = TRUE>>=
element_all <- c(names(new_abs_size_norm_monocle_p_ratio_by_geometric_mean[which(new_abs_size_norm_monocle_p_ratio_by_geometric_mean < .01)]), 
                 names(abs_default_deseq_p[abs_default_deseq_p < 0.01]), 
                 names(abs_scde_p[abs_scde_p < 0.01]), 
                 names(mode_size_norm_permutate_ratio_by_geometric_mean[which(mode_size_norm_permutate_ratio_by_geometric_mean < 0.01)]))

sets_all <- c(rep(paste('Monocle', sep = ''), length(new_abs_size_norm_monocle_p_ratio_by_geometric_mean[new_abs_size_norm_monocle_p_ratio_by_geometric_mean < 0.01])), 
              rep(paste('DESeq', sep = ''), length(abs_default_deseq_p[abs_default_deseq_p < 0.01])), 
              rep(paste('SCDE', sep = ''), length(abs_scde_p[abs_scde_p < 0.01])),
              rep(paste('Permutation test', sep = ''), length(which(mode_size_norm_permutate_ratio_by_geometric_mean < 0.01))))

venneuler_venn(element_all, sets_all)

table(sets_all)
@ %def

\subsection{Supplementary figure 2: Gene expression as measured by read counts and mRNA copies per cell}
<<supplementary_figure_2a, eval = TRUE>>=
cds <- data.frame(transcript = round(as.vector(exprs(absolute_cds)[1:38919, c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0")])), 
  read_counts = as.vector(exprs(quake_read_cds)[1:38919, c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0")]), 
	cell = rep(c("SRR1033854_0", "SRR1033855_0", "SRR1033856_0"), each = 38919)
	)

qplot(value, data = melt(cds), log = 'x') + geom_histogram(aes(fill = variable)) + facet_wrap(~cell+variable, nrow = 3, scale = 'free') + xlab('') + ylab('Gene number') + nm_theme()  +  theme(strip.background = element_blank(),
       strip.text.x = element_blank())
@ %def

<<supplementary_figure_2b, eval = TRUE>>=
#generate the result of goodness of fit for each gene: 
# abs_gd_fit_res <- mcesApply(absolute_cds, 1, gd_fit_pval, cores = detectCores(),
#                  exprs_thrsld = 10, pseudo_cnt = 0.01)
# abs_gd_fit_res <- unlist(abs_gd_fit_res) 
# abs_gd_fit_df <- matrix(abs_gd_fit_res, nrow(absolute_cds), ncol = 11, byrow = T)
# 
# #select only nb and zinb and calculate the number of genes pass goodness of fit and number of genes can be fitted: 
# abs_gd_fit_res <- cal_gd_statistics(abs_gd_fit_df[, c('nb_pvalue', 'zinb_pvalue')], percentage = F, type = 'absolute')
# readcount_gd_fit_res <- cal_gd_statistics(read_gd_fit_df[, c('nb_pvalue', 'zinb_pvalue')], percentage = F,  type = 'readcount')
# gd_fit_res <- rbind(abs_gd_fit_res, readcount_gd_fit_res)
# gd_fit_res <- cbind(gd_fit_res, data_type = row.names(gd_fit_res))
# row.names(gd_fit_res) <- NULL
# gd_fit_res <- as.data.frame(gd_fit_res)
# 
# gd_fit_res_num <- subset(gd_fit_res, data_type == 'gd_fit_num')
# gd_fit_res_success_num <- subset(gd_fit_res, data_type == 'success_fit_num')
# 
# test <- melt(gd_fit_res_num[, 1:3], id.vars = 'type')
# p1 <- qplot(as.factor(variable), as.numeric(value), geom = 'bar', stat = 'identity', data = test, fill = type) + facet_wrap('type') + 
#   theme(legend.position = 'none') + xlab('Fit types') + ylab('number of genes') + nm_theme() + theme(strip.background = element_blank(),
#        strip.text.x = element_blank()) + theme(axis.text.x = element_text(angle = 30, hjust = .9))
# p1 + nm_theme()
# @ %def
# 
# <<supplementary_figure_2c, eval = TRUE>>=
# test <- melt(gd_fit_res_success_num[, 1:3], id.vars = 'type')
# p2 <- qplot(as.factor(variable), as.numeric(value), geom = 'bar', stat = 'identity', data = test, fill = type) + facet_wrap('type') + 
#   theme(legend.position = 'none') + xlab('Fit types') + ylab('number of genes') + nm_theme() + theme(strip.background = element_blank(),
#        strip.text.x = element_blank()) + theme(axis.text.x = element_text(angle = 30, hjust = .9))
# p2 + nm_theme()
@ %def

\subsection{Supplementary figure 3: Dependence of the frequency of mRNA copy numbers on total RNA recovery efficiency (from Cole)} 
<<supplementary_figure_1, eval = TRUE>>=

@ %def

<<supplementary_figure_1, eval = TRUE>>=

@ %def


<<supplementary_figure_1, eval = TRUE>>=

@ %def

\subsection{Supplementary figure 4: Single cell trajectory reconstruction using FPKM and RPC expression values}
<<supplementary_figure_3a, eval = TRUE>>=
#run cole_muscle_ordering: 
plot_spanning_tree(std_HSMM, color_by = "Time", show_backbone = T, show_cell_names = F) + nm_theme()
@ %def

<<supplementary_figure_3b, eval = TRUE>>=
plot_spanning_tree(HSMM_myo, color_by = "Time", show_backbone = T, show_cell_names = F) + nm_theme()
@ %def

<<supplementary_figure_3c, eval = TRUE>>=
plot_tree_pairwise_cor(std_HSMM, HSMM_myo)
@ %def

<<supplementary_figure_3d, eval = TRUE>>=
element_all <- c(row.names(HSMM_myo_size_norm_res[HSMM_myo_size_norm_res$qval <0.1, ]), 
  row.names(std_HSMM_myo_pseudotime_res_ori[std_HSMM_myo_pseudotime_res_ori$qval <0.1, ]))
sets_all <- c(rep(paste('Transcript counts (Size + VST)', sep = ''), nrow(HSMM_myo_size_norm_res[HSMM_myo_size_norm_res$qval <0.1, ])), 
            rep(paste('FPKM', sep = ''), nrow(std_HSMM_myo_pseudotime_res_ori[std_HSMM_myo_pseudotime_res_ori$qval <0.1, ])))
venneuler_venn(element_all, sets_all)
@ %def

<<supplementary_figure_3e, eval = TRUE>>=
#first generate all the data for preparing the data.frame: 

#figure 4d: 
qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = data_type, data = melt(muscle_df)) + #facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
    ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + ylim(0, 1)
 
#only show absolute transcript counts data: 
muscle_df$data_type = c("Transcript (size normalization)", "Transcript (size normalization)", "FPKM", "FPKM")

muscle_df$class = '3relative'
muscle_df.1 <- muscle_df
muscle_df.1 <- muscle_df[1:2, ]
qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = I("red")), data = melt(muscle_df)) + #facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
    ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank())

muscle_df <- muscle_df[1:2, ] #select only the transcript counts data: 
muscle_df[1:2, 'Type'] <- c('Monocle', 'DESeq')

qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = data_type, data = melt(muscle_df)) + #facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('') + ylab('') + facet_wrap(~variable, scales = 'free_x') +  theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
    ggtitle('') + monocle_theme_opts() + theme(strip.text.x = element_blank(), strip.text.y = element_blank()) + theme(strip.background = element_blank()) + ylim(0, 1) + nm_theme() + 
    theme(strip.background = element_blank(), strip.text.x = element_blank())
@ %def

\subsection{Supplementary figure 5: Two measures for quantifying the cell-fate dependent expression between two pseudotemporal lineages}
This is just a demonstration of the metrics we developed for quantifying the gene expression divergence and no code is required. 

\subsection{Supplementary figure 6: Estimated RPC vs spike-in RPC when titrating the amount of spike-in added in the reaction}
<<supplementary_figure_6a, eval = TRUE>>=
qplot(k, b, geom = c('point'), size = I(4), data = kb_df, color = pData(absolute_cds)$Time) + #label = Cell,
    geom_smooth(method = 'rlm', aes(group = 199), size = .1) +nm_theme() + 
    xlab('Slope from FPKM vs. \n ERCC transcript counts') + ylab('Intercept from  FPKM vs. \n ERCC transcript counts')

@ %def

<<supplementary_figure_6b, eval = TRUE>>=
qplot(unlist(lapply(mc_list_list, function(x) x$m)), unlist(lapply(mc_list_list, function(x) x$c)), size = I(1), color = log10(conc_ladder[1:20])) + 
  xlab('m') + ylab('c') + scale_color_continuous(name = 'detection limits concentration', low = 'white', high = 'red') + nm_theme()
@ %def


<<supplementary_figure_6c, eval = TRUE>>=
mlt_transcript_counts_mode_fpkm$conc <- round(mlt_transcript_counts_mode_fpkm$conc, 3)
qplot(ceiling(10^value), fill = I('red'), alpha = I(0.7), geom = c('histogram'), data = subset(mlt_transcript_counts_mode_fpkm, conc %in% c(0.014, 3.662, 234.375, 7500.000 )), size = I(2)) + facet_wrap(~conc, scales = "free_x", ncol = 1)  + geom_vline(x = 1, linetype = 'longdash', color = I('blue')) + nm_theme() + xlab('') + ylab('')

@ %def

<<supplementary_figure_6d, eval = TRUE>>=
mlt_sum_cell_spike_in_all$conc <- round(mlt_sum_cell_spike_in_all$conc, 3)
qplot(spikein, mc, data = subset(mlt_sum_cell_spike_in_all, spikein > 1e03 & conc %in% c(0.014, 3.662, 234.375, 7500.000 )), color = Time, size = I(.4)) + 
  scale_x_log10() + scale_y_log10() + geom_smooth(method = 'rlm', aes(group = 1), size = .2) + geom_abline(slope = 1, size = .2) + 
	facet_wrap(~conc, scale = 'free_x', ncol = 1) + ylab('') + theme(axis.text.x = element_text(angle = 30, hjust = .9)) + 
	xlab('') + nm_theme() # xlab('total mRNA calculated \n from spikein regression') + ylab('total mRNA calculated \n from mc alogrithm')
@ %def

\section{Citation}
If you use this package to analyze your experiments, please cite:
<<citation, eval=TRUE>>=
citation("DevTree")
@ %def 

\section{Acknowledgements}
Xiaojie Qiu would like to thank Yian Ma for helping developing the algorithm for transcript counts recovery.

\section{Session Info}
<<sessi>>=
sessionInfo()
@

\bibliographystyle{unsrt}
\bibliography{dev_tree}

\end{document}
