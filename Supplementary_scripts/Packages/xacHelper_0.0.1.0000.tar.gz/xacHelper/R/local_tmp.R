generate_basic_datasets <- function() {
    #load some meta data from quake paper: 
    load('/Users/xqiu/Dropbox (Personal)/Quake/absolute_transcript/SRR_cell_type')
    load('/Users/xqiu/Dropbox (Personal)/Quake/absolute_transcript/quake_gene_name')
    
    .simpleCap <- function(x) {
      s <- strsplit(x, " ")[[1]]
      paste(toupper(substring(s, 1,1)), substring(s, 2),
            sep="", collapse=" ")
    }
    
    # Load up the Quake paper data as relative expression values (classic FPKM)
    
    sra_table <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/SraRunTable.txt")
    sra_table$Run <- paste(sra_table$Run, "_0", sep="")
    
    fpkm_matrix <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung//standard_normalized_out/genes.fpkm_table", row.names="tracking_id")
    #fpkm_matrix <- fpkm_matrix[,-1]
    sample_sheet <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/standard_normalized_out/samples.table", row.names="sample_id")
    sample_sheet <- merge(sample_sheet, sra_table, by.x="row.names", by.y="Run")
    row.names(sample_sheet) <- sample_sheet$Row.names 
    sample_sheet <- sample_sheet[,-1]
    sample_sheet$Time <- NULL
    sample_sheet$Time[sample_sheet$age == "Embryonic day 14.5"] <- "E14.5"
    sample_sheet$Time[sample_sheet$age == "Embryonic day 16.5"] <- "E16.5"
    sample_sheet$Time[sample_sheet$age == "Embryonic day 18.5"] <- "E18.5"
    sample_sheet$Time[sample_sheet$age == "post natal day 107"] <- "Adult"
    
    #fpkm_matrix <- fpkm_matrix * sample_sheet$internal_scale ############### this is wrong since each matrix row will multiple one value in the vector 
    # fpkm_matrix <- t(t(fpkm_matrix) * sample_sheet$internal_scale)
    gene_ann <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung//standard_normalized_out/genes.attr_table", row.names="tracking_id")
    
    gencode_biotypes <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/gencode_biotypes.txt")
    gencode_biotypes <- gencode_biotypes[,c(1,2)]
    spike_names <- row.names(fpkm_matrix)[grepl("ERCC", row.names(fpkm_matrix))]
    spike_biotypes <- data.frame(gene_id=spike_names, biotype="spike")
    
    gencode_biotypes <- rbind(gencode_biotypes,spike_biotypes)
    
    gene_ann <- merge(gene_ann, gencode_biotypes, by.x="row.names", by.y="gene_id")
    row.names(gene_ann) <- gene_ann$Row.names
    gene_ann <- gene_ann[,c(-1)]
    
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = gene_ann)
    
    fpkm_matrix <- as.matrix(fpkm_matrix)
    fpkm_matrix <- fpkm_matrix[row.names(gene_ann),]
    fpkm_matrix <- fpkm_matrix[,row.names(sample_sheet)]
    
    standard_cds <- newCellDataSet(fpkm_matrix, 
                                   expressionFamily=tobit(), 
                                   phenoData = pd, 
                                   featureData = fd,
                                   lowerDetectionLimit=1)
    
    pData(standard_cds)$Total_mRNAs <- colSums(exprs(standard_cds))
    
    # TODO: exclude spike genes for coverage trick estimation!
    valid_genes <- row.names(subset(fData(standard_cds), biotype %in% c("spike") == FALSE))
    
    # Load up the ERCC spike-in control metadata, which we will use to 
    # convert the standard FPKM values to absolute values 
    input.ERCC.annotation<-read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/ERCC_specification.txt", header=T)
    colnames(input.ERCC.annotation)<-c("Resort_ID",
                                       "ERCC_ID",
                                       "subgroup",
                                       "conc_attomoles_ul_Mix1",
                                       "conc_attomoles_ul_Mix2",
                                       "exp_fch_ratio",
                                       "log2_Mix1_Mix2")
    
    # So we can index this data frame by ERCC transcript ID  							   
    rownames(input.ERCC.annotation)<-input.ERCC.annotation[,"ERCC_ID"]
    
    # Extract the spike-in FPKM values for each cell as a CellDataSet subset
    ercc_controls <- standard_cds[rownames(input.ERCC.annotation),]
    
    # Compute the mean spike FPKMs
    mean_spike_fpkms <- rowMeans(exprs(ercc_controls))
    spike_df <- input.ERCC.annotation 
    
    # Merge the means with the metadata so we can compare mean FPKM to spike-in concentration later
    spike_df <- cbind(spike_df, mean_spike_fpkms[row.names(spike_df)])
    colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
    spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23))
    pData(ercc_controls)$Cell <- row.names(pData(ercc_controls))
    
    # Fit a robust linear model of spike concentration vs. FPKM for each cell
    molModels <- esApply(ercc_controls, 2, function(cell_exprs, input.ERCC.annotation) {
      
      #print (cell_exprs)
      spike_df <- input.ERCC.annotation 
      spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
      colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
      spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23))
      spike_df$rounded_numMolecules <- round(spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23)))
      # print (mean(spike_df$rounded_numMolecules))
      
      spike_df <- subset(spike_df, FPKM >= 1e-10)
      spike_df$log_fpkm <- log10(spike_df$FPKM) 
      spike_df$log_numMolecules <- log10(spike_df$numMolecules)
      
      print (paste("geometric mean of log numMol ", mean(spike_df$log_numMolecules), "geometric mean of log FPKM ", mean(spike_df$log_fpkm)))
      
      molModel <- tryCatch({
        #molModel <- vgam (rounded_numMolecules ~ sm.ns(log_fpkm, df=3), data=spike_df, family=negbinomial(zero=NULL))
        molModel <- rlm(log_numMolecules ~ log_fpkm, data=spike_df)
        
        #
        # 		    qp <- qplot(FPKM, numMolecules, data=spike_df, log="xy") +
        # 			geom_abline(color="green") +
        # geom_smooth(aes(y=10^log_numMolecules), method="lm") +
        # geom_smooth(aes(y=10^log_numMolecules), method="rlm", color="red") +
        # geom_line(aes(y=10^predict(molModel,type="response")))
        # print(qp)
        molModel
      }, 
      error = function(e) { print(e); NULL })
      molModel
    }, input.ERCC.annotation)
    
    # Now use the per-cell linear models to produce a matrix of absolute transcript abundances 
    # for each gene in the genome, in each cell
    norm_fpkms <- mapply(function(cell_exprs, molModel) {
      tryCatch({
        norm_df <- data.frame(log_fpkm=log10(cell_exprs))
        res <- 10^predict(molModel, type="response", newdata=norm_df)
      }, 
      error = function(e) {
        rep(NA, length(cell_exprs))
      })
    }, 
    split(exprs(standard_cds), rep(1:ncol(exprs(standard_cds)), each = nrow(exprs(standard_cds)))), 
    molModels)
    
    row.names(norm_fpkms) <- row.names(exprs(standard_cds))
    colnames(norm_fpkms) <- colnames(exprs(standard_cds))
    
    norm_fpkms_melted <- melt(norm_fpkms)
    total_RNA_df <- ddply(norm_fpkms_melted, .(Var2), function(x) { data.frame(total=sum(x$value), mode_mol=mlv(x$value[x$value > 0.0], method = "mfv")$M) })
    
    total_RNA_df <- merge(sample_sheet, total_RNA_df, by.x="row.names", by.y="Var2")
    
    # Now let's generate a new CellDataSet that uses the absolute transcript counts
    fpkm_matrix_abs <- norm_fpkms
    colnames(fpkm_matrix_abs) <- colnames(fpkm_matrix)
    row.names(fpkm_matrix_abs) <- row.names(fpkm_matrix)
    #fpkm_matrix <- fpkm_matrix[,-1]
    
    pd <- new("AnnotatedDataFrame", data = sample_sheet[colnames(fpkm_matrix_abs),])
    fd <- new("AnnotatedDataFrame", data = gene_ann[rownames(fpkm_matrix_abs),])
    
    absolute_cds <- newCellDataSet(fpkm_matrix_abs, 
                                   phenoData = pd, 
                                   featureData = fd, 
                                   expressionFamily=negbinomial(), 
                                   lowerDetectionLimit=1)
    
    pData(absolute_cds)$Total_mRNAs <- esApply(absolute_cds, 2, sum)
    transcript_num <- 38919 #number of genes in the genome 
    pData(absolute_cds)$endogenous_RNA <- esApply(absolute_cds, 2, function(x) sum(x[1:transcript_num]))
    
    # Load up the isoform-level read counts
    count_matrix <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/standard_normalized_out/isoforms.fpkm_table", row.names="tracking_id")
    #fpkm_matrix <- fpkm_matrix[,-1]
    isoform_ann <- read.delim("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/standard_normalized_out/isoforms.attr_table", row.names="tracking_id")
    isoform_ann$isoform_id <- row.names(isoform_ann)
    
    isoform_ann <- merge(isoform_ann, gene_ann[,c("gene_id", "biotype")], by.x="gene_id", by.y="row.names")
    #gencode_biotypes <- read.delim("gencode_biotypes.txt")
    row.names(isoform_ann) <- isoform_ann$isoform_id
    isoform_ann <- isoform_ann[,-1]
    
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = isoform_ann)
    
    count_matrix <- as.matrix(count_matrix)
    count_matrix <- count_matrix[row.names(isoform_ann),]
    count_matrix <- count_matrix[,row.names(sample_sheet)]
    
    isoform_count_cds <- newCellDataSet(count_matrix, 
                                        phenoData = pd, 
                                        featureData = fd, 
                                        expressionFamily=negbinomial(), 
                                        lowerDetectionLimit=1)
    
    #use the algorithm to recover the transcript counts based on mode inferred from isoform data 
    norm_matrix <- relative2abs(exprs(standard_cds), t_estimate = estimate_t(exprs(isoform_count_cds)))
    mc_adj_cds <- newCellDataSet(as.matrix(norm_matrix),
                                 phenoData = new("AnnotatedDataFrame", data = pData(standard_cds)),
                                 featureData = new("AnnotatedDataFrame", data = fData(standard_cds)),
                                 expressionFamily = negbinomial(),
                                 lowerDetectionLimit = 1)
    pData(mc_adj_cds)$Total_mRNAs <- esApply(mc_adj_cds, 2, sum)
    pData(mc_adj_cds)$endogenous_RNA <- esApply(mc_adj_cds, 2, function(x) sum(x[1:transcript_num]))
    
    #read the read count data for the genes: 
    dir = "/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Projects/quake_lung/standard_normalized_out"
    sample_table <- read.delim(paste(dir, "/samples.table", sep = ''))
    norm_count <- read.delim(paste(dir, "/genes.count_table", sep = ''))
    row.names(norm_count) <- norm_count$tracking_id
    norm_count <- norm_count[, -1]
    
    read_countdata <- round(t(t(norm_count) * sample_table$internal_scale)) #convert back to the raw counts 
    
    quake_read_cds <- newCellDataSet(read_countdata[row.names(absolute_cds), colnames(absolute_cds)],
                                     phenoData = new("AnnotatedDataFrame", data = pData(absolute_cds)),
                                     featureData = new("AnnotatedDataFrame", data = fData(absolute_cds)),
                                     expressionFamily = negbinomial(),
                                     lowerDetectionLimit = 1)
    
    #generate the pvals from the statistical test (permutation based or from software: monocle/DESeq/SCDE)
    
    ################################## this long section is used to generate all the data for making the figure 1e: ##################################
    #generate the test p-val as well as the permutation pval
    
    #select cells for two group tests (E18.5 vs E14.5): 
    valid_cells <- colnames(absolute_cds)[colSums(round(exprs(absolute_cds[valid_genes,])))  > 9500]
    
    #double check the cells selected are the same as we used in the paper:  identical(colnames(new_abs_cds_14_18), cells_used)
    new_abs_cds_14_18 <- absolute_cds[, intersect(valid_cells, row.names(subset(pData(absolute_cds), Time %in% c('E18.5', 'E14.5'))))]
    new_abs_cds_14_18 <- estimateSizeFactors(new_abs_cds_14_18) #calculate the size factor for performing the relative absolute expression tests
    
    new_mc_cds_14_18 <- mc_adj_cds[, colnames(new_abs_cds_14_18)]
    new_mc_cds_14_18 <- estimateSizeFactors(new_mc_cds_14_18)
    
    new_std_cds_14_18 <- standard_cds[, colnames(new_abs_cds_14_18)]
    
    #prepare the readcount data for DESeq / SCDE: 
    read_countdata <- read_countdata[row.names(new_abs_cds_14_18), colnames(new_abs_cds_14_18)] 
    
    #create a cds for readcount data to perform the default DEG tests for DESeq and SCDE : 
    count_cds <- newCellDataSet(read_countdata[row.names(new_abs_cds_14_18), colnames(new_abs_cds_14_18)],
                                phenoData = new("AnnotatedDataFrame", data = pData(new_abs_cds_14_18)),
                                featureData = new("AnnotatedDataFrame", data = fData(new_abs_cds_14_18)),
                                expressionFamily = negbinomial(),
                                lowerDetectionLimit = 1)
    
    count_cds <- estimateSizeFactors(count_cds)
    
    #load some meta data from quake paper: 
    load('/Users/xqiu/Dropbox (Personal)/Quake/absolute_transcript/SRR_cell_type')
    load('/Users/xqiu/Dropbox (Personal)/Quake/absolute_transcript/quake_gene_name')
    
    #gsa data: 
    dropbox_root <- paste(Sys.getenv("HOME"), "/Dropbox (Cole Trapnell's Lab)", sep="")
    
    human_go_gsc <- loadGSCSafe(paste(dropbox_root,"/Shared Data/GMT/EM_pathways/Human/symbol/Human_GO_AllPathways_with_GO_iea_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
    names(human_go_gsc$gsc) <- str_split_fixed(names(human_go_gsc$gsc), "%", 2)[,1]
    
    human_reactome_gsc <- loadGSCSafe(paste(dropbox_root,"/Shared Data/GMT/EM_pathways/Human/symbol/Pathways/Human_Reactome_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
    names(human_reactome_gsc$gsc) <- str_split_fixed(names(human_reactome_gsc$gsc), "%", 2)[,1]
    
    mouse_go_gsc <- loadGSCSafe(paste(dropbox_root,"/Shared Data/GMT/EM_pathways/Mouse/by_symbol/GO/MOUSE_GO_bp_with_GO_iea_symbol.gmt", sep=""), encoding="latin1")
    names(mouse_go_gsc$gsc) <- str_split_fixed(names(mouse_go_gsc$gsc), "%", 2)[,1]
    
    mouse_reactome_gsc <- loadGSCSafe(paste(dropbox_root,"/Shared Data/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Reactome_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
    names(mouse_reactome_gsc$gsc) <- str_split_fixed(names(mouse_reactome_gsc$gsc), "%", 2)[,1]
    
    mouse_kegg_gsc <- loadGSCSafe(paste(dropbox_root,"/Shared Data/GMT/EM_pathways/Mouse/by_symbol/Pathways/Mouse_Human_KEGG_June_20_2014_symbol.gmt", sep=""), encoding="latin1")
    names(mouse_kegg_gsc$gsc) <- str_split_fixed(names(mouse_kegg_gsc$gsc), "%", 2)[,1]
    
    ##Cole's code to order the muscle cells##
    HSMM_fpkm_matrix <- read.delim("~/Dropbox (Cole Trapnell's Lab)/Shared Data/Muscle/HSMM/HSMM_cuffnorm_out/genes.fpkm_table")
    row.names(HSMM_fpkm_matrix) <- HSMM_fpkm_matrix$tracking_id
    HSMM_fpkm_matrix <- HSMM_fpkm_matrix[,-1]
    
    HSMM_isoform_fpkm_matrix <- read.delim("~/Dropbox (Cole Trapnell's Lab)/Shared Data/Muscle/HSMM/HSMM_cuffnorm_out/isoforms.fpkm_table")
    row.names(HSMM_isoform_fpkm_matrix) <- HSMM_isoform_fpkm_matrix$tracking_id
    HSMM_isoform_fpkm_matrix <- HSMM_isoform_fpkm_matrix[,-1]
    
    sample_sheet <- read.delim("~/Dropbox (Cole Trapnell's Lab)/Shared Data/Muscle/HSMM/sample_sheet.txt")
    sample_sheet$cell_id <- paste(sample_sheet$cell_id, "_0", sep="")
    row.names(sample_sheet) <- sample_sheet$cell_id
    sample_sheet <- sample_sheet[colnames(HSMM_fpkm_matrix),]
    
    cell_is_valid_singleton <- row.names(subset(sample_sheet, Control == FALSE & Unusual.Shape == FALSE & Debris == FALSE & Clump == FALSE & Cells.in.Well == 1)) 
    sample_sheet <- sample_sheet[cell_is_valid_singleton,]
    
    HSMM_fpkm_matrix <- HSMM_fpkm_matrix[,row.names(sample_sheet)]
    HSMM_isoform_fpkm_matrix <- HSMM_isoform_fpkm_matrix[,row.names(sample_sheet)]
    
    HSMM_fpkm_matrix_adj <- relative2abs(HSMM_fpkm_matrix, estimate_t(HSMM_isoform_fpkm_matrix), cores=1)
    
    gene_ann <- read.delim("~/Dropbox (Cole Trapnell's Lab)/Shared Data/Muscle/HSMM/gene_annotations.txt")
    
    mito_genes <- subset(gene_ann, grepl("chrM", gene_ann$locus))$gene_short_name
    
    gencode_biotypes <- read.delim("~/Dropbox (Cole Trapnell's Lab)/Shared Data/Muscle/HSMM/gencode_biotypes.txt")
    
    gene_ann <- merge(gene_ann, gencode_biotypes, by = "gene_id")
    row.names(gene_ann) <- gene_ann$gene_id
    gene_ann <- gene_ann[,c("gene_short_name", "biotype")]
    gene_ann <- gene_ann[row.names(HSMM_fpkm_matrix_adj),]
    #sample_sheet <- sample_sheet[colnames(fpkm_matrix_adj),]
    
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = gene_ann)
    HSMM <-  newCellDataSet(HSMM_fpkm_matrix_adj, 
                            phenoData = pd, 
                            featureData = fd, 
                            expressionFamily=negbinomial(), 
                            lowerDetectionLimit=1)

}
