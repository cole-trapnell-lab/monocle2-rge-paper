#'  Load all the data save in the package
#'  
#' @param pkg_name The name for the package
#' @export 
#' 
load_all_data <- function(pkg_name = 'DevTree') 
  data(list = data(package = pkg_name)$results[, 3])

#' Multicore esApply wrapper (this function is taken from Monocle)
#'
#' @param required_packages a vector of package names need to provide for the environment paraell
#' @importFrom parallel makeCluster stopCluster clusterCall parRapply parCapply
#' @export
#' 
mcesApply <- function(X, MARGIN, FUN, required_packages, cores=1, ...) {
  parent <- environment(FUN)
  if (is.null(parent))
    parent <- emptyenv()
  e1 <- new.env(parent=parent)
  multiassign(names(pData(X)), pData(X), envir=e1)
  environment(FUN) <- e1
  cl <- parallel::makeCluster(cores)
  
  cleanup <- function(){
    parallel::stopCluster(cl)
  }
  on.exit(cleanup)
  
  if (is.null(required_packages) == FALSE){
    parallel::clusterCall(cl, function(pkgs) {
      for (req in pkgs) {
        library(req, character.only=TRUE)
      }
    }, required_packages)
  }
  
  if (MARGIN == 1){
    res <- parRapply(cl, exprs(X), FUN, ...)
  }else{
    res <- parCapply(cl, exprs(X), FUN, ...)
  }
  
  res
}

#add some scripts required in the following functions
# source('hack_glm_perm.R')

#' function for permutating the two group labels ad calculating the p-val
#' 
#' @param x The gene expression vector 
#' @param fc The fold change between two groups from the original data
#' @param alpha number of group 0 in the two-group test
#' @param beta number of group 1 in the two-group test
#' @param permutate_num Time of permutations to perform
#' @param return_fc A logic argument to determine whether or not the fold change from the each permutation should be returned 
#' @export

permuation_pval <- function(x, fc, alpha = 43, beta = 74, permutate_num = 10000, return_fc = F) {
  
  fc_vec <- rep(0, permutate_num)
  # Time <- Time_ori
  #message(Time)
  
  if(is.na(fc)) return(1)
  for(i in 1:permutate_num) {
    x <- sample(x, length(x))
    x_0 <- (mean(x[1:alpha]))
    x_1 <- (mean(x[(alpha + 1):(alpha + beta)]))
    
    mean_fc <- log2(x_1 / x_0) #return the log transformed fold-change
    fc_vec[i] <- mean_fc
  }
  
  if(fc > 0)  pval <- sum(fc <= fc_vec) / length(fc_vec)
  else pval <- sum(fc >= fc_vec) / length(fc_vec)
  
  if(return_fc)
    return(list(pval = pval, fc_vec = fc_vec))  
  else
    return(pval)
}

#' Function to compare the performance of VGLM with different options for the size factor setting
#' 
#' @param x Gene expression vector 
#' @param disp_func A function provides the information for the dispersion based on fitting the data
#' @param Total_mRNAs Total mRNA counts for each cell  
#' @param Time The time when the cells are collected
#' @export

logLik_cmpr <- function(x, disp_func, Total_mRNAs, Time) {
  vglm_test_df <- data.frame(expression = round(as.numeric(x)), Total_mRNAs = Total_mRNAs, Time = Time)
  
  print(dim(vglm_test_df))
  ori <- vglm(as.formula("expression~1"), data = vglm_test_df, family = negbinomial)
  full_ori <- vglm(as.formula("expression~Time"), data = vglm_test_df, family = negbinomial)
  #   lrtest(full_ori, ori)
  (testStatistic <- 2 * (logLik(full_ori) - logLik(ori)))
  (ori_pval <- pchisq(testStatistic, df = length(coef(full_ori)) - length(coef(full_ori)),
                      lower.tail = FALSE))
  cell_wise_size <- vglm(as.formula("expression~1"), data = vglm_test_df, family = negbinomial.size(size = disp_func(vglm_test_df$expression + 0.01), imu = NULL, zero=NULL))
  full_cell_wise_size <- vglm(as.formula("expression~Time"), data = vglm_test_df, family = negbinomial.size(size = disp_func(vglm_test_df$expression + 0.01), imu = NULL, zero=NULL))
  #   lrtest(full_ori, ori)
  (testStatistic <- 2 * (logLik(full_cell_wise_size) - logLik(cell_wise_size)))
  (cell_wise_size_pval <- pchisq(testStatistic, df = length(coef(full_cell_wise_size)) - length(coef(cell_wise_size)),
                                 lower.tail = FALSE))
  
  mean_size <- vglm(as.formula("expression~1"), data = vglm_test_df, family = negbinomial.size(size = disp_func(mean(vglm_test_df$expression) + 0.01), imu = NULL, zero=NULL))
  full_mean_size <- vglm(as.formula("expression~Time"), data = vglm_test_df, family = negbinomial.size(size = disp_func(mean(vglm_test_df$expression) + 0.01), imu = NULL, zero=NULL))
  #   lrtest(full_ori, ori)
  (testStatistic <- 2 * (logLik(full_mean_size) - logLik(mean_size)))
  (mean_size_pval <- pchisq(testStatistic, df = length(coef(full_mean_size)) - length(coef(mean_size)),
                            lower.tail = FALSE))
  
  cell_wise_isize <- vglm(as.formula("expression~1"), data = vglm_test_df, family = negbinomial(isize = disp_func(vglm_test_df$expression + 0.01), imu = NULL, zero=NULL))  
  full_cell_wise_isize <- vglm(as.formula("expression~Time"), data = vglm_test_df, family = negbinomial(isize = disp_func(vglm_test_df$expression + 0.01), imu = NULL, zero=NULL))  
  #   lrtest(full_ori, ori)
  (testStatistic <- 2 * (logLik(full_cell_wise_isize) - logLik(cell_wise_isize)))
  (cell_wise_isize_pval <- pchisq(testStatistic, df = length(coef(full_cell_wise_isize)) - length(coef(cell_wise_isize)),
                                  lower.tail = FALSE))
  
  mean_isize <- vglm(as.formula("expression~1"), data = vglm_test_df, family = negbinomial(isize = disp_func(mean(vglm_test_df$expression) + 0.01), imu = NULL, zero=NULL))
  full_mean_isize <- vglm(as.formula("expression~Time"), data = vglm_test_df, family = negbinomial(isize = disp_func(mean(vglm_test_df$expression) + 0.01), imu = NULL, zero=NULL))
  #   lrtest(full_ori, ori)
  (testStatistic <- 2 * (logLik(full_mean_isize) - logLik(mean_isize)))
  (mean_isize_pval <- pchisq(testStatistic, df = length(coef(full_mean_isize)) - length(coef(mean_isize)),
                             lower.tail = FALSE))
  
  return(data.frame(ori = ori_pval, cell_wise_size = cell_wise_size_pval, mean_size = mean_size_pval, cell_wise_isize = cell_wise_isize_pval, mean_isize = mean_isize_pval))
}

#' Function to calculat the data.frame
#' 
#' @param gene_names
#' @param ind
#' @param test_res
#' @export

construct_df <- function(gene_names, ind, test_res, DEG_test_name, p_vec){
  #names
  name <- gene_names[ind] #use index to find the gene names
  #fold change (extract fc from the test dataframe)
  if("fc" %in% names(test_res)) {
    fc <- test_res[name, 'fc']
  }
  else if('log2FoldChange' %in% names(test_res)) {
    fc <- test_res[name, 'log2FoldChange'] #note that DESeq1 fold change is different from naive fold change
  }
  else { #scde/mle 
    if(length(grep('mc', DEG_test_name))) {
      message('choosing mc cds for fc: ', DEG_test_name)
      fc <- gene_mean_mc[name]
    }
    else if(length(grep('std', DEG_test_name))) {
      message('choosing standard cds: ', DEG_test_name)
      fc <- gene_mean_std[name]
    }
    else { #absolute
      message('choosing absolute cds: ', DEG_test_name)    
      fc <- gene_mean_abs[name]
    }
  }
  
  #avg expression 
  if(length(grep('mc', DEG_test_name))) {
    message('choosing mc cds for avg_exp: ', DEG_test_name)
    avg_exp <- rowMeans(exprs(mc_abs_14_18[name, ]))
    avg_e14 <- rowMeans(exprs(mc_abs_14_18[name, pData(mc_abs_14_18)$Time == 'E14.5']))
    avg_e18 <- rowMeans(exprs(mc_abs_14_18[name, pData(mc_abs_14_18)$Time == 'E18.5']))
  }
  else if(length(grep('std', DEG_test_name))) {
    message('choosing standard cds for avg_exp: ', DEG_test_name)
    avg_exp <- rowMeans(exprs(std_cds_14_18[name, ]))
    avg_e14 <- rowMeans(exprs(std_cds_14_18[name, pData(std_cds_14_18)$Time == 'E14.5']))
    avg_e18 <- rowMeans(exprs(std_cds_14_18[name, pData(std_cds_14_18)$Time == 'E18.5']))}
  else { #absolute
    message('choosing absolute cds for avg_exp: ', DEG_test_name)    
    avg_exp <- rowMeans(exprs(abs_cds_14_18[name, ]))
    avg_e14 <- rowMeans(exprs(abs_cds_14_18[name, pData(abs_cds_14_18)$Time == 'E14.5']))
    avg_e18 <- rowMeans(exprs(abs_cds_14_18[name, pData(abs_cds_14_18)$Time == 'E18.5']))
  }
  
  #pval 
  pval <- p_vec[name]
  
  return(list(names = name, fc = fc, avg_exp = avg_exp, avg_e14 = avg_e14, avg_e18 = avg_e18, pval = pval, type = rep(DEG_test_name, length(fc))))
}

#' Function to calculate the true/false positive and true/false negative 
#' @param true_data The true (1) / false (0) positive DEGs based on the permutation test
#' @param type parameters for the function of construct_df
#' @param gene_names names of genes
#' @param test_res 
#' @param p_vec 
#' @export

find_TFPN <- function(true_data, type, gene_names, test_res, p_vec) { #gene_names, x, test_res, DEG_test_name, p_vec
  
  TP_tmp <- which((true_data * (p_vec <= p_thrsld)) == 1) 
  FP_tmp <- which(((1 - true_data) * (p_vec <= p_thrsld)) == 1) 
  TN_tmp <- which(((1 - true_data) * (p_vec > p_thrsld)) == 1) 
  FN_tmp <- which((true_data * (p_vec > p_thrsld)) == 1) 
  
  list_tmp <- list(TP = TP_tmp, FP = FP_tmp, TN = TN_tmp, FN = FN_tmp)
  
  TFPN_list <- lapply(list_tmp, function(x) construct_df(gene_names, x, test_res, type, p_vec))
  
  return(TFPN_list)
}

#' Update the TFPN data.frame
#' 
#' @param TP 
#' @param FP
#' @param TN
#' @param FN
#' @param TFPN_list
#' @export

update_TFPN <- function(TP, FP, TN, FN, TFPN_list) {
  TP$name <- c(TP$name, TFPN_list$TP$name)
  TP$fc <- c(TP$fc, TFPN_list$TP$fc)
  TP$avg_exp <- c(TP$avg_exp, TFPN_list$TP$avg_exp)
  TP$avg_e14 <- c(TP$avg_e14, TFPN_list$TP$avg_e14)
  TP$avg_e18 <- c(TP$avg_e18, TFPN_list$TP$avg_e18)
  TP$pval <- c(TP$pval, TFPN_list$TP$pval)
  TP$type <- c(TP$type, TFPN_list$TP$type)
  
  FP$name <- c(FP$name, TFPN_list$FP$name)
  FP$fc <- c(FP$fc, TFPN_list$FP$fc)
  FP$avg_exp <- c(FP$avg_exp, TFPN_list$FP$avg_exp)
  FP$avg_e14 <- c(FP$avg_e14, TFPN_list$FP$avg_e14)
  FP$avg_e18 <- c(FP$avg_e18, TFPN_list$FP$avg_e18)
  FP$pval <- c(FP$pval, TFPN_list$FP$pval)
  FP$type <- c(FP$type, TFPN_list$FP$type)
  
  TN$name <- c(TN$name, TFPN_list$TN$name)
  TN$fc <- c(TN$fc, TFPN_list$TN$fc)
  TN$avg_exp <- c(TN$avg_exp, TFPN_list$TN$avg_exp)
  TN$avg_e14 <- c(TN$avg_e14, TFPN_list$TN$avg_e14)
  TN$avg_e18 <- c(TN$avg_e18, TFPN_list$TN$avg_e18)
  TN$pval <- c(TN$pval, TFPN_list$TN$pval)
  TN$type <- c(TN$type, TFPN_list$TN$type)
  
  FN$name <- c(FN$name, TFPN_list$FN$name)
  FN$fc <- c(FN$fc, TFPN_list$FN$fc)
  FN$avg_exp <- c(FN$avg_exp, TFPN_list$FN$avg_exp)
  FN$avg_e14 <- c(FN$avg_e14, TFPN_list$FN$avg_e14)
  FN$avg_e18 <- c(FN$avg_e18, TFPN_list$FN$avg_e18)
  FN$pval <- c(FN$pval, TFPN_list$FN$pval)
  FN$type <- c(FN$type, TFPN_list$FN$type)
  
  return(list(TP = TP, FP = FP , TN = TN, FN = FN))
}

#' plot thee pval distribution in TP, FP, TN, FN categories:
#' @export

plot_category_pval <- function(DEG_test_list, permutate_pval, p_thrsld) {
  true_data <- as.numeric(permutate_pval < p_thrsld) #logic to numeric 
  gene_names <- names(permutate_pval)
  
  TP <- list(); length(TP) <- 7; names(TP) <- c('name', 'pval', 'avg_exp', 'avg_e14', 'avg_e18', 'fc', 'type')
  FP <- list(); length(FP) <- 7; names(FP) <- c('name', 'pval', 'avg_exp', 'avg_e14', 'avg_e18', 'fc', 'type')
  TN <- list(); length(TN) <- 7; names(TN) <- c('name', 'pval', 'avg_exp', 'avg_e14', 'avg_e18', 'fc', 'type')
  FN <- list(); length(FN) <- 7; names(FN) <- c('name', 'pval', 'avg_exp', 'avg_e14', 'avg_e18', 'fc', 'type') #pval, fc, avg_exp, names 
  for(i in 1:length(DEG_test_list)) {#length(DEG_test_list)
    message(i, ": ", names(DEG_test_list)[i])
    if("padj" %in% colnames(DEG_test_list[[i]])) {
      print(DEG_test_list[[i]][1, ])
      p_vec <- DEG_test_list[[i]][gene_names, length(DEG_test_list[[i]][1, ]) - 1]
      names(p_vec) <- gene_names
      
      TFPN_list <- find_TFPN(true_data, type = names(DEG_test_list)[i], gene_names, DEG_test_list[[i]], p_vec) #true_data, type, gene_names, test_res, p_vec
      
      TFPN_update <- update_TFPN(TP, FP, TN, FN, TFPN_list) 
      TP <- TFPN_update$TP
      FP <- TFPN_update$FP
      TN <- TFPN_update$TN
      FN <- TFPN_update$FN
      
    }
    else if("qval" %in% colnames(DEG_test_list[[i]])) {
      p_vec <- DEG_test_list[[i]][gene_names, 'pval']
      names(p_vec) <- gene_names
      
      TFPN_list <- find_TFPN(true_data, type = names(DEG_test_list)[i], gene_names, DEG_test_list[[i]], p_vec) #true_data, type, gene_names, test_res, p_vec
      
      TFPN_update <- update_TFPN(TP, FP, TN, FN, TFPN_list) 
      TP <- TFPN_update$TP
      FP <- TFPN_update$FP
      TN <- TFPN_update$TN
      FN <- TFPN_update$FN
    }
    else if(!is.data.frame(DEG_test_list[[i]])) {
      p_vec <- DEG_test_list[[i]]$pval[gene_names]
      names(p_vec) <- gene_names
      
      TFPN_list <- find_TFPN(true_data, type = names(DEG_test_list)[i], gene_names, DEG_test_list[[i]], p_vec) #true_data, type, gene_names, test_res, p_vec
      
      TFPN_update <- update_TFPN(TP, FP, TN, FN, TFPN_list) 
      TP <- TFPN_update$TP
      FP <- TFPN_update$FP
      TN <- TFPN_update$TN
      FN <- TFPN_update$FN
    }
    else  message("qval not found: ", names(DEG_test_list)[i])
  }
  return(list(TP = TP, FP = FP, TN = TN, FN = FN))
}

#add the goodness of fit test on the gene distribution 
#tobit model 

# tmp_ln <- fitdist(as.numeric(obs + pseudo_cnt), 'lnorm', 
#                   lower = c(eps, eps))
# ln_pvalue[i] <- gofstat(tmp_ln)$chisqpvalue

# #negative binomial distribution  
# tmp_nb <- fitdist(round(obs + pseudo_cnt), 'nbinom',
#                   lower = c(eps, eps))#, start = list(size = exprs_abs[i, 200], mu = exprs_abs[i, 201]))
# nb_pvalue[i] <- gofstat(tmp_nb)$chisqpvalue


# #vglm fitting 
# fit_tobit <- vglm(obs~1, data=data.frame(obs  = obs)), family = "tobit")
# mu <- coef(fit_tobit)[1]
# lsd <- coef(fit_tobit)[2]
# #pchisq(deviance(fit_tobit), df.residual(fit_tobit), lower.tail  = F)
# uniq_fpkm <- unique(round(sort(log10(test_gd_obs[7, ]))))
# tobit.p <- c(ptobit(uniq_fpkm[1], mean = mu, sd = exp(lsd), log = F), 
#              diff(ptobit(uniq_fpkm, mean = mu, sd = exp(lsd), log = F)) 
#              ) 
# tobit.p[length(uniq_fpkm)] <- tobit.p[length(uniq_fpkm)] + 1 - sum(c(diff(ptobit(uniq_fpkm[1], mean = mu, sd = exp(lsd), log = F)), 
#                                          diff(ptobit(uniq_fpkm, mean = mu, sd = exp(lsd), log = F))))
# tobit.chisq <- chisq.test(as.vector(table(round(sort(log10(test_gd_obs[7, ]))))), p = tobit.p, simulate.p.value = T, B = 9000)$p.value

# nb.p <- c(dnbinom(uniq_cnt_lst[-1], mu = mu, size = size), 1 - sum(dnbinom(uniq_cnt_lst[-1], mu = mu, size = size)))
# nb_pvalue.chisq[i] <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = nb.p, simulate.p.value = T, B = 9999)$p.value

# add_2_lst <- 1 - sum(c(plnorm(uniq_cnt_lst[1], meanlog = meanlog, sdlog = sdlog), 
#                        diff(plnorm(uniq_cnt_lst, meanlog = meanlog, sdlog = sdlog))))
# ln.p <- c(plnorm(uniq_cnt_lst[1], meanlog = meanlog, sdlog = sdlog), #for continous variable, we need the area between neighboring sections
#           diff(plnorm(uniq_cnt_lst, meanlog = meanlog, sdlog = sdlog)))
# ln.p[uniq_len] = ln.p[uniq_len] + add_2_lst
# ln_pvalue.chisq[i] <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = ln.p, simulate.p.value = T, B = 9999)$p.value #?


#' Function for performing the intersection between multiple DEG gene sets
#' @export

inter_num <- function(deg_list, index) {
  Reduce(intersect, (deg_list[index]))
}

#' Calculate the fold change of gene expression between different groups
#'
#' @param cds CellDataFrame for the gene expression
#' @param fc_list A list storing the cell category assignments in the first component and then the two categories at each categories
#' @export

fc <- function(cds, fc_list) {
  log2(rowMeans(exprs(cds[, fc_list[[1]] == fc_list[[2]][1]])) / 
         rowMeans(exprs(cds[, fc_list[[1]] == fc_list[[2]][2]])))
}

#' Calculate mean expression for E14.5/E18.5 
#'
#' @param x Gene expression vector
#' @param Time The time assignment for the data 
#' @export

mean_exprs <-  function(x, Time, type = c('E14.5', 'E18.5')) { 
  x_14 <- (mean(x[Time == type[1]]))
  x_18 <- (mean(x[Time == type[2]]))
  a <- list(x_14, x_18)
  
  return(a)
}

#' Log2 fold change between two groups
#' 
#' @param x Gene expression vector 
#' @param grp0 The first group assignment 
#' @param grp1 The second group assignment 
#' @param grp The group assignment for the cells 
#' @param round A logic argument determining whether or not we should round the data first 
#' @export

mean_fc <- function(x, grp0 = c('E14.5', 'T0_CT_0'), grp1 = c('E18.5', 'T48_CT_0'), grp = Time, round = FALSE) { 
  if(round) {
    x_0 <- (mean(round(x[grp == grp0])))
    x_1 <- (mean(round(x[grp == grp1])))  
  }
  else {
    x_0 <- (mean(x[grp == grp0]))
    x_1 <- (mean(x[grp == grp1]))
  }
  if(any(c(x_0, x_1) > 0)) {
    return(log2(x_1 / x_0)) #return the log transformed fold-change
  }
  else {
    return(NA)
  }
}

#' Calculate the log2 median fold change between two groups
#' 
#' @param x the gene expression assignment 
#' @export

median_fc <- function(x) {
  x_14 <- (median(x[Time == "E14.5"]))
  x_18 <- (median(x[Time == "E18.5"]))
  if(x_14 >= 1 & x_18 >= 1) {
    return(log2(x_18 / x_14)) #return the log transformed fold-change
  }
  else {
    return(NA)
  } 
}

roc.curve <- function(p_vec = p_vec, true_d = true_data, p_thrsld, print = FALSE){
  Ps = (p_vec <= p_thrsld ) * 1
  FP = sum((Ps == 1) * (true_d == 0), na.rm = T) / sum(true_d == 0)
  TP = sum((Ps == 1) * (true_d == 1), na.rm = T) / sum(true_d == 1)
  if(print == TRUE){
    print(table(Observed = true_d, Predicted = p_vec))
  }
  
  # results <- vector(“list”, 2)
  # results[[1]] = FP
  # results[[2]] = TP
  # results
  vect=c(FP,TP)
  names(vect)=c("FPR","TPR")
  return(vect)
}

#'vectorized roc.curve function for calculating the coordinates on the curve 
#' @export
ROC.curve <- Vectorize(roc.curve, "p_thrsld")

pre_rec.curve = function(p_vec = p_vec, true_data = true_data, p_thrsld, print = FALSE){
  Ps = (p_vec <= p_thrsld ) * 1
  precision = sum((Ps == 1) * (true_data == 1), na.rm = T) / sum(Ps, na.rm = T) #fraction of retrieved instances that are relevant 
  recall = sum((Ps == 1) * (true_data == 1), na.rm = T) / sum(true_data) #fraction of relevant instances that are retrieved 
  if(print == TRUE){
    print(table(Observed = true_data,Predicted = p_vec))
  }
  
  # results <- vector(“list”, 2)
  # results[[1]] = FP
  # results[[2]] = TP
  # results
  vect=c(recall, precision)
  names(vect)=c("recall","precision")
  return(vect)
}

#vectorized precision-recal function for calculating the coordinates on the curve 
#' @export
PRE_REC.curve <- Vectorize(pre_rec.curve, "p_thrsld")

#' Calculate area under curve based on the zoo package
#' @export
AUC <- function(x, y) {
  id <- order(x)
  auc <- sum(diff(x[id]) * rollmean(y[id], 2))
  
  auc
}

#' function to perform the scde DEG analysis based the scde package 
#' 
#' @param dir the directory to load the sample annotation file as well as the read count file
#' @param DEG_attribute The attributes used for performing the two group test 
#' @param contrast The constrast used for performing the test
#' @param n.cores Number of cores used for the test 
#' @param normalize A logic argument determining whether or not we should normalize our data by the size normalization
#' @param save.crossfit.plots A logic argument determing wheter or not we save the crossfit plots between cells
#' @param save.model.plots A logic argument determing wheter or not we save the model plots 
#' @param show.plot A logic argument determing wheter or not we show the plot
#' @export

scde_DEG <- function(dir, count_cds,  cds_subset = NULL, DEG_attribute, contrast,  n.cores = detectCores(), normalize = F,
                     save.crossfit.plots = F, save.model.plots = F, show.plot = F) {
  if(!is.null(dir)) {
    if(is.null(cds_subset)) {
      stop('Please provide cds_subset object to make the new count_cds')
    }
    
    sample_table <- read.delim(paste(dir, "/samples.table", sep = ''))
    norm_count <- read.delim(paste(dir, "/genes.count_table", sep = ''))
    row.names(norm_count) <- norm_count$tracking_id
    norm_count <- norm_count[, -1]
    
    countdata <- round(t(t(norm_count) * sample_table$internal_scale)) #convert back to the raw counts 
    
    countdata <- countdata[rownames(cds_subset), colnames(cds_subset)] #select only the correct cells 
    
    count_cds <- newCellDataSet(countdata,
                                phenoData = gene_pd[colnames(cds_subset), ],
                                featureData = gene_fd[row.names(cds_subset), ])
    #make a DESeqDataSet for DEG testing in DESeq2 
  }
  
  sg <- factor(pData(count_cds)[, DEG_attribute], levels = contrast)
  names(sg) <- colnames(count_cds)
  print(sg)
  table(sg)
  # message(sg)
  
  #use the top std gene lists 
  #clean up the dataset 
  if(normalize)
    cd <- round(t(t(exprs(count_cds)) / sizeFactors(count_cds)))
  else {
    cd <- round(exprs(count_cds))
  }
  
  #ensure the data are integer: 
  cd<-apply(cd,2,function(x) {storage.mode(x) <- 'integer'; x})
  
  #   # clean up the dataset
  # cd <- es.mef.small;
  # # omit genes that are never detected
  # cd <- cd[rowSums(cd)>0,];
  # # omit cells with very poor coverage
  # cd <- cd[,colSums(cd)>1e4]; 
  # sg <- Time_ori
  # cd <- round(exprs(abs_cds_14_18))
  
  #check the original datasets: 
  # cd <- cd[rowSums(cd) > 0, ] #genes expressed at least in one cell 
  # sg <- sg[colSums(cd) > 1e4] #remove cell which has low expression 
  # cd <- cd[, colSums(cd) > 1e4] #cells with high coverage 
  
  #fit error model 
  o.ifm <- scde.error.models(counts = cd, groups = sg, n.cores = n.cores, threshold.segmentation = T, 
                             save.crossfit.plots = save.crossfit.plots, save.model.plots = save.model.plots, verbose = 1)
  valid.cells <- o.ifm$corr.a > 0
  table(valid.cells)
  o.ifm <- o.ifm[valid.cells, ]
  
  #DEG testing 
  o.prior<-scde.expression.prior(models = o.ifm, counts = cd, length.out = 400, show.plot = show.plot)
  groups <- sg
  ediff<-scde.expression.difference(o.ifm,cd,o.prior,groups=groups,n.randomizations=100,n.cores=n.cores,verbose=1)
  mle_vec <- ediff[, 'mle']
  z_vec <- ediff[, 'Z']
  names(z_vec) <- row.names(ediff)
  
  #calculate the p-value from the normal distribution
  pvalue2sided = 2 * pnorm(-abs(z_vec))
  save(pvalue2sided, file = 'scde_pval.Rdata')
  
  scde_qval <- p.adjust(pvalue2sided, method = 'BH')
  scde_deg_name <- names(scde_qval[scde_qval < 0.1])
  
  return(list(pval = pvalue2sided, qval = scde_qval, deg_name = scde_deg_name))
}

#'using DESeq1 to calculate the two group test 
#'
#' @param count_d CellDataFrame contains the information for performing the DEG test
#' @param condition A vector represents the condition assignment for each cell
#' @param disp_method, sharing The method for calculating the dispersion and  
#' @param test_type The type of differential gene expression test, either the LRT or nbinomGLMTest, please refer to the details of DESeq data
#' @param scale A logic argument determing whether or we should normalize the data
#' @param contrast The constrast used for performing the test
#' @param fullModelFormulaStr The full model for the likelihood ratio test
#' @param reducedModelFormulaStr The reduced model for the likelihodd ratio test
#' @export

DESeq1_test <- function(count_d, condition = Time_ori, disp_method = 'blind', sharing = 'fit-only', 
                        test_type = 'nbinomGLMTest', scale = F, contrast = c("E14.5", "E18.5"),
                        fullModelFormulaStr = 'count~condition', reducedModelFormulaStr = 'count~1') {  
  message(class(count_d))
  if(class(count_d)[1] != 'CountDataSet')
    count_d <- newCountDataSet(round(exprs(cds)), condition)
  ## Estimate library size and dispersion
  d <- estimateSizeFactors(count_d)
  
  if(!scale) pData(d)$sizeFactor <- 1
  # if(test_type == 'nbinomGLMTest') d <- estimateDispersions(d, method = 'pooled', sharingMode = sharing)
  d2 <- d
  
  sizeFactor <- pData(d)$sizeFactor
  print(sizeFactor)
  
  d <- DESeq::estimateDispersions(d2, method = disp_method, sharingMode = sharing)
  message('pass here')
  #   plotDispEsts(d, main="DESeq: Per-gene dispersion estimates")
  
  ## Principal components biplot on variance stabilized data, color-coded by condition-librarytype
  #   print(plotPCA(varianceStabilizingTransformation(d), intgroup=c("condition", "libType")))
  message('estimate dispersion')
  tmp <- do.call(cbind.data.frame, lapply(d@fitInfo, function(x) x[c(1, 3)])) 
  disp_func <- lapply(ls(d@fitInfo), function(x) fitInfo(d, name = x)) #per-condition has multiple pvals
  message('all disp functions extracted')
  
  if(test_type == 'nbinomGLMTest') {
    message('test is ', test_type)
    ## Fit full and reduced models, get p-values
    print(DESeq::sizeFactors(d))
    dfit1 <- fitNbinomGLMs(d, as.formula(fullModelFormulaStr))
    dfit0 <- fitNbinomGLMs(d, as.formula(reducedModelFormulaStr))
    dpval <- nbinomGLMTest(dfit1, dfit0)
    dpadj <- p.adjust(dpval, method="BH")
    
    ## Make results table with pvalues and adjusted p-values
    dtable <- transform(dfit1, pval=dpval, padj=dpadj)
    dtable <- cbind(dtable, tmp)
    # dtable <- dtable[order(dtable$padj), ]
    head(dtable)
    # row.names(dtable) <- row.names(dtable)[order(dtable$padj)]
    message('pass glm test')
    
    return(list(dfit1 = dfit1, dfit0 = dfit0, 
                full_df.residual = attr( dfit1, "df.residual" ),
                reduced_df.residual = attr( dfit0, "df.residual" ),
                full_deviance = dfit1$deviance,
                reduced_deviance = dfit0$deviance,
                dtalbe = dtable, disp_func = disp_func))
    
  }
  # directly use nbinomTest()
  else if(test_type == 'nbinomTest') {
    dtable <- nbinomTest(d, contrast[1], contrast[2])
    dtable <- cbind(dtable, tmp)
    # row.names(dtable) <- dtable$id 
    message('pass nb test')
    
    return(list(dtalbe = dtable, disp_func = disp_func))
  }
  
  #"perGeneDispEsts" "dispFunc"        "fittedDispEsts"  "df"              "sharingMode"  
  # conditions <- ls(d@fitInfo)
  
  # dtable$perGeneDispEsts <- fitInfo(d)$perGeneDispEsts
  # dtable$fittedDispEsts <- fitInfo(d)$fittedDispEsts
}

#' Function to perform the two group differential gene expression test based on the DESeq 
#' 
#' @param dir the directory to load the sample annotation file as well as the read count file
#' @param cds CellDataFrame contains the information for performing the DEG test
#' @param Time A vector represents the time assignment for each cell
#' @param test_type The type of differential gene expression test, either the LRT or nbinomGLMTest, please refer to the details of DESeq data
#' @param design The full model for the likelihood ratio test
#' @param reduced The reduced model for the likelihodd ratio test
#' @param pd Data.frame for the phenotype
#' @export

DESeq2_deg <- function(dir, cds, Time, test_type = 'LRT', design = as.formula("~ Time"), 
                       reduced = as.formula('~ 1'), pd = pData(cds)) {
  if(!is.null(dir)) {
    sample_table <- read.delim(paste(dir, "/samples.table", sep = ''))
    norm_count <- read.delim(paste(dir, "/genes.count_table", sep = ''))
    row.names(norm_count) <- norm_count$tracking_id
    norm_count <- norm_count[, -1]
    
    countdata <- round(t(t(norm_count) * sample_table$internal_scale)) #convert back to the raw counts 
    
    if(exists('sample_sheet')) countdata <- countdata[, row.names(sample_sheet)] #select only the correct cells 
    
    #make a DESeqDataSet for DEG testing in DESeq2 
  }
  else countdata <- round(exprs(cds))
  # return(DEseq2_cnt_cds)
  
  DEseq2_cnt_cds <- DESeqDataSetFromMatrix(
    countData = countdata[, ], 
    colData = pd, 
    design = design #test 
  )
  DEseq2_cnt_cds <- DESeq(DEseq2_cnt_cds, test = test_type, reduced =reduced) #differential gene expression test 
  #generate other diagnostic pltos 
  return(DEseq2_cnt_cds)
}

#' Performance pseudotime test based on DESeq1 
#' @param count_d CellDataFrame contains the information for performing the DEG test
#' @param Pseudotime A vector represents the pseudotime calculated from monocle
#' @param disp_method, sharing The method for calculating the dispersion and  
#' @param test_type The type of differential gene expression test, either the LRT or nbinomGLMTest, please refer to the details of DESeq data
#' @param scale A logic argument determing whether or not we should normalize the data
#' @param fullModelFormulaStr The full model for the likelihood ratio test
#' @param reducedModelFormulaStr The reduced model for the likelihodd ratio test
#' @param branchTest sA logic argument determing whether or not we should perform the branch-dependent gene expression test
#' @export

DESeq1_pseudotime_test <- function(count_d = count, Pseudotime = pData(mc_abs_HSMM_myo)$Pseudotime, 
                                   disp_method = 'blind', sharing = 'fit-only', test_type = 'nbinomGLMTest', scale = T,
                                   full_model = "count~ns(Pseudotime, df = 3)", reduced_model = "count~1", branchTest = F) {  
  ## Estimate library size and dispersion
  
  # if(test_type == 'nbinomGLMTest') d <- estimateDispersions(d, method = 'pooled', sharingMode = sharing)
  count_d <- DESeq::newCountDataSet(round(counts(count_d)), pData(count_d)$condition) 
  d <- estimateSizeFactors(count_d)
  pData(d)$'Pseudotime' <- Pseudotime
  
  if(!scale) {
    #d <- estimateDispersions(d, method = disp_method, sharingMode = sharing)
    pData(d)$sizeFactor <- 1
    d <- estimateDispersions(d, method = disp_method, sharingMode = sharing)
  }
  d <- estimateDispersions(d, method = disp_method, sharingMode = sharing)
  
  #   plotDispEsts(d, main="DESeq: Per-gene dispersion estimates")
  
  ## Principal components biplot on variance stabilized data, color-coded by condition-librarytype
  #   print(plotPCA(varianceStabilizingTransformation(d), intgroup=c("condition", "libType")))
  
  message('test is ', test_type)
  ## Fit full and reduced models, get p-values
  dfit1 <- fitNbinomGLMs(d, as.formula(full_model)) #test on pseudotime 
  dfit0 <- fitNbinomGLMs(d, as.formula(reduced_model))
  dpval <- nbinomGLMTest(dfit1, dfit0)
  dpadj <- p.adjust(dpval, method="BH")
  
  ## Make results table with pvalues and adjusted p-values
  dtable <- transform(dfit1, pval=dpval, padj=dpadj)
  dtable <- dtable[order(dtable$padj), ]
  head(dtable)
  dtable
  message('pass glm test')
  
  #"perGeneDispEsts" "dispFunc"        "fittedDispEsts"  "df"              "sharingMode"  
  tmp <- do.call(cbind.data.frame, lapply(d@fitInfo, function(x) x[c(1, 3)])) 
  conditions <- ls(d@fitInfo)
  
  dtable <- cbind(dtable, tmp)
  
  if(branchTest) {
    #branch test
    #to do: 
    ##duplication of the data 
    dup_absolute_cds <- branchTest(absolute_cds, progenitor_type = 'duplicate', return_duplicated_cds = T)
    dup_mc_adj_cds <- branchTest(mc_adj_cds, progenitor_type = 'duplicate', return_duplicated_cds = T)
    dup_standard_cds <- branchTest(standard_cds, progenitor_type = 'duplicate', return_duplicated_cds = T)
  }
  # dtable$perGeneDispEsts <- fitInfo(d)$perGeneDispEsts
  # dtable$fittedDispEsts <- fitInfo(d)$fittedDispEsts
  return(list(dtalbe = dtable, disp_func = fitInfo(d)$dispFunc))
}

#' calculate the f_1 score
#'
#' @param TF_PN_vec The vector for number of true/false postive/negative genes from differential gene test based on the permutation pval 
#' @param beta The \eqn{\beta} parameter in the F_score formula
#' @export
#' 
# F_score <- function(TF_PN_vec, beta = 1) { #TP, FP, TN, FN
#   f_beta <- ((1 + beta^2) * TF_PN_vec[1]) / ((1 + beta^2) * TF_PN_vec[1] + beta^2 * TF_PN_vec[4] + TF_PN_vec[2])
#   f_beta
# }

F_score <- function (pre, rec, beta = 1){
  f_beta <- ((1 + beta^2) * pre * rec)/(beta^2 * pre + rec)
  f_beta
}

#' Function to generate the golden test sets based on the permutaton 
#' @param permutate_pval Pval from the permutation 
#' @param p_thrsld The threshold to determine whether or not it is a significant gene
#' @export
#' 
gene_list_true_data <- function(permutate_pval = abs_permutate_pval, p_thrsld, na.rm = T) {
  true_data <- permutate_pval <= p_thrsld #std_permutate_pval
  if(na.rm) true_data <- true_data[!is.na(true_data)]
  else true_data[is.na(true_data)] <- 1
  true_data[true_data] <- 1
  true_data[!true_data] <- 0
  # true_data <- true_data[!is.na(true_data)]
  
  gene_list <- names(true_data)
  
  # gene_list <- intersect(gene_list, row.names(permutate_pval)) #gene_list_abs
  # true_data <- true_data[gene_list]
  
  return(list(true_data = true_data, gene_list = gene_list))
}

#' construct a dataframe for all the pvals and a list for the pval 
#' To do: 
#' 1. output also a list
#' @export

make_pval_df <- function(DEG_test_list) {
  pval <- c()
  type <- c()
  # length(deg_list) <- length(DEG_test_list)
  # skip_cnt <- 0
  size_quake_id <- c(grep("quake", names(DEG_test_list)), grep("size", names(DEG_test_list))) #don't look at the quake/size
  
  for(i in 1:length(DEG_test_list)) {
    message(i, ": ", names(DEG_test_list)[i])
    if(class(get(names(DEG_test_list)[i])) == 'function' | i %in% size_quake_id) {
      message("skipping ", names(DEG_test_list)[i])
      #       skip_cnt <- skip_cnt + 1
      next
    }
    
    if(is.data.frame(DEG_test_list[[i]])) { #extract the qval 
      message('not a list')
      pval_pvalue <- c('pval', 'pvalue')
      p_ind <- which(pval_pvalue %in% colnames(DEG_test_list[[i]]))
      pval_tmp <- DEG_test_list[[i]][, pval_pvalue[p_ind]]
      print(pval_tmp[1:10]) 
      
      pval <- c(pval, pval_tmp) 
      type <- c(type, rep(names(DEG_test_list)[i], length(pval_tmp)))
    }
    else if(!is.data.frame(DEG_test_list[[i]])) {
      if(class(DEG_test_list[[i]]) == 'list') {
        message('a list')
        if(any(names(DEG_test_list[[i]]) %in% c("dtalbe", "diff_test_res"))) { #add pval either from DESeq (dtable) or from custom Monocle (diff_test_res)
          DESeq_pval_tmp <- DEG_test_list[[i]][['dtalbe']]$pval
          Monocle_pval_tmp <- as.numeric(as.character(DEG_test_list[[i]][['diff_test_res']]$pval))
          pval_tmp <- c(DESeq_pval_tmp, Monocle_pval_tmp)
          print(pval_tmp[1:10])
          
          pval <- c(pval, pval_tmp)   
          
          type <- c(type, rep(names(DEG_test_list)[i], length(pval_tmp)))
        }
        else {
          pval_tmp <- DEG_test_list[[i]]$pval
          print(pval_tmp[1:10])
          
          pval <- c(pval, pval_tmp) 
          type <- c(type, rep(names(DEG_test_list)[i], length(pval_tmp)))
        }
      }
      else {
        message('everything else')
        #         deg_list[[i - skip_cnt]] <-DEG_test_list[[i]]$pval
        #         names(deg_list)[i] <- names(DEG_test_list)[i]    
        pval_tmp <- DEG_test_list[[i]]$pval 
        pval <- c(pval, pval_tmp) 
        type <- c(type, rep(names(DEG_test_list)[i], length(pval_tmp)))
      }
      
    }
    else  message("qval not found: ", names(DEG_test_list)[i])
  }
  
  pval_df <- data.frame(pval = pval, type = type)
  return(pval_df)
}

#' prepare the data for comparing the performance of different DEG tests
#'
#' @param golden_std_type 
#' @export

testing_DEG <- function(golden_std_type = 'DEG_permutation', fc_thrsld_vec = NULL, p_thrsld_vec = seq(0.01, 0.10, length.out = 10), permuation_p = permuation_p[1], input_pval_df = NULL, data_type = 'absolute', quake_list = F) { #pval thrsld / fold change thrsld 
  
  if(golden_std_type %in% c('DEG_permutation', 'pseudotime_permutation')) p_thrsld_vec = seq(0.01, 0.1, length.out = 10)
  cb_mlt_roc_df <- NULL
  cb_mlt_gene_num <- NULL
  gene_list <- NULL 
  for(p_thrsld in p_thrsld_vec) {
    if(!is.null(p_thrsld_vec)) {
      gene_list_true_data_list <- gene_list_true_data(p_thrsld = p_thrsld, permutate_pval = permuation_p)
      gene_list <- gene_list_true_data_list$gene_list
      true_data <- gene_list_true_data_list$true_data
    }
    else if(is.null(fc_thrsld_vec)){
      if(data_type == 'absolute') { 
        sort_fc <- sort_fc_abs
      }
      else if(data_type == 'standard') {
        sort_fc <- sort_fc_std
      }
      else if(data_type == 'mc') {
        sort_fc <- sort_fc_est
      }
      fc2_deg <- sort_fc_abs[abs(sort_fc) > fc_thrsld] #top differential expressed genes
      fc2_neg <- sort_fc[sort(abs(gene_mean_abs), decreasing = T)][1:length(fc2_abs_deg)] #no dynamic changes genes 
      fc2 <- c(fc2_abs_deg, fc2_abs_neg)
      gene_list <- names(fc2)
      
      true_data <- c(rep(1, length(fc2_abs_deg)), rep(0, length(fc2_abs_deg)))
      true_data[true_data] <- 1
      true_data[!true_data] <- 0
    }
    else true_data <- quake_true_data
    
    if(data_type == 'absolute') {
      if(is.null(input_pval_df)) {
        pval_df <- data.frame(abs_dtable_blind_fit_nbinomTest = abs_dtable_blind_fit_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_blind_max_nbinomTest = abs_dtable_blind_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_blind_gene_nbinomTest = abs_dtable_blind_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_pool_fit_nbinomTest = abs_dtable_pool_fit_nbinomTest$dtalbe[gene_list, 'pval'],
                              abs_dtable_pool_max_nbinomTest = abs_dtable_pool_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_pool_gene_nbinomTest = abs_dtable_pool_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_condition_fit_nbinomTest = abs_dtable_condition_fit_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_dtable_condition_max_nbinomTest = abs_dtable_condition_max_nbinomTest$dtalbe[gene_list, 'pval'],
                              abs_dtable_condition_gene_nbinomTest = abs_dtable_condition_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              abs_diff_DESeq2 = as.data.frame(abs_DESeq_res)[gene_list, ]$'pvalue', 
                              diff_abs = as.numeric(as.character(abs_diff_test_res$diff_test_res[gene_list, 'pval'])), 
                              abs_diff_scde = abs_scde_res_list$pval[gene_list])
        print(pval_df[1:10, ])
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
        
      }
      else {
        pval_df <- input_pval_df[gene_list, ]
        print(pval_df[1:10, ])
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
      }
    } 
    else if(data_type == 'mc' & golden_std_type == 'DEG_permutation') {
      if(is.null(input_pval_df))
        pval_df <- data.frame(mc_dtable_blind_fit_nbinomTest = mc_dtable_blind_fit_nbinomTest$dtalbe[gene_list, 'pval'],
                              mc_dtable_blind_max_nbinomTest = mc_dtable_blind_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              mc_dtable_blind_gene_nbinomTest = mc_dtable_blind_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              mc_dtable_pool_fit_nbinomTest = mc_dtable_pool_fit_nbinomTest$dtalbe[gene_list, 'pval'],
                              mc_dtable_pool_max_nbinomTest = mc_dtable_pool_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              mc_dtable_pool_gene_nbinomTest = mc_dtable_pool_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              mc_dtable_condition_fit_nbinomTest = mc_dtable_condition_fit_nbinomTest$dtalbe[gene_list, 'pval'], 
                              mc_dtable_condition_max_nbinomTest = mc_dtable_condition_max_nbinomTest$dtalbe[gene_list, 'pval'],
                              mc_dtable_condition_gene_nbinomTest = mc_dtable_condition_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              diff_DESeq2 = as.data.frame(mc_DESeq_res)[gene_list, ]$'pvalue', 
                              diff_mc = as.numeric(as.character(mc_diff_test_res$diff_test_res[gene_list, 'pval'])), 
                              ori_diff_mc = ori_mc_diff_test_res[gene_list, 'pval'], 
                              diff_scde = abs_scde_res_list$pval[gene_list]) 
      else {
        pval_df <- input_pval_df[gene_list, ]
        print(pval_df[1:10, ])          
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
      }
      
      #mc method with different 
      #DEGs only on quake test df: 
      #       pval_df <- data.frame(quake_mc_dtable_blind_fit_nbinomTest = quake_mc_dtable_blind_fit_nbinomTest[gene_list, 'pval'], 
      #                               quake_mc_dtable_blind_max_nbinomTest = quake_mc_dtable_blind_max_nbinomTest[gene_list, 'pval'], 
      #                               quake_mc_dtable_blind_gene_nbinomTest = quake_mc_dtable_blind_gene_nbinomTest[gene_list, 'pval'],
      #                               quake_mc_dtable_pool_fit_nbinomTest = quake_mc_dtable_pool_fit_nbinomTest[gene_list, 'pval'],
      #                               quake_mc_dtable_pool_max_nbinomTest = quake_mc_dtable_pool_max_nbinomTest[gene_list, 'pval'], 
      #                               quake_mc_dtable_pool_gene_nbinomTest = quake_mc_dtable_pool_gene_nbinomTest[gene_list, 'pval'], 
      #                               quake_mc_dtable_condition_fit_nbinomTest = quake_mc_dtable_condition_fit_nbinomTest[gene_list, 'pval'], 
      #                               quake_mc_dtable_condition_max_nbinomTest = quake_mc_dtable_condition_max_nbinomTest[gene_list, 'pval'],
      #                               quake_mc_dtable_condition_gene_nbinomTest = quake_mc_dtable_condition_gene_nbinomTest[gene_list, 'pval'], 
      #                               mc_quake_res_blind_fit = mc_quake_res_blind_fit[gene_list, 'pval'], 
      #                               mc_quake_res_blind_max = mc_quake_res_blind_max[gene_list, 'pval'], 
      #                               mc_quake_res_blind_gene = mc_quake_res_blind_gene[gene_list, 'pval'], 
      #                               mc_quake_res_pool_fit = mc_quake_res_pool_fit[gene_list, 'pval'], 
      #                               mc_quake_res_pool_max = mc_quake_res_pool_max[gene_list, 'pval'], 
      #                               mc_quake_res_pool_gene = mc_quake_res_pool_gene[gene_list, 'pval'], 
      #                               mc_quake_res_condition_fit = mc_quake_res_condition_fit[gene_list, 'pval'], 
      #                               mc_quake_res_condition_max = mc_quake_res_condition_[gene_list, 'pval'], 
      #                               mc_quake_res_condition_gene = mc_quake_res_condition_gene[gene_list, 'pval'], 
      #                               )
    }
    else if(data_type == 'mc' & golden_std_type == 'pseudotime_permutation') {
      if(is.null(input_pval_df)) {
        pval_df <- data.frame(mc_pseudo_dtable_condition_gene_nbinomGLMTest = mc_pseudo_dtable_fit_gene_nbinomTest[gene_list, 'pval'], 
                              diff_DESeq2_pseudo = as.data.frame(mc_DESeq2_pseudo_res)[gene_list, 'pvalue'], 
                              diff_mc_pseudo = mc_pseudotime_res$diff_test_res[gene_list, 'pval']) 
        print(pval_df[1:10, ])          
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
      }        
      else {
        pval_df <- input_pval_df[gene_list, ]
        print(pval_df[1:10, ])          
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
      }
    }
    else if(data_type == 'standard') {
      if(is.null(input_pval_df))
        pval_df <- data.frame(std_dtable_blind_fit_nbinomTest = std_dtable_blind_fit_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_blind_max_nbinomTest = std_dtable_blind_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_blind_gene_nbinomTest = std_dtable_blind_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_pool_fit_nbinomTest = std_dtable_pool_fit_nbinomTest$dtalbe[gene_list, 'pval'],
                              std_dtable_pool_max_nbinomTest = std_dtable_pool_max_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_pool_gene_nbinomTest = std_dtable_pool_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_condition_fit_nbinomTest = std_dtable_condition_fit_nbinomTest$dtalbe[gene_list, 'pval'], 
                              std_dtable_condition_max_nbinomTest = std_dtable_condition_max_nbinomTest$dtalbe[gene_list, 'pval'],
                              std_dtable_condition_gene_nbinomTest = std_dtable_condition_gene_nbinomTest$dtalbe[gene_list, 'pval'], 
                              diff_fpkm = std_diff_test_res[gene_list, 'pval'], 
                              diff_DESeq2 = as.data.frame(std_DESeq_res)[gene_list, ]$'pvalue', 
                              diff_scde = std_scde_res_list$pval[gene_list]) 
      else {
        pval_df <- input_pval_df[gene_list, ]
        print(pval_df[1:10, ])
        message('the dimensions of pval_df are: ') 
        print(dim(pval_df))
      }
    }
    
    pval_df[is.na(pval_df)] <- 1
    cpr_DEG_test <- compare_DEG_test(pval_df, true_data, return_plot = F) #make roc curves   
    mlt_roc_df <- cpr_DEG_test$mlt_roc_df 
    mlt_roc_df$thrsld <- p_thrsld
    
    mlt_gene_num <- cpr_DEG_test$mlt_gene_num
    mlt_gene_num$thrsld <- p_thrsld
    
    cb_mlt_roc_df <- rbind(cb_mlt_roc_df, mlt_roc_df)
    cb_mlt_gene_num <- rbind(cb_mlt_gene_num, mlt_gene_num)
  }
  cpr_DEG_test$cb_mlt_roc_df <- cb_mlt_roc_df
  cpr_DEG_test$cb_mlt_gene_num <- cb_mlt_gene_num
  
  assign(paste(data_type, '_', golden_std_type, '_cpr_DEG_test', sep = ''), cpr_DEG_test) #save the data
  
  #return the results from the analysis
  return(cpr_DEG_test)
}

#' goodness of fit tests based on different approaches (fitdist, glm, zeroinfl, hurdle)
#' 
#' @param obs Vector of gene expression value 
#' @param exprs_thrsld The lower limit of gene expression value 
#' @param pseudo_cnt the pseudocount added in the data for the purpose of data fitting
#' @param eps the machine precision requred for the fitdist function
#' @export
#'  
gd_fit_pval <- function(obs, exprs_thrsld, pseudo_cnt, eps = sqrt(.Machine$double.eps)) { #nrow(absolute_cds)
  #exprs_cell_num <- c(sum(std_obs > 0), sum(abs_obs > 0), sum(mc_obs > 0))
  
  if(sum(obs > 0, na.rm = T) < exprs_thrsld) { #restrict to genes expressed at least 10 cells
    res <- c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
    names(res) <-  c("ln_pvalue", "nb_pvalue", "ln_pvalue.glm.link", "ln_pvalue.glm.log", "ln_pvalue.chisq", "nb_pvalue.glm",
                     "nb_pvalue.chisq", "zinb_pvalue.chisq", "zanb_pvalue.chisq", "zinb_pvalue", "zanb_pvalue")
    return(res)
  }
  
  uniq_cnt_lst <- sort(unique(as.numeric(round(obs + pseudo_cnt)))) #sort the counts
  uniq_len <- length(uniq_cnt_lst) #use for calulating the probability for the chisq.test
  
  #the following is prepared for dealing with runtime errors
  test_glm <- function() {
    tmp_ln <- fitdist(as.numeric(obs + pseudo_cnt), 'lnorm',
                      lower = c(eps, eps))
    ln_pvalue <- gofstat(tmp_ln)$chisqpvalue
    tmp_nb <- fitdist(as.numeric(round(obs + pseudo_cnt)), 'nbinom',
                      lower = c(eps, eps))#, start = list(size = exprs_abs[i, 200], mu = exprs_abs[i, 201]))
    nb_pvalue <- tryCatch({gofstat(tmp_nb)$chisqpvalue},
                          error = function(e) {
                            print(e);
                            NA
                          })
    
    #confirm the two approaches (fitdistr, glm with normal distribution) are the same
    log.glm <- glm(obs~1, family=gaussian(link = "log"), data=data.frame(obs  = obs + pseudo_cnt))
    log.y.glm <- glm(log(obs)~1, family=gaussian, data=data.frame(obs  = obs + pseudo_cnt))
    ln.lm <- lm(obs~1, data=data.frame(obs = log((obs + pseudo_cnt))))
    nb.glm <- glm.nb(obs ~ 1, data=data.frame(obs = round(obs + pseudo_cnt)))
    
    ln_pvalue.glm.link <- pchisq(deviance(log.glm), df.residual(log.glm), lower.tail  = F)
    ln_pvalue.glm.log <- pchisq(deviance(log.y.glm), df.residual(log.y.glm), lower.tail  = F)
    
    meanlog <- coef(ln.lm) #mapping log-normal
    sdlog <- sqrt(sum(residuals(ln.lm) ^2) / 198)
    
    add_2_lst <- 1 - sum(c(plnorm(uniq_cnt_lst[1], meanlog = meanlog, sdlog = sdlog),
                           diff(plnorm(uniq_cnt_lst, meanlog = meanlog, sdlog = sdlog))))
    ln.p <- c(plnorm(uniq_cnt_lst[1], meanlog = meanlog, sdlog = sdlog), #for continous variable, we need the area between neighboring sections
              diff(plnorm(uniq_cnt_lst, meanlog = meanlog, sdlog = sdlog)))
    ln.p[uniq_len] = ln.p[uniq_len] + add_2_lst
    ln_pvalue.chisq <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = ln.p, simulate.p.value = T, B = 9999)$p.value #?
    
    nb_pvalue.glm <- pchisq(deviance(nb.glm), df.residual(nb.glm), lower.tail  = F) #goodness of fit
    
    mu = exp(coef(nb.glm)) #intercept
    size = nb.glm$theta #mapping negative binomial
    nb.p <- c(dnbinom(uniq_cnt_lst[-1], mu = mu, size = size), 1 - sum(dnbinom(uniq_cnt_lst[-1], mu = mu, size = size)))
    nb_pvalue.chisq <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = nb.p, simulate.p.value = T, B = 9999)$p.value
    
    message('nb_pvalue.chisq is ', ln_pvalue.chisq)
    #other pvalues: nb_pvalue.glm.link_gd, nb_pvalue.glm.log_gd
    res <- c(ln_pvalue, nb_pvalue, ln_pvalue.glm.link, ln_pvalue.glm.log, ln_pvalue.chisq, nb_pvalue.glm, nb_pvalue.chisq)
    names(res) <- c("ln_pvalue", "nb_pvalue", "ln_pvalue.glm.link", "ln_pvalue.glm.log", "ln_pvalue.chisq", "nb_pvalue.glm",
                    "nb_pvalue.chisq")
    
    return(res)
  }
  test_zero_hurdle <- function() {
    zz <- zeroinfl(round(obs + pseudo_cnt)~1,dist="negbin")
    mu <- exp(coef(zz)[1])  ## mu
    theta <- zz$theta          ## theta
    zprob <- plogis(coef(zz)[2]) ## zprob
    prob = theta / (theta + mu)
    zin.p <- c(dzinegbin(uniq_cnt_lst[-1], prob = prob, size = theta, pstr0 = zprob),
               1 - sum(dzinegbin(uniq_cnt_lst[-1], prob = prob, size = theta, pstr0 = zprob)))
    zinb_pvalue.chisq <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = zin.p, simulate.p.value = T, B = 9999)$p.value
    
    zz <- hurdle(round(obs + pseudo_cnt)~1,dist="negbin")
    mu <- exp(coef(zz)[1])  ## mu
    theta <- zz$theta          ## theta
    zprob <- plogis(coef(zz)[2]) ## zprob
    prob = theta / (theta + mu)
    zan.p <- c(dzanegbin(uniq_cnt_lst[-1], prob = prob, size = theta, pobs = zprob),
               1 - sum(dzanegbin(uniq_cnt_lst[-1], prob = prob, size = theta, pobs0 = zprob)))
    zanb_pvalue.chisq <- chisq.test(as.vector(table(round(obs + pseudo_cnt))), p = zan.p, simulate.p.value = T, B = 9999)$p.value
    
    res <- c(zinb_pvalue.chisq, zanb_pvalue.chisq)
    names(res) <- c("zinb_pvalue.chisq", "zanb_pvalue.chisq")
    return(res)
  }
  test_zinb <- function() {
    tmp_zinb <- fitdist(round(as.numeric(obs + pseudo_cnt)), 'zinegbin',
                        lower = c(eps, eps, eps), upper = c(1, 1, Inf), start = list(prob = 0.13, pstr0 = 0.2, size = 0.15))
    zinb_pvalue <- gofstat(tmp_zinb)$chisqpvalue
    names(zinb_pvalue) <- "zinb_pvalue"
    
    return(zinb_pvalue)
  }
  
  test_zanb <- function() {
    tmp_zanb <- fitdist(round(as.numeric(obs + pseudo_cnt)), 'zanegbin',
                        lower = c(eps, eps, eps), upper = c(1, 1, Inf), start = list(prob = 0.13, pobs0 = 0.2, size = 0.15))
    
    zanb_pvalue <- gofstat(tmp_zanb)$chisqpvalue
    names(zanb_pvalue) <- "zanb_pvalue"
    
    return(zanb_pvalue)
  }
  
  #use tryCatch
  glm_res <- tryCatch({test_glm()},
                      error = function(e) {
                        print (e);
                        return(c(ln_pvalue = NA, nb_pvalue = NA, ln_pvalue.glm.link = NA, ln_pvalue.glm.log = NA, ln_pvalue.chisq = NA, nb_pvalue.glm = NA,
                                 nb_pvalue.chisq = NA))
                      })
  zero_hurdle_res <- tryCatch({test_zero_hurdle()},
                              error = function(e) {
                                print(e);
                                return(c(zinb_pvalue.chisq = NA, zanb_pvalue.chisq = NA))
                              })
  zinb_res <- tryCatch({test_zinb()},
                       error = function(e) {
                         print(e);
                         return(c(zinb_pvalue = NA))
                       })
  zanb_res <- tryCatch({test_zanb()},
                       error = function(e) {
                         print(e);
                         return(c(zanb_pvalue = NA))
                       })
  
  res_all <- c(glm_res, zero_hurdle_res, zinb_res, zanb_res)
  
  return(res_all)
  
  #vglm fitting
  #       zinb.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "zinegbinomial")
  #       zanb.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "zanegbinomial")
  #       mu <- exp(coef(zinb.vglm)[2])
  #       theta <- exp(coef(zib.vglm)[3])
  #       zprob <- plogis(coef(zinb.vglm)[1])
  #test the fitting of tobit model: 
  tobit.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "tobit")
  pchisq(logLik(tobit.vglm), df.residual(tobit.vglm), lower.tail  = F)
}

#the following function can be used to calculate the parameters for the zero-inflated negative binomial distribution
test_zero_hurdle <- function(obs) {
  zz <- zeroinfl(round(obs)~1,dist="negbin") 
  mu <- exp(coef(zz)[1])  ## mu 
  theta <- zz$theta          ## theta 
  zprob <- plogis(coef(zz)[2]) ## zprob
  prob = theta / (theta + mu) 
  aic <- AIC(zz)
  
  bic <- -2 * logLik(zz) + 3 * log(length(obs)) # -2 * logLik + k * log(N)
  
  # test <- vglm(round(obs) ~ 1, family = zinegbinomial())
  # pred <- predict(test)[1, ]
  # vglm_zprob <- inv.logit(pred[1])
  # vglm_mu <- exp(pred[2])
  # vglm_size <- exp(pred[3])
  
  # return(list(mu = mu, theta = theta, zprob = zprob, vglm_mu = vglm_mu, vglm_theta = vglm_size, vglm_zprob = vglm_zprob))
  return(list(mu = mu, theta = theta, zprob = zprob, aic = aic, bic = bic))
  #using vglm: 
}

#' code for plots the mc_optimzation and the spikein optimization 
#' @export
abs_mc_gene_correltion <- function(absolute_cds, mc_cds, gene_ids) {
  abs_gene <- as.vector(exprs(absolute_cds)[gene_ids, ])
  mc_gene <- as.vector(exrps(mc_cds)[gene_ids, ])
  ERCC_mc <- as.vector(exprs(mc_cds)[gene_ids, ])
  gene_df <- data.frame(abs_gene = ERCC_spike, mc_gene = ERCC_mc, 
                        time = rep(pData(absolute_cds)[, 'Time'],  time = ercc_num), 
                        gene = rep(gene_ids, time = ncol(absolute_cds)))
  
  p1 <- 
    qplot(ercc_spike + 1, ercc_mc + 1, color = time, data = ercc_df, log = "xy", alpha = I(.3)) + 
    geom_smooth(method = "rlm", color = "red", se = T) + 
    #geom_smooth(method = "loess", color = "black", se = F) + 
    xlab("ERCC spike in count") + ylab("ERRCC spike in count based on the mc") + 
    monocle_theme_opts() + facet_wrap(~time, scale = 'free') + geom_abline(color = 'blue', slope = 1)
  
  melt_gene_df <- melt(gene_df)
  
  #show distribution of each gene by different normalization 
  p2 <- 
    ggplot(data = melt_gene_df) + geom_histogram(aes(x = value, fill = variable), alpha = 0.7, binwidth = 1) + 
    facet_wrap(~gene, scale = 'free') + monocle_theme_opts()
  
  return(list(gene_df, p1, p2))
} 

#' this code is used to compare the unique DEGs from two different DEG tests
#' @export
plot_sample_mc_abs_uniq <- function(set1 = names(round_mc_permutate_pval_vec[round_mc_permutate_pval_vec <= p_thrsld]), 
                                    set2 = names(round_abs_permutate_pval_vec[round_abs_permutate_pval_vec <= p_thrsld]), n = 10) {
  uniq_set1 <- setdiff(set1, set2)
  uniq_set2 <- setdiff(set2, set1)
  
  sample_set1 <- sample(uniq_set1, n = 10)
  sample_set2 <- sample(uniq_set2, n = 10)
  
  plot_genes(c(sample_set1, 'mc'))
  plot_genes(c(sample_set2, 'abs'))
}

sample_p <- function(x, type, p_thrsld = 0.05, n = 12, lower = 0.3, upper = 0.4) {
  if(type == 'Neg') {
    Neg <- names(x[x > p_thrsld])
    sample_genes <- sample(Neg[!is.na(Neg)], size = n)
  }
  else if(type == 'Pos') {
    Pos <- names(x[x < p_thrsld])
    sample_genes <- sample(Pos[!is.na(Pos)], size = n)
  }
  else if(type == 'Range') {
    Range <- names(x[x < upper & x > lower])
    sample_genes <- sample(Range[!is.na(Range)], size = n)
  }
}

#' Function to calculate precision and recall
#' @param est_pval The pval calculated from the differential gene test 
#' @param true_pval The permutation pval used as the gold standard
#' @param type Type of data to be calculated, either precision or recall 
#' @param q_thrsld The threshold to determine whether or not a gene is a significant gene
#' @export

# precision_recall_cal <- function(est_pval, true_pval, type = c('precision', 'recall'), q_thrsld = 0.1){
#   qval <- p.adjust(est_pval, method = 'BH')
#   names(qval) <- names(est_pval)
#   true_qval <- p.adjust(true_pval, method = 'BH')
#   
#   fp <- setdiff(names(qval[qval <= q_thrsld]), names(true_pval[true_qval <= q_thrsld])) #false positive
#   tp <- intersect(names(qval[qval <= q_thrsld]), names(true_qval[true_qval <= q_thrsld])) #true positive
#   fn <- setdiff(names(qval[qval > q_thrsld]), names(true_qval[true_qval > q_thrsld]))
#   
#   if(type == 'precision') length(tp) / length(union(fp, tp)) #precision = tp / (tp + fp)
#   else if(type =='recall') length(tp) / length(union(tp, fn)) #precision = tp / (tp + fn)
# }

precision_recall_cal <- function (est_pval, true_pval, type = c("precision", "recall"),
                                  q_thrsld = 0.1){
  qval <- p.adjust(est_pval, method = "BH")
  names(qval) <- names(est_pval)
  true_qval <- p.adjust(true_pval, method = "BH")
  fp <- setdiff(names(qval[qval <= q_thrsld]), names(true_pval[true_qval <= q_thrsld]))
  tp <- intersect(names(qval[qval <= q_thrsld]), names(true_qval[true_qval <= q_thrsld]))
  fn <- setdiff(names(qval[qval > q_thrsld]), names(true_qval[true_qval > q_thrsld]))
  if (type == "precision")
    length(tp)/length(union(fp, tp))
  else if (type == "recall")
    length(tp)/length(union(tp, fn))
}

#' Convert read count to TPM 
#' @param counts Readcounts for the gene 
#' @param The effective length of a gene
#' @export
#' 
countToTpm <- function(counts, effLen)
{
  rate <- log(counts) - log(effLen)
  denom <- log(sum(exp(rate)))
  exp(rate - denom + log(1e6))
}

#' Convert read count to FPKM  
#' @param counts Readcounts for the gene 
#' @param The effective length of a gene
#' 
countToFpkm <- function(counts, effLen)
{
  N <- sum(counts)
  exp( log(counts) + log(1e9) - log(effLen) - log(N) )
}

#' Convert FPKM to TPM  
#' @param fpkm FPKM value for the gene 
#' @export
#' 
fpkmToTpm <- function(fpkm)
{
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}

#' Convert count to effectie counts  
#' @param counts Readcount value for the gene 
#' @param len Length of a gene 
#' @param effLen effective length for a gene
#' @export

countToEffCounts <- function(counts, len, effLen)
{
  counts * (len / effLen)
}

#' Function to ordering the cell based on different choices of genes 
#' 
#' @param cds CellDataframe used for performing the cell ordering 
#' @param type Type of gene list used for performing the ordering  
#' @param marker_gene_list A known list of marker genes for performing the ordering
#' @param thrsld Threshold to determine whether or not a gene expressed 
#' @param estimateSizeFactors A logic argument determining whether or not we should perform the differential gene test
#' @export
#' 
pseudo_ordering <- function(cds, type = c('diff_gene', 'pca', 'marker'), marker_gene_list = NULL, thrsld = .5, dim = 1, estimateSizeFactors = F){
  if(type == 'diff_gene'){
    fData(cds)$num_cells_expressed <- apply(exprs(cds), 1, function(x)  sum(x > thrsld))
    
    expressed_genes <- row.names(subset(fData(cds), num_cells_expressed >= 50))
    #, cores = detectCores() - 1, relative_expr = F
    if(estimateSizeFactors)
      test_res <- differentialGeneTest(cds[expressed_genes,   ], fullModelFormulaStr = "expression~Media",
                                       cores = detectCores() - 1, relative_expr = F)
    else 
      test_res <- differentialGeneTest(cds[expressed_genes,   ], fullModelFormulaStr = "expression~Media",
                                       cores = detectCores() - 1)
    ordering_genes <- row.names(subset(test_res, qval < 0.01))
    ordering_genes <- row.names(subset(test_res, qval < 0.1))
    ordering_genes <- intersect(ordering_genes, expressed_genes)
    
    cds <- cds[ordering_genes, ]
    cds_matrix <- exprs(cds)
    sample_sheet <-  pData(cds)
    gene_ann <- fData(cds) 
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = gene_ann)
    cds_2 <- newCellDataSet(cds_matrix, 
                            phenoData = pd, 
                            featureData = fd, 
                            expressionFamily=tobit(), #get around with the negbinomial distribution error
                            lowerDetectionLimit=.1)
  }
  else if(type == 'pca'){
    loading_genes <- pca_analysis(cds, dim_type = dim, scale = T, overlap = F, filter = T, num = 1000)
    cds <- cds[loading_genes, ]
    cds_matrix <- exprs(cds)
    sample_sheet <-  pData(cds)
    gene_ann <- fData(cds) 
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = gene_ann)
    cds_2 <- newCellDataSet(cds_matrix, 
                            phenoData = pd, 
                            featureData = fd, 
                            expressionFamily=tobit(), #get around with the negbinomial distribution error
                            lowerDetectionLimit=.1)
  }
  else if(type == 'marker'){
    cds <- cds[marker_gene_list, ]
    cds_matrix <- exprs(cds)
    sample_sheet <-  pData(cds)
    gene_ann <- fData(cds) 
    pd <- new("AnnotatedDataFrame", data = sample_sheet)
    fd <- new("AnnotatedDataFrame", data = gene_ann)
    cds_2 <- newCellDataSet(cds_matrix, 
                            phenoData = pd, 
                            featureData = fd, 
                            expressionFamily=tobit(), #get around with the negbinomial distribution error
                            lowerDetectionLimit=.1)
  }
  cds_2@expressionFamily <- tobit()
  
  if(estimateSizeFactors)
    cds_2 <- monocle::estimateSizeFactors(cds_2)
  # std_HSMM_2 <- setOrderingFilter(cds_2, ordering_genes)
  cds_2 <- reduceDimension(cds_2, use_irlba = F)
  cds_2 <- orderCells(cds_2, num_paths = 2, reverse = F)
  plot_spanning_tree(cds_2, color_by="State", show_backbone=T, show_cell_names = F)
  
  cds_2@expressionFamily <- negbinomial()
  return(cds_2)
}

#' Extract the highest loading genes from PCA analysis
#' 
#' @param cds CellDataFrame used for performing the PCA analysis
#' @param dim_type A index to decide which PCA component will be used, either component 1/2/3 when dim_type == 1 otherwise component 2/3/4 when dim_type == 2
#' @param num Number of genes to be extracted
#' @param filter A logic argument determing whether or not we need to filter the gene 
#' @param scale A logic argument determing whether or not we need to scale the data
#' @param overlap A logic argument determing whether or not we need to just use the overlapping genes 
#' @param gene_list The gene list to be compared with 
#' @param exprs_thrsld The threshold to determine whether or not a gene is expressed
#' @export
#' 
pca_analysis <- function(cds = absolute_cds, dim_type = c(2, 1), num = 1000, filter = F,
                         scale = T, overlap = F, gene_list = quake_gene_list[1:116], exprs_thrsld = 0.1) {
  if(dim_type == 1)
    dims = c(1, 2, 3)
  else if(dim_type == 2)
    dims = c(2, 3, 4)
  
  pcr_res <- princomp(exprs(cds))
  print(loadings(pcr_res)[, 1:3])
  
  # PCA analysis was performed on all cells using all genes
  # expressed in more than two cells and with a variance in transcript level (log2(FPKM))
  # across all single cells greater than 0.5.
  
  filter_genes <- function(cds) {
    fData(cds)$num_cell_exprs <- apply(exprs(cds), 1, function(x)  sum(x > exprs_thrsld))
    fData(cds)$variance <- apply(exprs(cds), 1, function(x)  var(x))
    
    cds <- cds[row.names(subset(fData(cds), num_cell_exprs > 2 & variance > 5)), ]
  }
  
  if(filter)
    cds <- filter_genes(cds)
  #prcomp is preferred becouse of numerical stability
  if(scale)
    pca.object <- prcomp(exprs(cds), center=TRUE, scale=TRUE)  # PCA with centering and scaling
  else
    pca.object <- prcomp(exprs(cds))  # PCA with centering and scaling
  pca.object$rotation  # The loadings are here
  
  #decide how many principal component to retain
  screeplot(pca.object, type="lines")
  #Kaiser’s criterion
  (pca.object$sdev)^2
  #decide the number of components need to consider based on the total variance explained 
  summary(pca.object)
  
  #pick highest loading genes: 
  comp2_gene <- names(sort(pca.object$x[, dims[1]], decreasing = F)[1:num])
  comp3_gene <- names(sort(pca.object$x[, dims[2]], decreasing = F)[1:num])
  comp4_gene <- names(sort(pca.object$x[, dims[3]], decreasing = F)[1:num])
  
  if(overlap)
    comp_all <- intersect(c(comp2_gene, comp3_gene), comp4_gene)
  else 
    comp_all <- unique(c(comp2_gene, comp3_gene, comp4_gene))
  print(gene_list %in% comp_all)
  print(sum(gene_list %in% comp_all))
  
  loading_gene_names <- fData(cds[comp_all, ])$gene_short_name
  
  qplot(log10(pca.object$x[, 1]), log10(pca.object$x[, 2]))
  
  return(comp_all)
}

#' use modified glm.perm package to perform the pseudotime / branch permutation tests (depend on hack_glm_perm.R)
#'
#' @param cds 
#' @param full_model
#' @param var The character vector indicating the columns used for performing the permutation test 
#' @param perm_num Number of permutations
#' @export
#'
cal_glm_perm <- function(cds = standard_cds, full_model = "expression~ns(time, df =3)",
                         var = c('ns(time, df = 3)1', 'ns(time, df = 3)2', 'ns(time, df = 3)3'), perm_num = 10000) {
  split_df <- split(t(exprs(cds)), col(t(exprs(cds)), as.factor = T))
  glm_perm_res <-
    mclapply(split_df, function(x, time = pData(cds)$Pseudotime, State = pData(cds)$State, nrep = perm_num){
      test_df <- data.frame(expression = round(x), time =  time, State = State)
      
      tmp <- tryCatch(tmp <- {prr.test(full_model, var = var, family =
                                         negative.binomial(theta = mean(test_df$expression)), data = test_df, nrep = nrep)},
                      error = function(e){
                        print(e);
                        NA}
      )
      
      if(!is.na(tmp[1]))
        pval <- unlist(tmp$p.value.perm)[2:6]
      else
        pval <- c(NA, NA, NA, NA, NA)
    }, mc.cores = detectCores())
  return(glm_perm_res)
}

#use glm.perm package for the branch permutation test:
#To do: 
##do the branchTest based on Pseudotime * State (check State)

cal_glm_perm_branch <- function(cds = standard_cds) {
  split_df <- split(t(exprs(cds)), col(t(exprs(cds)), as.factor = T))
  glm_perm_res <- 
    mclapply(split_df, function(x, time = Pseudotime){
      test_df <- data.frame(expression = round(x), time =  time, State = State)
      
      tmp <- tryCatch(tmp <- {prr.test("expression~ time + State", var = 'State', family = 
                                         negative.binomial(theta = mean(test_df$expression)), data = test_df)},
                      error = function(e){
                        print(e);
                        NA}
      )
      
      if(!is.na(tmp[1]))
        pval <- unlist(tmp$p.value.perm)[2:6]
      else
        pval <- c(NA, NA, NA, NA, NA) 
      
    }, mc.cores = detectCores())
  
  return(glm_perm_res)
}

#' this helper function is used to calculate the AIC/BIC for different distribution fitting
#' 
#' @param obs The gene expression value 
#' @param pseudo_cnt Pseudotime count add to the gene expression for the purpose of fitting
#' @export
#' 
vglm_fit_helper <- function(obs = obs, pseudo_cnt = pseudo_cnt) {
  vglm(obs~1, data=data.frame(obs  = ((obs) + pseudo_cnt)), family = "lognormal")
  ln.vglm = vglm(obs~1, data=data.frame(obs  = ((obs) + pseudo_cnt)), family = "lognormal")
  nb.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "negbinomial")
  #zinb.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "zinegbinomial")
  zinb.vglm = zeroinfl(obs~1, data = data.frame(obs  = round((obs) + pseudo_cnt)), dist = "negbin")
  #zanb.vglm = vglm(obs~1, data=data.frame(obs  = round((obs) + pseudo_cnt)), family = "zanegbinomial")
  zanb.vglm = hurdle(obs~1, data = data.frame(obs  = round((obs) + pseudo_cnt)), dist = "negbin")
  
  ln.aic[i] <- AIC(ln.vglm)
  ln.bic[i] <- BIC(ln.vglm)
  nb.aic[i] <- AIC(nb.vglm)
  nb.bic[i] <- BIC(nb.vglm)
  zinb.aic[i] <- AIC(zinb.vglm)
  zinb.bic[i] <- BIC(zinb.vglm)
  zanb.aic[i] <- AIC(zanb.vglm)
  zanb.bic[i] <- BIC(zanb.vglm)
  return(data.frame(ln.aic = ln.aic, ln.bic = ln.bic, nb.aic = nb.aic, nb.bic = nb.bic, 
                    zinb.aic = zinb.aic, zanb.aic = zanb.aic, zanb.aic = zanb.aic, zanb.bic = zanb.bic))          
}

#' function to calculate the AIC/BIC for different distributions 
#' @param exprs_abs The data.frame for the expression value 
#' @param pseudo_cnt The Pseudocount added into the expression matrix
#' @export
#' 
cal_AIC_BIC <- function(exprs_abs = exprs(absolute_cds), pseudo_cnt = 0.01) {
  #calculate the AIC/BIC: 
  ln.aic = rep(0, nrow(exprs_abs))
  ln.bic = rep(0, nrow(exprs_abs))
  nb.aic = rep(0, nrow(exprs_abs))
  nb.bic = rep(0, nrow(exprs_abs))
  
  zinb.aic = rep(0, nrow(exprs_abs))
  zinb.bic = rep(0, nrow(exprs_abs))
  zanb.aic = rep(0, nrow(exprs_abs))
  zanb.bic = rep(0, nrow(exprs_abs))
  
  apply(exprs_abs, 1, function(x){
    obs <- as.numeric(exprs_abs[i, ])
    if(sum(obs) < 199 & length(which(exprs(standard_cds)[i, ] > 1)) < 50) {
      print(i)
      #next #only expressed genes
    }
    res <- tryCatch({vglm_fit}, 
                    error = function(e){
                      print(e);
                      return(data.frame(ln.aic = NA, ln.bic = NA, nb.aic = NA, nb.bic = NA, 
                                        zinb.aic = NA, zanb.aic = NA, zanb.aic = NA, zanb.bic = NA))
                    })
  }) 
}

makeprobsvec<-function(p){
  phat<-p/sum(p)
  phat[is.na(phat)] = 0
  phat
}

shannon.entropy <- function(p) {
  if (min(p) < 0 || sum(p) <=0)
    return(Inf)
  p.norm<-p[p>0]/sum(p)
  -sum( log10(p.norm)*p.norm)
}

makeprobs<-function(a){
  colSums<-apply(a,2,sum)
  b<-t(t(a)/colSums)
  b[is.na(b)] = 0
  b
}

#' the following code is used to calculate the JSD (This function is based on functions: makeprobsvec, shannon.entropy and makeprobs)
#'
#' @param p, q two distributions
#' @export

JSdistVec<-function(p,q){
  # non_zero <- p > 0 && q > 0
  #   p <- p[non_zero]
  #   q <- q[non_zero]
  #
  JSdiv<-shannon.entropy((p+q)/2)-(shannon.entropy(p)+shannon.entropy(q))*0.5
  #print(JSdiv)
  JSdiv[is.infinite(JSdiv)] <- 1
  JSdiv[JSdiv < 0] <- 0
  
  JSdist<-sqrt(JSdiv)
  JSdist
}

#' the following code is used to calculate the JSD between each column of data (This function is based on functions: makeprobsvec, shannon.entropy and makeprobs)
#'
#' @param p, q two distributions
#' @export

pairwiseJSdist <- function(matrix1) {
  JS <- apply(matrix1,2,function(x){
    apply(matrix1,2,JSdistVec,x)
  })
  
  min_JS <- min(rowMins(JS[JS > 0]))
  JS[JS == 0] <- min_JS
  diag(JS) <- 0
}

#' A function to make readcount 
#' @param dir The directory for the readcount data 
#' @param cds CellDataframe used to provide the phenotype data
#' @export
#' 
make_readcount <- function(dir, cds) {
  norm_count <- read.delim(paste(dir, "/genes.count_table", sep = ''))
  norm_count <- norm_count[, -1]
  
  sample_sheet <- read.delim(paste(dir, "/samples.table", sep = ''))
  row.names(sample_sheet) <- as.vector(sample_sheet$sample_id)
  
  norm_count <- norm_count[, row.names(sample_sheet)]
  read_countdata <- round(t(t(norm_count) * sample_sheet$internal_scale)) #convert back to the raw counts
  read_countdata <- read_countdata[, colnames(cds)]
  
  read_cds <- newCellDataSet(read_countdata,
                             phenoData = new("AnnotatedDataFrame", data = pData(cds)),
                             featureData = new("AnnotatedDataFrame", data = fData(cds)),
                             expressionFamily=negbinomial(),
                             lowerDetectionLimit=.1)
  
  return(read_cds)
}

#' function to make a cds object
#' 
#' @param exprs_matrix The gene expression matrix
#' @param pd The phenotype information data.frame
#' @param fd The gene feature information
#' @param expressionFamily The distribution for the data
#' @export
#' 
make_cds <- function(exprs_matrix, pd, fd, expressionFamily) {
  cds <- newCellDataSet(exprs_matrix, 
                        phenoData = new("AnnotatedDataFrame", data = pd), 
                        featureData = new("AnnotatedDataFrame", data = fd), 
                        expressionFamily=expressionFamily, 
                        lowerDetectionLimit=.1)
  return(cds)
}

#' append the object in the .RData file
#' 
#' @param robj The R object
#' @param filename The .RData file for appending the R object
#' @export
#' 
appendRData <- function(robj, filename = 'muscle_analysis.RData') { 
  
  tmpEnv <- new.env() 
  
  savedObjects <- load(filename, envir = tmpEnv) 
  
  # quick check for name collisions 
  stopifnot(!(deparse(substitute(robj)) %in% savedObjects)) 
  
  save(list = c(savedObjects, deparse(substitute(robj))), 
       file = filename, 
       envir = tmpEnv) 
} 

#' test the all other DEG results: 
#' @export

all_other_DEG   <- function(cds, read_count_d = NULL, type = c('absolute', 'relative'), 
                            Time = pData(cds)$Media, contrast = c("DM", "GM"), full_model = 'expression~Media') {
  if(type == 'relative') 
    scale = F
  else 
    scale = T
  
  # dtable_condition_gene_nbinomTest <- DESeq1_test(count_d, contrast = contrast, disp_method = 'per-condition', sharing = 'gene-est-only', test_type = 'nbinomTest', scale = F) 
  # row.names(dtable_condition_gene_nbinomTest$dtalbe) <- dtable_condition_gene_nbinomTest$dtalbe$id
  count_d <- newCountDataSet(round(exprs(cds))[, ], (Time)) 
  dtable_blind_fit_nbinomTest <- DESeq1_test(count_d, contrast = contrast, disp_method = 'blind', sharing = 'fit-only', test_type = 'nbinomTest', scale = scale) 
  
  row.names(dtable_blind_fit_nbinomTest$dtalbe) <- dtable_blind_fit_nbinomTest$dtalbe$id
  
  ori_diff_test_res <- differentialGeneTest(cds[, ], 
                                            fullModelFormulaStr = full_model, 
                                            reducedModelFormulaStr = "expression~1", cores = detectCores())
  
  
  # ori_diff_test_res <- differentialGeneTest(absolute_cds[1:20, ], 
  #                                              fullModelFormulaStr = full_model, 
  #                                              reducedModelFormulaStr = "expression~1", cores = 1)
  #test the custom_DEG_update on the cluster with muscle data: 
  # test <- cos_differentialGeneTest(std_HSMM_myo[1:1000, ], fullModelFormulaStr = 'expression~Media',
  #                       cell_wise_size = T,fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only')
  
  if(type == 'relative'){
    #zero 1/2: specify mean or sd intercept only  
    cds@expressionFamily <- tobit(zero = NULL)
    ori_diff_test_res_zero_null <- differentialGeneTest(cds[, ], 
                                                        fullModelFormulaStr = full_model, #log10(Total_mRNAs) + spike_total_mRNAs
                                                        reducedModelFormulaStr = "expression~1", cores = detectCores())
    cds@expressionFamily <- tobit()
  }
  else if(type == 'absolute') {
    #zero 2/-2: specify mean or variance intercept only  
    cds@expressionFamily <- negbinomial(zero = NULL)
    ori_diff_test_res_zero_null <- differentialGeneTest(cds[, ], 
                                                        fullModelFormulaStr = full_model, #log10(Total_mRNAs) + spike_total_mRNAs
                                                        reducedModelFormulaStr = "expression~1", cores = detectCores())
    cds@expressionFamily <- negbinomial()
  }
  
  #different normalization approaches with total RNA: 
  if(type == 'absolute') { 
    ini_diff_test_res <- cos_differentialGeneTest((cds[, ]), 
                                                  cell_wise_size = F, fitType = 'initial', disp_method = 'blind', disp_sharing = 'fit-only',
                                                  fullModelFormulaStr = "expression~Time", 
                                                  reducedModelFormulaStr = "expression~1", cores = detectCores())
    fix_diff_test_res <- cos_differentialGeneTest((cds[, ]), 
                                                  cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                  fullModelFormulaStr = full_model, 
                                                  reducedModelFormulaStr = "expression~1", cores = detectCores())
    
    diff_test_res_times_total_RNA <- cos_differentialGeneTest((cds[, ]),
                                                              cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                              fullModelFormulaStr =  paste(full_model, " * Total_mRNAs"), #log10(Total_mRNAs) + spike_total_mRNAs
                                                              reducedModelFormulaStr = "expression~ Total_mRNAs", cores = detectCores())
    diff_test_res_times_total_log10_RNA <- cos_differentialGeneTest(cds[, ],
                                                                    cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                                    fullModelFormulaStr = paste(full_model, " * Total_mRNAs"), #log10(Total_mRNAs) + spike_total_mRNAs
                                                                    reducedModelFormulaStr = "expression~ Total_mRNAs", cores = detectCores())
    diff_test_res_total_RNA <- cos_differentialGeneTest(cds[, ],
                                                        cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                        fullModelFormulaStr = paste(full_model, " * Total_mRNAs"), #log10(Total_mRNAs) + spike_total_mRNAs
                                                        reducedModelFormulaStr = "expression~ Total_mRNAs", cores = detectCores())
    diff_test_res_total_log10_RNA <- cos_differentialGeneTest(cds[, ],
                                                              cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                              fullModelFormulaStr = paste(full_model, " * Total_mRNAs"), #log10(Total_mRNAs) + spike_total_mRNAs
                                                              reducedModelFormulaStr = "expression ~ log10(Total_mRNAs)", cores = detectCores())
    
    #different normalization approaches: normalization with geometric mean and normalization with size factors  
    d <- estimateSizeFactors(count_d)
    geom_mean_total <- exp(mean(log(colSums(exprs(cds)))))
    
    geom_norm_mat <- t(t(exprs(cds)) / colSums(exprs(cds))) * geom_mean_total
    geom_norm_cds <- newCellDataSet(geom_norm_mat, 
                                    phenoData = new("AnnotatedDataFrame", data = pData(cds)), 
                                    featureData = new("AnnotatedDataFrame", data = fData(cds)), 
                                    expressionFamily=negbinomial(), 
                                    lowerDetectionLimit=.1)
    size_norm_mat <- t(t(exprs(cds)) / pData(d)$sizeFactor)
    size_norm_cds <- newCellDataSet(size_norm_mat, 
                                    phenoData = new("AnnotatedDataFrame", data = pData(cds)), 
                                    featureData = new("AnnotatedDataFrame", data = fData(cds)),
                                    expressionFamily=negbinomial(), 
                                    lowerDetectionLimit=.1)
    
    norm_diff_test_res <- cos_differentialGeneTest((geom_norm_cds[, ]),
                                                   cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                   fullModelFormulaStr = full_model, 
                                                   reducedModelFormulaStr = "expression~1", cores = detectCores())
    
    size_norm_diff_test_res <- cos_differentialGeneTest((size_norm_cds[, ]), 
                                                        cell_wise_size = F, fitType = 'fix-size', disp_method = 'blind', disp_sharing = 'fit-only',
                                                        fullModelFormulaStr = full_model, 
                                                        reducedModelFormulaStr = "expression~1", cores = detectCores())
  }
  
  #SCDE / DESEq2
  #  if(type == 'absolute') {
  # #scde_res_list <- scde_DEG(dir = NULL, count_cds = cds[, ], DEG_attribute = 'Time', contrast = scde_contrast, n.cores = detectCores())
  # DEGSeq2_res_cds <- DESeq2_deg(dir = NULL, cds = cds[, ], pd = pData(cds))
  # DESeq_res <- DESeq2::results(DEGSeq2_res_cds) #, name = 'Time_T24_CT_0_vs_T0_CT_0'
  #  }
  #  else if(type == 'relative') {
  #    if(is.null(read_count_d))
  #      stop('If type == relative, read_count_d has to be provided')
  # #scde_res_list <- scde_DEG(dir = NULL, count_cds = read_count_d[, ], DEG_attribute = 'Time', contrast = scde_contrast, n.cores = detectCores())
  #    DEGSeq2_res_cds <- DESeq2_deg(dir = NULL, cds = read_count_d[, ], pd = pData(read_count_d))
  #    DESeq_res <- DESeq2::results(DEGSeq2_res_cds) #, name = 'Time_T24_CT_0_vs_T0_CT_0'
  #  }
  #fix this:
  DEGSeq2_res_cds <- NA 
  DESeq_res <- NA
  #other normalization approaches? 
  if(type == 'absolute')
    return(list(ori_diff_test_res, ini_diff_test_res, fix_diff_test_res, ori_diff_test_res_zero_null, diff_test_res_times_total_RNA, 
                diff_test_res_times_total_log10_RNA, diff_test_res_times_total_log10_RNA, diff_test_res_total_RNA, 
                diff_test_res_total_log10_RNA, norm_diff_test_res, size_norm_diff_test_res, 
                #scde_res_list, 
                DEGSeq2_res_cds, DESeq_res))
  else(type == 'relative')
  return(list(ori_diff_test_res, ori_diff_test_res_zero_null,
              # scde_res_list, 
              DEGSeq2_res_cds, DESeq_res))
}

#' function to perform the two group permutation test after size normalization 
#' 
#' @param cds CellDataFrame used to perform the permutation test
#' @export
#' 
cal_perm_pval_size_norm <- function(cds = new_abs_cds_14_18_2, alpha = sum(pData(cds_size_norm_cds)$Time == 'E14.5'),
                                    beta = sum(pData(cds_size_norm_cds)$Time == 'E18.5'), 
                                    grp0 = 'E14.5', grp1 = 'E18.5', group = pData(cds_size_norm_cds)$Time, size_norm = T){
  if(size_norm){
    cds_norm_mat <- t(t(round(exprs(cds))) / sizeFactors(cds))
  }
  else cds_norm_mat = round(exprs(cds))
  cds_size_norm_cds <- newCellDataSet(cds_norm_mat, 
                                      phenoData = new("AnnotatedDataFrame", data = pData(cds)), 
                                      featureData = new("AnnotatedDataFrame", data = fData(cds)),
                                      expressionFamily=negbinomial(), 
                                      lowerDetectionLimit=.1)
  
  size_norm_permutate_pval <- permu_two_group_gen(cds_size_norm_cds[, ], round = T, 
                                                  alpha = alpha,
                                                  beta = beta, 
                                                  grp0 = grp0, grp1 = grp1, group = group)
  
  return(size_norm_permutate_pval)
}
#' function to perform the two group permutation test
#' @param cds The CellDataFrame used to perform the permutation test
#' @param alpha Nnumber of cell for condition 1 
#' @param beta Nnumber of cell for condition 2
#' @param round A logic variable to determine whether or not the expression value should be rounded 
#' @param grp0 Name for group 1 
#' @param grp1 Name for group 2
#' @param group The group assignment for each cell
#' @export
#'  
permu_two_group_gen <- function(cds, alpha = sum(pData(cds)$Media == 'GM'),
                                beta = sum(pData(cds)$Media == 'DM'), round = F,
                                grp0 = 'GM', grp1 = 'DM',
                                group = pData(cds)$Media){
  if(ncol(cds) != alpha + beta)
    stop("The dimension of cds doesn't match the permutation setting") 
  
  split_cds <- split(t(round(exprs(cds[, ]))), col(t(exprs(cds[, ])), as.factor = T))
  
  fc <- esApply(cds[, ], 1, mean_fc, round = round, grp0 = grp0, grp1 = grp1, grp = group)
  
  split_fc <- split(t(fc), col(t(fc), as.factor = T))
  
  round_permutate_pval <- mcmapply(permuation_pval, split_cds, split_fc, alpha = alpha, beta =  beta, mc.cores = detectCores()) #multiple cores 
  
  round_permutate_pval_vec <- unlist(lapply(round_permutate_pval, function(x) x[[1]]))
  return(round_permutate_pval_vec)
}

#' hypergeometric enrichments for hclust data
#' 
#' @param clust A cluster object obtained from the pheatmap
#' @param gsc The result from runGSA
#' @param cds CellDataframe used for performing the hypergeometric test on each cluster
#' @param tree_num number of clusters cutted for performing the hypergeometric test
#' @export
#' 
hyper_hclust <- function(clust = cluster, gsc, cds = absolute_cds, tree_num = 2) {
  tree_grp <- cutree(clust$tree_row, tree_num)
  gene_universe <- unique(as.character(fData(cds[valid_gene_id_cell, ])$gene_short_name))
  gsa_results <- list()
  for(i in 1:max(tree_grp)) {
    cluster_genes <- names(tree_grp[tree_grp == i])
    gsaRes <- runGSAhyper(cluster_genes, gsc=gsc, universe=gene_universe)
    gsa_results[[length(gsa_results) + 1]] <- gsaRes
  }
  names(gsa_results) <- paste('class_', 1:max(tree_grp), sep = '')
  gsa_results
}

#' function to make a dataframe for the enrichment 
#' 
#' @param gsaRes The result from the runGAS 
#' @param extract_num Number of enriched terms to extract
#' @param custom_p_adjust A logic argument to determine whether or not we should perform the pval adjustment after separating the potential AT1/AT2 terms 
#' @param add_terms A logic argument to determine whether or not we should add significant terms relevant to "respiration" or "secretion"
#' @export
#' 
make_enrichment_df <- function (gsa_res = gsaRes_reactome_instant_log_ratio, gene_num = 10,
                                custom_p_adjust = F, add_terms = F, direction = T, select_top_stats = F) {
  enrich_data <- GSAsummaryTable(gsa_res)
  if(direction) {
    AT1_ids <- grep(enrich_data[, 1], pattern = "^RESPI")
    AT2_ids <- grep(enrich_data[, 1], pattern = "SECRETORY")
    if (custom_p_adjust) {
      up_data <- enrich_data[which(enrich_data$"p (dist.dir.up)" <
                                     0.05), ]
      up_data$"p adj (dist.dir.up)" <- p.adjust(up_data$"p (dist.dir.up)",
                                                method = "BH")
      down_data <- enrich_data[which(enrich_data$"p (dist.dir.dn)" <
                                       0.05), ]
      down_data$"p adj (dist.dir.dn)" <- p.adjust(down_data$"p (dist.dir.dn)",
                                                  method = "BH")
      print(paste("number of significant AT2 genes is", nrow(down_data[which(down_data$"p adj (dist.dir.dn)" <
                                                                               0.1), ])))
      up_data <- enrich_data[which(enrich_data$"p adj (dist.dir.up)" <
                                     0.05), ]
      down_data <- enrich_data[which(enrich_data$"p (dist.dir.dn)" <
                                       0.05), ]
      up_ids <- which(enrich_data$"p adj (dist.dir.up)" < 0.1)
      down_ids <- which(enrich_data$"p adj (dist.dir.down)" <
                          0.1)
    }
    else {
      up_data <- enrich_data[which(enrich_data$"p (dist.dir.up)" < 0.05), ]
      message(paste("number of significant AT1 genes is", nrow(up_data)))
      
      down_data <- enrich_data[which(enrich_data$"p (dist.dir.dn)" < 0.05), ]
      message(paste("number of significant AT2 genes is", nrow(down_data)))
      
      up_ids <- which(enrich_data$"p (dist.dir.up)" < 0.05)
      down_ids <- which(enrich_data$"p (dist.dir.down)" < 0.05)
    }
    if(select_top_stats) {
      # up_data <- up_data[which(enrich_data$"p (dist.dir.up)" < 0.05), ]
      # down_data <- down_data[which(enrich_data$"p (dist.dir.dn)" < 0.05), ]
      
      if(!is.null(up_data$"Stat (dist.dir.up)"))
        up_data$stat <- log(up_data$"Stat (dist.dir.up)")
      else
        up_data$stat <- (up_data$"Stat (dist.dir)")         
      if(!is.null(down_data$"Stat (dist.dir.dn)"))
        down_data$stat <- log(down_data$"Stat (dist.dir.up)")
      else
        down_data$stat <- log(down_data$"Stat (dist.dir)")   
      
      up_data <- up_data[sort(as.vector(up_data$stat),
                              index.return = T)$ix, ]
      down_data <- down_data[sort(as.vector(down_data$stat),
                                  index.return = T)$ix, ]
      down_data$stat <- - down_data$stat
      
      up_data <- up_data[1:gene_num, ]
      down_data <- down_data[1:gene_num, ]
      
      if (add_terms)
        up_data <- rbind(up_data, enrich_data[intersect(AT1_ids,
                                                        up_ids), ])
      up_data$colour <- "#BD1C7C"
      up_data$hjust <- 1.3
      
      if (add_terms)
        down_data <- rbind(down_data, enrich_data[intersect(AT2_ids,
                                                            up_ids), ])
      down_data$colour <- "#337DB9"
      down_data$hjust <- -0.3
    }
    
    else {
      up_data <- up_data[sort(as.vector(up_data$"p adj (dist.dir.up)"),
                              index.return = T)$ix, ]
      down_data <- down_data[sort(as.vector(down_data$"p (dist.dir.dn)"),
                                  index.return = T)$ix, ]
      up_data <- up_data[1:gene_num, ]
      if (add_terms)
        up_data <- rbind(up_data, enrich_data[intersect(AT1_ids,
                                                        up_ids), ])
      up_data$colour <- "#BD1C7C"
      up_data$hjust <- 1.3
      
      if(!is.null(up_data$"Stat (dist.dir.up)"))
        up_data$stat <- log(up_data$"Stat (dist.dir.up)")
      else
        up_data$stat <- (up_data$"Stat (dist.dir)")         
      if(!is.null(down_data$"Stat (dist.dir.dn)"))
        down_data$stat <- -log(down_data$"Stat (dist.dir.up)")
      else
        down_data$stat <- -log(down_data$"Stat (dist.dir)")   
      
      down_data <- down_data[1:gene_num, ]
      if (add_terms)
        down_data <- rbind(down_data, enrich_data[intersect(AT2_ids,
                                                            up_ids), ])
      down_data$colour <- "#337DB9"
      down_data$hjust <- -0.3
    }
    
    updown_data <- rbind(up_data, down_data)
    updown_data <- updown_data[!is.na(updown_data$stat), ]
    updown_data <- unique(updown_data)
    updown_data <- updown_data[sort(as.vector(updown_data$stat),
                                    index.return = T, decreasing = T)$ix, ]
    return(updown_data)
  }
  else {
    if(length(which(enrich_data[, 'p adj (non-dir.)'] < 0.05)) == 0)
      stop('There is no terms with adj pval less than 0.5')
    else 
      message(length(which(enrich_data[, 'p adj (non-dir.)'] < 0.05)), ' terms are significant')
    
    data <- enrich_data[which(enrich_data[, 'p adj (non-dir.)'] < 0.05), ]
    data$stat <- log(data$'Stat (non-dir.)')
    data <- data[sort(as.vector(data$stat),
                      index.return = T)$ix, ]
    
    data <- data[1:gene_num, ]
    
    return(data)
  }
}

##' function to calculate the statistics for goodness of fit 
#' 
#' @param gd_fit_res The result from the goodness of fit  
#' @param percentage A logic argument to determine whether or not we should calculate the percentage of genes rather than the numbers
#' @param gene_list The set of genes should as the basis for the analysis
#' @param type The type of data we used for calculating the results 
#' @export
#' 
cal_gd_statistics <- function(gd_fit_res, percentage = T, gene_list = valid_gene_id_cell, type = 'absolute') {
  valid_id <- which(apply(apply(gd_fit_res[, c('nb_pvalue', 'zinb_pvalue')], 2, function(x) !is.na(x)), 1, all))
  message('all successfully fitting gene number: ', length(valid_id))
  
  gd_fit_num <- apply(gd_fit_res[valid_id, ], 2, function(x) {sum(x > 0.01, na.rm = T)} )
  if(percentage)
    gd_fit_num <- gd_fit_num / length(valid_id) 
  
  print(gd_fit_num)
  
  na_num <- apply(gd_fit_res[gene_list, ], 2, function(x) {sum(!is.na(x))} )
  message('number of valid genes for fitting is ', length(gene_list))
  
  print(na_num)
  if(percentage)
    na_num <- na_num / length(gene_list)
  
  res <- rbind(gd_fit_num, na_num)
  row.names(res) <- c('gd_fit_num', 'success_fit_num')
  res <- cbind(res, type = type)
  return(res)
}

##' function to calculate m/c value under different concentration level: 
#' 
#' @param detecthion_threshold The lowest detection limit for the sequencing 
#' @export
#' 
test_mc <- function(detecthion_threshold = 937.5) {  
  valid_ids <- which(input.ERCC.annotation[, 'conc_attomoles_ul_Mix1'] >= detecthion_threshold)
  
  molModels <- esApply(ercc_controls, 2, function(cell_exprs, input.ERCC.annotation, valid_ids) {
    
    #print (cell_exprs)
    spike_df <- input.ERCC.annotation 
    spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
    colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
    spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23))
    spike_df$rounded_numMolecules <- round(spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23)))
    # print (mean(spike_df$rounded_numMolecules))
    
    if(is.null(valid_ids))
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    else{
      spike_df <- spike_df[valid_ids, ]
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    }
    
    #     return(list(row.names(spike_df)))
    spike_df$log_fpkm <- log10(spike_df$FPKM)
    spike_df$log_numMolecules <- log10(spike_df$numMolecules)
    
    #   print (paste("geometric mean of log numMol ", mean(spike_df$log_numMolecules), "geometric mean of log FPKM ", mean(spike_df$log_fpkm)))
    #   c(mean_x_ij_log = mean(spike_df$log_numMolecules), mean_y_ij_log = mean(spike_df$log_fpkm), transcript_num = nrow(spike_df), lowest_detection = min(spike_df$numMolecules))
    molModel <- tryCatch({
      #molModel <- vgam (rounded_numMolecules ~ sm.ns(log_fpkm, df=3), data=spike_df, family=negbinomial(zero=NULL))
      molModel <- rlm(log_numMolecules ~ log_fpkm, data=spike_df)
      
      #
      #         qp <- qplot(FPKM, numMolecules, data=spike_df, log="xy") +
      #       geom_abline(color="green") +
      # geom_smooth(aes(y=10^log_numMolecules), method="lm") +
      # geom_smooth(aes(y=10^log_numMolecules), method="rlm", color="red") +
      # geom_line(aes(y=10^predict(molModel,type="response")))
      # print(qp)- 1
      molModel
    }, 
    error = function(e) { print(e); NULL })
    molModel
  }, input.ERCC.annotation, valid_ids)
  
  kb_df <- data.frame(b = unlist(lapply(molModels, FUN=function(x) { intercept=x$coefficients[1] })), k = unlist(lapply(molModels, FUN=function(x) { slope=x$coefficients[2] })))
  kb_model <- rlm(b ~ k, data = kb_df)
  m <- kb_model$coefficients[2]
  c <- kb_model$coefficients[1]
  
  return(data.frame(m = m, c = c))
}

#' confirm the mode of transcript copy number is one and that the correlationship between our method and the spikein regression recovery 
#' 
#' @param detecthion_threshold The lowest detection limit for the sequencing 
#' @param return_molModel a logic flag to determine whether or not we should return the regression models
#' @export
#' 
conc_spike_in <- function(detecthion_threshold = 937.5, return_molModel = F) {
  valid_ids <- which(input.ERCC.annotation[, 'conc_attomoles_ul_Mix1'] >= detecthion_threshold)
  
  molModels <- esApply(ercc_controls, 2, function(cell_exprs, input.ERCC.annotation, valid_ids) {
    
    #print (cell_exprs)
    spike_df <- input.ERCC.annotation 
    spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
    colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
    spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23))
    spike_df$rounded_numMolecules <- round(spike_df$conc_attomoles_ul_Mix1*(10*10^(-3)*1/40000*10^(-18)*6.02214179*10^(23)))
    # print (mean(spike_df$rounded_numMolecules))
    
    if(is.null(valid_ids))
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    else {
      spike_df <- spike_df[valid_ids, ]
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    }
    
    spike_df$log_fpkm <- log10(spike_df$FPKM)
    spike_df$log_numMolecules <- log10(spike_df$numMolecules)
    
    #   print (paste("geometric mean of log numMol ", mean(spike_df$log_numMolecules), "geometric mean of log FPKM ", mean(spike_df$log_fpkm)))
    #   c(mean_x_ij_log = mean(spike_df$log_numMolecules), mean_y_ij_log = mean(spike_df$log_fpkm), transcript_num = nrow(spike_df), lowest_detection = min(spike_df$numMolecules))
    molModel <- tryCatch({
      #molModel <- vgam (rounded_numMolecules ~ sm.ns(log_fpkm, df=3), data=spike_df, family=negbinomial(zero=NULL))
      molModel <- rlm(log_numMolecules ~ log_fpkm, data=spike_df)
      
      #
      #         qp <- qplot(FPKM, numMolecules, data=spike_df, log="xy") +
      #       geom_abline(color="green") +
      # geom_smooth(aes(y=10^log_numMolecules), method="lm") +
      # geom_smooth(aes(y=10^log_numMolecules), method="rlm", color="red") +
      # geom_line(aes(y=10^predict(molModel,type="response")))
      # print(qp)- 1
      molModel
    }, 
    error = function(e) { print(e); NULL })
    molModel
  }, input.ERCC.annotation, valid_ids)
  
  if(return_molModel)
    return(molModels)
  
  norm_fpkms <- mapply(function(cell_exprs, molModel) {
    tryCatch({
      norm_df <- data.frame(log_fpkm=log10(cell_exprs))
      res <- 10^predict(molModel, type="response", newdata=norm_df)
    }, 
    error = function(e) {
      rep(NA, length(cell_exprs))
    })
  }, 
  split(exprs(standard_cds), rep(1:ncol(exprs(standard_cds)), each = nrow(exprs(standard_cds)))), 
  molModels)
  
  qplot(round(estimate_t(exprs(norm_fpkms))), color = I('red'), alpha = I(0.3), geom = c('density')) + 
    geom_vline(x = 1, linetype = 'longdash', color = I('blue')) + xlab('mode of transcript copy number in cells') + monocle_theme_opts()
  
  return(norm_fpkms)
}

#' Function to perform the hiearchical clusters on hypergeometric test results
#' @export 
#' 
hyper_hclust <- function(clust = cluster, gsc, cds = absolute_cds, tree_num = 2, 
                         gene_universe = unique(as.character(fData(absolute_cds[valid_gene_id_cell, ])$gene_short_name))) {
  tree_grp <- cutree(clust$tree_row, tree_num)
  tree_grp <- tree_grp[unique(names(tree_grp))] #remove duplicated gene names (like not mapping genes)
  
  gsa_results <- list()
  for(i in 1:max(tree_grp)) {
    cluster_genes <- names(tree_grp[tree_grp == i])
    gsaRes <- runGSAhyper(cluster_genes, gsc=gsc, universe=gene_universe)
    gsa_results[[length(gsa_results) + 1]] <- gsaRes      
  }
  names(gsa_results) <- paste('class_', 1:max(tree_grp), sep = '')
  gsa_results
}

#'Function to perform the hypergeometric test and to plot the enrichment 
#' @export
#' 
plot_gsa_hyper_heatmap <- function(cds, gsa_results, significance=0.05, sign_type = 'qval')
{
  hyper_df <- ldply(gsa_results, function(gsa_res)
  {
    data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues, qval = gsa_res$p.adj)
  })
  colnames(hyper_df)[1] <- "cluster_id"
  hyper_df$qval <- p.adjust(hyper_df$pval, method = 'fdr')
  hyper_df <- subset(hyper_df, hyper_df[, sign_type] <= significance)
  
  hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set), function(x) { nrow(x) }), by="gene_set")
  save(hyper_df, file = 'hyper_df') 
  hyper_df$gene_set <- factor(hyper_df$gene_set, levels=unique(arrange(hyper_df, V1, cluster_id)$gene_set))
  
  qplot(cluster_id, gene_set, fill=-log10(qval), geom="tile", data=hyper_df) + scale_fill_gradientn(colours=rainbow(7))
}

#' Function to load the GSC dataset safely
#' @export
#' 
loadGSCSafe <- function (file, type = "auto", addInfo, sep="\t", encoding="unknown") 
{
  if (missing(addInfo)) {
    addUserInfo <- "skip"
    addInfo <- "none"
  }
  else {
    addUserInfo <- "yes"
  }
  tmp <- try(type <- match.arg(type, c("auto", "gmt", "sbml", 
                                       "sif", "data.frame"), several.ok = FALSE), silent = TRUE)
  if (class(tmp) == "try-error") {
    stop("argument type set to unknown value")
  }
  if (type == "auto") {
    if (class(file) == "character") {
      tmp <- unlist(strsplit(file, "\\."))
      type <- tolower(tmp[length(tmp)])
      if (!type %in% c("gmt", "sif", "sbml", "xml")) 
        stop(paste("can not handle .", type, " file extension, read manually using e.g. read.delim() and load as data.frame", 
                   sep = ""))
    }
    else {
      type <- "data.frame"
    }
  }
  if (type == "gmt") {
    con <- file(file, encoding=encoding)
    tmp <- try(suppressWarnings(open(con)), silent = TRUE)
    if (class(tmp) == "try-error") 
      stop("file could not be read")
    if (addUserInfo == "skip") 
      addInfo <- vector()
    gscList <- list()
    i <- 1
    tmp <- try(suppressWarnings(while (length(l <- scan(con, 
                                                        nlines = 1, what = "character", quiet = T, sep=sep)) > 0) {
      if (addUserInfo == "skip") 
        addInfo <- rbind(addInfo, l[1:2])
      tmp <- l[3:length(l)]
      gscList[[l[1]]] <- unique(tmp[tmp != "" & tmp != 
                                      " " & !is.na(tmp)])
      i <- i + 1
    }), silent = TRUE)
    if (class(tmp) == "try-error") 
      stop("file could not be read")
    close(con)
    gsc <- gscList[!duplicated(names(gscList))]
    if (addUserInfo == "skip") 
      addInfo <- unique(addInfo)
  }
  else if (type %in% c("sbml", "xml")) {
    require(rsbml)
    tmp <- try(sbml <- rsbml_read(file))
    if (class(tmp) == "try-error") {
      stop("file could not be read by rsbml_read()")
    }
    gsc <- list()
    for (iReaction in 1:length(reactions(model(sbml)))) {
      metIDs <- names(c(reactants(reactions(model(sbml))[[iReaction]]), 
                        products(reactions(model(sbml))[[iReaction]])))
      geneIDs <- names(modifiers(reactions(model(sbml))[[iReaction]]))
      if (length(geneIDs) > 0) {
        geneNames <- rep(NA, length(geneIDs))
        for (iGene in 1:length(geneIDs)) {
          geneNames[iGene] <- name(species(model(sbml))[[geneIDs[iGene]]])
        }
        for (iMet in 1:length(metIDs)) {
          gsc[[metIDs[iMet]]] <- c(gsc[[metIDs[iMet]]], 
                                   geneNames)
        }
      }
    }
    if (length(gsc) == 0) {
      stop("no gene association found")
    }
    else {
      for (iMet in 1:length(gsc)) {
        tmp1 <- name(species(model(sbml))[[names(gsc)[iMet]]])
        tmp2 <- compartment(species(model(sbml))[[names(gsc)[iMet]]])
        names(gsc)[iMet] <- paste(tmp1, " (", tmp2, ")", 
                                  sep = "")
      }
    }
  }
  else if (type == "sif") {
    tmp <- try(gsc <- as.data.frame(read.delim(file, header = FALSE, 
                                               quote = "", as.is = TRUE), stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("argument file could not be read and converted into a data.frame")
    }
    if (ncol(gsc) != 3) {
      stop("sif file should contain three columns")
    }
    if (addUserInfo == "skip") 
      addInfo <- gsc[, c(1, 2)]
    gsc <- gsc[, c(3, 1)]
    tmp <- nrow(gsc)
    gsc <- unique(gsc)
    geneSets <- unique(gsc[, 2])
    gscList <- list()
    for (iGeneSet in 1:length(geneSets)) {
      gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                                 1]
    }
    names(gscList) <- geneSets
    gsc <- gscList
  }
  else if (type == "data.frame") {
    tmp <- try(gsc <- as.data.frame(file, stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("argument file could not be converted into a data.frame")
    }
    for (i in 1:ncol(gsc)) {
      gsc[, i] <- as.character(gsc[, i])
    }
    if (ncol(gsc) != 2) {
      stop("argument file has to contain exactly two columns")
    }
    tmp <- nrow(gsc)
    gsc <- unique(gsc)
    geneSets <- unique(gsc[, 2])
    gscList <- list()
    for (iGeneSet in 1:length(geneSets)) {
      gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                                 1]
    }
    names(gscList) <- geneSets
    gsc <- gscList
  }
  if (addUserInfo == "yes") {
    tmp <- try(addInfo <- as.data.frame(addInfo, stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("failed to convert additional info in argument 'addInfo' into a data.frame")
    }
  }
  if (class(addInfo) == "data.frame") {
    if (ncol(addInfo) != 2) 
      stop("additional info in argument 'file' or 'addInfo' has to contain 2 columns")
    tmp <- nrow(addInfo)
    addInfo <- unique(addInfo[addInfo[, 1] %in% names(gsc), 
                              ])
  }
  else {
  }
  res <- list(gsc, addInfo)
  names(res) <- c("gsc", "addInfo")
  class(res) <- "GSC"
  return(res)
}

#' Function to load the GSC data (This function is from Cole)
#' @export
#' 
loadGSCSafe <- function (file, type = "auto", addInfo, sep="\t", encoding="unknown") 
{
  if (missing(addInfo)) {
    addUserInfo <- "skip"
    addInfo <- "none"
  }
  else {
    addUserInfo <- "yes"
  }
  tmp <- try(type <- match.arg(type, c("auto", "gmt", "sbml", 
                                       "sif", "data.frame"), several.ok = FALSE), silent = TRUE)
  if (class(tmp) == "try-error") {
    stop("argument type set to unknown value")
  }
  if (type == "auto") {
    if (class(file) == "character") {
      tmp <- unlist(strsplit(file, "\\."))
      type <- tolower(tmp[length(tmp)])
      if (!type %in% c("gmt", "sif", "sbml", "xml")) 
        stop(paste("can not handle .", type, " file extension, read manually using e.g. read.delim() and load as data.frame", 
                   sep = ""))
    }
    else {
      type <- "data.frame"
    }
  }
  if (type == "gmt") {
    con <- file(file, encoding=encoding)
    tmp <- try(suppressWarnings(open(con)), silent = TRUE)
    if (class(tmp) == "try-error") 
      stop("file could not be read")
    if (addUserInfo == "skip") 
      addInfo <- vector()
    gscList <- list()
    i <- 1
    tmp <- try(suppressWarnings(while (length(l <- scan(con, 
                                                        nlines = 1, what = "character", quiet = T, sep=sep)) > 0) {
      if (addUserInfo == "skip") 
        addInfo <- rbind(addInfo, l[1:2])
      tmp <- l[3:length(l)]
      gscList[[l[1]]] <- unique(tmp[tmp != "" & tmp != 
                                      " " & !is.na(tmp)])
      i <- i + 1
    }), silent = TRUE)
    if (class(tmp) == "try-error") 
      stop("file could not be read")
    close(con)
    gsc <- gscList[!duplicated(names(gscList))]
    if (addUserInfo == "skip") 
      addInfo <- unique(addInfo)
  }
  else if (type %in% c("sbml", "xml")) {
    require(rsbml)
    tmp <- try(sbml <- rsbml_read(file))
    if (class(tmp) == "try-error") {
      stop("file could not be read by rsbml_read()")
    }
    gsc <- list()
    for (iReaction in 1:length(reactions(model(sbml)))) {
      metIDs <- names(c(reactants(reactions(model(sbml))[[iReaction]]), 
                        products(reactions(model(sbml))[[iReaction]])))
      geneIDs <- names(modifiers(reactions(model(sbml))[[iReaction]]))
      if (length(geneIDs) > 0) {
        geneNames <- rep(NA, length(geneIDs))
        for (iGene in 1:length(geneIDs)) {
          geneNames[iGene] <- name(species(model(sbml))[[geneIDs[iGene]]])
        }
        for (iMet in 1:length(metIDs)) {
          gsc[[metIDs[iMet]]] <- c(gsc[[metIDs[iMet]]], 
                                   geneNames)
        }
      }
    }
    if (length(gsc) == 0) {
      stop("no gene association found")
    }
    else {
      for (iMet in 1:length(gsc)) {
        tmp1 <- name(species(model(sbml))[[names(gsc)[iMet]]])
        tmp2 <- compartment(species(model(sbml))[[names(gsc)[iMet]]])
        names(gsc)[iMet] <- paste(tmp1, " (", tmp2, ")", 
                                  sep = "")
      }
    }
  }
  else if (type == "sif") {
    tmp <- try(gsc <- as.data.frame(read.delim(file, header = FALSE, 
                                               quote = "", as.is = TRUE), stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("argument file could not be read and converted into a data.frame")
    }
    if (ncol(gsc) != 3) {
      stop("sif file should contain three columns")
    }
    if (addUserInfo == "skip") 
      addInfo <- gsc[, c(1, 2)]
    gsc <- gsc[, c(3, 1)]
    tmp <- nrow(gsc)
    gsc <- unique(gsc)
    geneSets <- unique(gsc[, 2])
    gscList <- list()
    for (iGeneSet in 1:length(geneSets)) {
      gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                                 1]
    }
    names(gscList) <- geneSets
    gsc <- gscList
  }
  else if (type == "data.frame") {
    tmp <- try(gsc <- as.data.frame(file, stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("argument file could not be converted into a data.frame")
    }
    for (i in 1:ncol(gsc)) {
      gsc[, i] <- as.character(gsc[, i])
    }
    if (ncol(gsc) != 2) {
      stop("argument file has to contain exactly two columns")
    }
    tmp <- nrow(gsc)
    gsc <- unique(gsc)
    geneSets <- unique(gsc[, 2])
    gscList <- list()
    for (iGeneSet in 1:length(geneSets)) {
      gscList[[iGeneSet]] <- gsc[gsc[, 2] == geneSets[iGeneSet], 
                                 1]
    }
    names(gscList) <- geneSets
    gsc <- gscList
  }
  if (addUserInfo == "yes") {
    tmp <- try(addInfo <- as.data.frame(addInfo, stringsAsFactors = FALSE), 
               silent = TRUE)
    if (class(tmp) == "try-error") {
      stop("failed to convert additional info in argument 'addInfo' into a data.frame")
    }
  }
  if (class(addInfo) == "data.frame") {
    if (ncol(addInfo) != 2) 
      stop("additional info in argument 'file' or 'addInfo' has to contain 2 columns")
    tmp <- nrow(addInfo)
    addInfo <- unique(addInfo[addInfo[, 1] %in% names(gsc), 
                              ])
  }
  else {
  }
  res <- list(gsc, addInfo)
  names(res) <- c("gsc", "addInfo")
  class(res) <- "GSC"
  return(res)
}

##' function to calculate True/False Postive/Negatice for the permutation result under the calculated p-vals
#' 
#' @param true_data The gold set for differential genes (1: True positive, 0: True negatice)
#' @param est_pval A vector of p-vals from different kinds of differential gene expression tests 
#' @param p_thrsld The threshold to determine whether or not a genes is a differentially expressed genes
#' @export
#' 
TF_PN_vec <- function(true_data, est_pval, p_thrsld = 0.05) {
  TF_PN_vec <- rep(0, 4)
  TF_PN_vec[1] <- sum(true_data * (est_pval <= p_thrsld), na.rm = T) #TP
  TF_PN_vec[2] <- sum((1 - true_data) * (est_pval <= p_thrsld), na.rm = T) #FP
  TF_PN_vec[3] <- sum((1 - true_data) * (est_pval > p_thrsld), na.rm = T) #TN
  TF_PN_vec[4] <- sum(true_data * (est_pval > p_thrsld), na.rm = T) #FN
  
  return(TF_PN_vec)
}

##' function to calculate precision/recall/F1 score
#' 
#' @param est_pval A vector of p-vals from different kinds of differential gene expression tests 
#' @param true_pval The gold set for differential genes (1: True positive, 0: True negatice)
#' @param TF_PN_vec The vector for True/False Postive/Negatice for the permutation calculated with the function TF_PN_vec
#' @param p_thrsld The threshold to determine whether or not a genes is a differentially expressed genes
#' @param beta The beta used in the formula of F1 caculation 
#' @export
#' 
# pre_rec_f1 <- function(est_pval, true_pval, TF_PN_vec, q_thrsld = .1, beta = 1) {
#   pre <- precision_recall_cal(est_pval, true_pval, type = c('precision'), q_thrsld = 0.1)
#   rec <- precision_recall_cal(est_pval, true_pval, type = c('recall'), q_thrsld = 0.1)
#   
#   f1 <-  F_score(TF_PN_vec, beta = 1)
#   
#   data.frame(pre = pre, rec = rec, f1 = f1)
# }

pre_rec_f1 <- function (est_pval, true_pval, TF_PN_vec, q_thrsld = 0.1, beta = 1){
  pre <- precision_recall_cal(est_pval, true_pval, type = c("precision"),
                              q_thrsld = 0.1)
  rec <- precision_recall_cal(est_pval, true_pval, type = c("recall"),
                              q_thrsld = 0.1)
  f1 <- F_score(pre, rec, beta = 1)
  data.frame(pre = pre, rec = rec, f1 = f1)
}

##' function to perform DEG test based on edgeR package
#' 
#' @param counts A matrix for the read counts data 
#' @param group The group assignment for each cell (for example, the time)
#' @param glm A logic flag to determine whether or not the glm should be used for the DEG test
#' @export
#' 
edgeR_test <- function(counts = exprs(count_cds), group = Time_ori, glm = F) {
  y <- DGEList(counts = counts,group = group)
  if(!glm) {
    y <- calcNormFactors(y)
    y <- estimateCommonDisp(y)
    y <- estimateTagwiseDisp(y)
    et <- exactTest(y)
    return(list(et = et, topTags = topTags(et)))
  }
  else { 
    design <- model.matrix(~group)
    y <- estimateGLMCommonDisp(y,design)
    y <- estimateGLMTrendedDisp(y,design)
    y <- estimateGLMTagwiseDisp(y,design)
    fit <- glmFit(y,design)
    lrt <- glmLRT(fit,coef=2)
    topTags(lrt)
    return(list(lrt = lrt, topTags = topTags(lrt)))
  }
}

##' function to perform DEG test based on DESeq2 package
#' 
#' @param dir The directory storing the counts data for performing the DEG test
#' @param cds The cds object for performing the DEG test
#' @param Time The vector for True/False Postive/Negatice for the permutation calculated with the function TF_PN_vec
#' @param test_type A logic flag to determine whether or not the LRT should be used for DEG detection
#' @param design A string denoting the full model formula
#' @param reduced A string denoting the reduced model formula
#' @param pd A dataframe storing the phenotype data for each sample 
#' @export
#' 
DESeq2_deg <- function (dir, cds, Time, test_type = "LRT", design = as.formula("~ Time"),
                        reduced = as.formula("~ 1"), pd = pData(cds)){
  if (!is.null(dir)) {
    sample_table <- read.delim(paste(dir, "/samples.table",
                                     sep = ""))
    norm_count <- read.delim(paste(dir, "/genes.count_table",
                                   sep = ""))
    row.names(norm_count) <- norm_count$tracking_id
    norm_count <- norm_count[, -1]
    countdata <- round(t(t(norm_count) * sample_table$internal_scale))
    if (exists("sample_sheet"))
      countdata <- countdata[, row.names(sample_sheet)]
  }
  else countdata <- round(exprs(cds))
  DEseq2_cnt_cds <- DESeqDataSetFromMatrix(countData = countdata[,
                                                                 ], colData = pd, design = design)
  DEseq2_cnt_cds <- DESeq(DEseq2_cnt_cds, test = test_type,
                          reduced = reduced)
  return(DEseq2_cnt_cds)
}

##' function to calculate all the associated parameters for the absolute transcript count recovery algorithm 
#' 
#' @param dilution Number of times the spike-in transcripts are diluated
#' @param volume The volumne for the the spike-in buffer to be added (nL)
#' @param ercc_control A dataframe storing the information about the ERCC spike-in transcripts 
#' @param select_above_thresh A logic flag to determine whether or not the regression should be performed based on all transcripts above a certain concentration 
#' @param add_pseudocount A logic flag to determine whether or not the pseudocount should be added in order to perform the regression 
#' @param capture_efficiency A value range between 0 to 1 to show the capture efficiency for the single-cell RNA-seq under study 
#' @export
#' 
all_algorithm_parameters <- function(dilution = 1/ 40000, volume = 10, ercc_control = ercc_controls, select_above_thresh = F, add_pseudocount = F, capture_efficiency = NA) {
  esApply(ercc_control, 2, function(cell_exprs, input.ERCC.annotation, dilution, volume, select_above_thresh, add_pseudocount, capture_efficiency) {
    spike_df <- input.ERCC.annotation
    spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
    colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
    spike_df$numMolecules <- spike_df$conc_attomoles_ul_Mix1*(volume*10^(-3)*dilution*10^(-18)*6.02214179*10^(23))
    if(!is.na(capture_efficiency))
      spike_df$numMolecules <- spike_df$numMolecules * capture_efficiency
    
    spike_df$rounded_numMolecules <- round(spike_df$conc_attomoles_ul_Mix1*(volume*10^(-3)*dilution*10^(-18)*6.02214179*10^(23)))
    if(add_pseudocount)
      spike_df$FPKM <- spike_df$FPKM + 1
    
    if(select_above_thresh){
      spike_df <- subset(spike_df, conc_attomoles_ul_Mix1 >= 800)
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    }
    else
      spike_df <- subset(spike_df, FPKM >= 1e-10)
    spike_df$log_fpkm <- log10(spike_df$FPKM)
    spike_df$log_numMolecules <- log10(spike_df$numMolecules)
    molModel <- tryCatch({
      molModel <- rlm(log_numMolecules ~ log_fpkm, data=spike_df)
      
      molModel
    },
    error = function(e) { print(e); NULL })
    
    kb <- coef(molModel)
    return(data.frame(total_RNA_transcripts = sum(spike_df$numMolecules),
                      fpkm = log10(spike_df$FPKM),
                      concentration = log10(spike_df$conc_attomoles_ul_Mix1),
                      c_mean_y_ij = mean(spike_df$log_numMolecules),
                      m_mean_x_ij = mean(spike_df$log_fpkm),
                      sum_M = log10(sum(spike_df$FPKM)),
                      sum_con = log10(sum(spike_df[row.names(spike_df), 'conc_attomoles_ul_Mix1'])),
                      m_norm_mean_x_ij = mean(log10(spike_df$FPKM / sum(spike_df$FPKM))),
                      R_mean_conc_ij = mean(log10(spike_df[row.names(spike_df), 'conc_attomoles_ul_Mix1'])),
                      R_rho_ij = mean(log10(spike_df[row.names(spike_df), 'conc_attomoles_ul_Mix1'] / sum(spike_df[row.names(spike_df), 'conc_attomoles_ul_Mix1']))),
                      b_ij = kb[1],
                      k_ij = kb[2]
    ))
  }, input.ERCC.annotation, dilution, volume, select_above_thresh = select_above_thresh, add_pseudocount = add_pseudocount, capture_efficiency)
}

#' change the function for the purpose of optiimization and mapping the landscape
#' 
#' @param mc A vector for the values of m and c
#' @param spike_data A dataframe storing the information about the ERCC spike-in transcripts  
#' @param alpha The alpha value used in the object function in the optimization 
#' @param total_RNAs A logic flag to determine whether or not the regression should be performed based on all transcripts above a certain concentration 
#' @param weight A numberic value range from 0 to 1 to determine the weights for each part
#' @param t_estimate A vector for the t^* in each cell 
#' @param relative_expr_matrix A dataframe for the relative measurement of the expression measurement (TPM)
#' @param split_relative_expr_matrix A dataframe for the relative measurement of the expression measurement (TPM) after splitting  
#' @param add_kl_divergence A logic flag to determine whether or not KL divergence should be consider in the obejective function 
#' @param cores Number of cores to be used in peforming the optimization 
#' @export
#' 
optim_mc_func_fix_c_test_optim <- function (mc, spike_data = spike_df, alpha = 1, total_RNAs = 50000,  weight = 0.01, 
                                            t_estimate = estimate_t(TPM_isoform_count_cds), relative_expr_matrix = exprs(TPM_cds), 
                                            split_relative_expr_matrix = split(exprs(TPM_cds), col(TPM_cds, as.factor = T)), add_kl_divergence  = T, cores = 1, ...) {
  if(is.null(spike_data$log_numMolecule))
    spike_data$log_numMolecules <- log10(spike_data$numMolecules)
  
  m_val <- mc[[1]]
  c_val <- mc[[2]]
  
  cell_num <- ncol(relative_expr_matrix)
  names(t_estimate) <- colnames(relative_expr_matrix)
  split_t <- split(t(t_estimate), col(as.matrix(t(t_estimate)), as.factor = T))
  
  total_rna_df <- data.frame(Cell = colnames(relative_expr_matrix), t_estimate = t_estimate)
  
  t_k_b_solution <- tryCatch({
    k_b_solution <- plyr::ddply(total_rna_df, .(Cell), function(x) {
      a_matrix <- matrix(c(log10(x[, "t_estimate"]), 1,
                           m_val, -1), ncol = 2, nrow = 2, byrow = T)
      colnames(a_matrix) <- c("k", "b")
      b_matrix <- matrix(c(0, -c_val), nrow = 2, byrow = T)
      k_b_solution <- t(solve(a_matrix, b_matrix))
    })
    k_b_solution},
    error = function(e) {print(e); c(NA, NA)}
  )
  
  if(any(is.na(t_k_b_solution)))
    return(NA)
  
  cell_dmode <- tryCatch({
    if(cores > 1){
      cell_dmode <- mcmapply(opt_norm_t, split_t, split_relative_expr_matrix, m = m_val, c = c_val, pseudocnt = 0.01, mc.cores = cores)
      adj_est_std_cds <- mcmapply(opt_norm_t, split_t, split_relative_expr_matrix, m = m_val, c = c_val, pseudocnt = 0.01, return_norm = T, mc.cores = cores)
    }
    else {
      cell_dmode <- mapply(opt_norm_t, split_t, split_relative_expr_matrix, m = m_val, c = c_val, pseudocnt = 0.01)
      adj_est_std_cds <- mapply(opt_norm_t, split_t, split_relative_expr_matrix, m = m_val, c = c_val, pseudocnt = 0.01, return_norm = T)
    }
    cell_dmode},
    error = function(e) {print(e); NA}
  )
  
  if(any(is.na(cell_dmode)))
    return(NA)
  
  #adj_est_std_cds <- mapply(opt_norm_t, split_t, split_fpkm, m = m_val, c = c_val, return_norm = T)
  sum_total_cells_rna <- colSums(adj_est_std_cds)
  
  #minimization function:
  #8.
  dmode_rmse_weight_total <- mean(weight*((cell_dmode - alpha)/alpha)^2 + (1 - weight)*((sum_total_cells_rna -  total_RNAs)/total_RNAs)^2)
  #add the JS distance measure:
  split_relative_expr_matrix <- split(t(adj_est_std_cds), 1:ncol(adj_est_std_cds))
  round_split_relative_expr_matrix <- split(t(round(adj_est_std_cds)), 1:ncol(adj_est_std_cds))
  
  p_df <- makeprobs(relative_expr_matrix) #relative expression
  p_list <- split(t(p_df), 1:ncol(p_df))
  q_df_round <- makeprobs(round(adj_est_std_cds)) #round
  q_df <- makeprobs(adj_est_std_cds) #no rounding
  q_list <- split(t(q_df), 1:ncol(q_df))
  q_list_round <- split(t(q_df_round), 1:ncol(q_df_round))
  
  dist_divergence <- mcmapply(function(x, y) {
    JSdistVec(x, y)
  }, p_list, q_list, mc.cores = cores)
  
  dist_divergence_round <- mcmapply(function(x, y) {
    JSdistVec(x, y)
  }, p_list, q_list_round, mc.cores = cores)
  
  gm_dist_divergence <- exp(mean(log(dist_divergence)))
  
  if(add_kl_divergence)
    res <- 0.25 * log10(dmode_rmse_weight_total + 1) + 0.75 * gm_dist_divergence
  else
    res <- log10(dmode_rmse_weight_total + 1)
  
  #use the algorithm:
  if(add_kl_divergence)
    res <- (weight * (mean(((cell_dmode - alpha)/alpha)^2) - 0)) + (1 - weight) * (gm_dist_divergence - 0.0) + dmode_rmse_weight_total
  else
    res <- log10(dmode_rmse_weight_total + 1)
  
  message('current m, c values are ', mc)
  message('dmode_rmse_weight_total is ', mean(((cell_dmode - alpha)/alpha)^2) - 0)
  message('gm_dist_divergence is ', gm_dist_divergence)
  
  return(list(m = m_val, c = c_val, dmode_rmse_weight_total = dmode_rmse_weight_total, gm_dist_divergence = gm_dist_divergence, dist_divergence_round = dist_divergence_round,
              cell_dmode = cell_dmode, t_k_b_solution = t_k_b_solution, sum_total_cells_rna = sum_total_cells_rna, optim_res = res))
  
  if(is.finite(dmode_rmse_weight_total))
    return(res)
  else
    return(10)
}

#' @export
optim_mc_func_fix_c <- function (kb_slope_intercept, kb_intercept = NULL, t_estimate = estimate_t(TPM_isoform_count_cds),
          relative_expr_matrix = relative_expr_matrix, split_relative_expr_matrix = split_relative_exprs,
          alpha = rep(1, ncol(relative_expr_matrix)), total_RNAs = rep(150000, ncol(relative_expr_matrix)),
          cores = 1, weight_mode=0.17, weight_relative_expr=0.50, weight_total_rna=0.33, verbose = F,  ...) {
  data('spike_df') #add the spikein dataset

  if(is.null(spike_df$log_numMolecule))
    spike_df$log_numMolecules <- log10(spike_df$numMolecules)

  if(is.null(kb_intercept)) {
    kb_slope_val <- kb_slope_intercept[1]
    kb_intercept_val <- kb_slope_intercept[2]
  }
  else {
    kb_slope_val <- kb_slope_intercept[1]
    kb_intercept_val <- kb_intercept
  }

  cell_num <- ncol(relative_expr_matrix)
  names(t_estimate) <- colnames(relative_expr_matrix)
  split_t <- split(Matrix::t(t_estimate), col(as.matrix(Matrix::t(t_estimate)), as.factor = T))

  total_rna_df <- data.frame(Cell = colnames(relative_expr_matrix), t_estimate = t_estimate, alpha_v = alpha)

  t_k_b_solution <- tryCatch({
    k_b_solution <- plyr::ddply(total_rna_df, .(Cell), function(x) {
      a_matrix <- matrix(c(log10(x[, "t_estimate"]), 1,
                           kb_slope_val, -1), ncol = 2, nrow = 2, byrow = T)
      colnames(a_matrix) <- c("k", "b")
      b_matrix <- matrix(c(log10(x[, "alpha_v"]), -kb_intercept_val), nrow = 2, byrow = T)
      k_b_solution <- Matrix::t(solve(a_matrix, b_matrix))
    })
    k_b_solution},
    error = function(e) {print(e); c(NA, NA)}
  )

  if(any(is.na(t_k_b_solution)))
    return(NA)

  cell_dmode <- tryCatch({
    if(cores > 1){
      cell_dmode <- unlist(mcmapply(opt_norm_t, split_t, split_relative_expr_matrix, alpha, kb_slope = kb_slope_val, kb_intercept = kb_intercept_val, pseudocnt = 0.01, mc.cores = cores))
      adj_est_std_cds <- unlist(mcmapply(opt_norm_t, split_t, split_relative_expr_matrix, alpha, kb_slope = kb_slope_val, kb_intercept = kb_intercept_val, pseudocnt = 0.01, return_norm = T, mc.cores = cores))
    }
    else {
      cell_dmode <- unlist(mapply(opt_norm_t, split_t, split_relative_expr_matrix, alpha, kb_slope = kb_slope_val, kb_intercept = kb_intercept_val, pseudocnt = 0.01))
      adj_est_std_cds <- unlist(mapply(opt_norm_t, split_t, split_relative_expr_matrix,  alpha, kb_slope = kb_slope_val, kb_intercept = kb_intercept_val, pseudocnt = 0.01, return_norm = T))
    }
    cell_dmode},
    error = function(e) {print(e); NA}
  )

  if(any(is.na(cell_dmode)))
    return(NA)

  sum_total_cells_rna <- colSums(adj_est_std_cds)

  #Jenn-Shannon divergence:
  p_df <- makeprobs(relative_expr_matrix) #relative expression
  p_list <- split(Matrix::t(p_df), 1:ncol(p_df))
  q_df <- makeprobs(adj_est_std_cds) #no rounding
  q_list <- split(Matrix::t(q_df), 1:ncol(q_df))

  dist_divergence <- mcmapply(function(x, y) {
    JSdistVec(x, y)
  }, p_list, q_list, mc.cores = cores)


  gm_dist_divergence <- exp(mean(log(dist_divergence)))

  #total RNA MSE
  sum_total_cells_rna_finite <- sum_total_cells_rna[is.finite(sum_total_cells_rna)]
  total_RNAs_finite <- total_RNAs[is.finite(sum_total_cells_rna)]
  total_rna_obj <- exp(mean(log(((sum_total_cells_rna_finite -  total_RNAs_finite)/total_RNAs_finite)^2))) #use geometric mean to avoid outlier cells

  #mode MSE
  mode_obj <- exp(mean(log(((cell_dmode[is.finite(cell_dmode)] - alpha[is.finite(cell_dmode)])/alpha[is.finite(cell_dmode)])^2)))

  relative_expr_obj <- gm_dist_divergence * 10 #give more weight on this

  #objective
  res <- weight_mode * mode_obj + weight_relative_expr * relative_expr_obj + weight_total_rna * total_rna_obj

  if(verbose){
    message('current m, c values are ', paste(kb_slope_val, kb_intercept_val, sep = ', '))
    message('objective is:')
    print(res)

    message('\n\ntotal_rna_obj is ', total_rna_obj)
    message('mode_obj is ', mode_obj)
    message('relative_expr_obj is ', relative_expr_obj)

    message('\n\nmean modes are:')
    print (mean(cell_dmode))
    message('mean target modes are:')
    print (mean(alpha))
    message('mean mode delta is:')
    print (mean(cell_dmode - alpha))
    message('mean total RNA delta is:')
    print (mean(sum_total_cells_rna_finite -  total_RNAs_finite))

  }
  #   return(list(m = m_val, c = c_val, dmode_rmse_weight_total = dmode_rmse_weight_total, gm_dist_divergence = gm_dist_divergence, dist_divergence_round = dist_divergence_round,
  #               cell_dmode = cell_dmode, t_k_b_solution = t_k_b_solution, sum_total_cells_rna = sum_total_cells_rna, optim_res = res))
  #
  if(is.finite(res))
    return(res)
  else
    return(1e10 * runif(1)) #Census should not run this part since non-finite values are removed
}

#' function to generate the data frame for making the gene regulatory network
#' @param cds The CDS object used for performing the analysis   
#' @param branchTest_res The data frame storing all the branchTest results
#' @param p_thrsld The threshold for selecting branch genes
#' @param TF_enrichment_gsc A TF enrichment object result from piano's hypergeometric test
#' @param motif_tfs_all All the TFs have motifs 
#' @param ABCs_df The dataframe stores all the ABC relevant results  
#' @param bifurcation_time The vector storing the information about the bifurcation time point 
#' @param filename The name for the file to be saved 
#' @export
#' 
infer_branch_gene_grn <- function(cds = abs_AT12_cds_subset_all_gene, branchTest_res = relative_abs_AT12_cds_subset_all_gene, p_thrsld = 0.05, 
                                  TF_enrichment_gsc = TF_up2k_dn.5k.enrichment_gsc, motif_tfs_all = c(motif_TFs, motif_TFs_add), 
                                  ABCs_df = NULL, 
                                  bifurcation_time = abs_bifurcation_time, filename = 'gene_regulatory_net'){
  names(TF_enrichment_gsc$gsc) <- toupper(names(TF_enrichment_gsc$gsc))
  
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "RXR::RAR" ] <- "RARA"
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "TCFE2A" ] <- "E2A"
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "TP63" ] <- "TRP63"
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "TP53" ] <- "TRP53"
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "ZNF143" ] <- "ZFP143"
  names(TF_enrichment_gsc$gsc)[names(TF_enrichment_gsc$gsc) == "TCFCP2L1" ] <- "TFCP2L1"
  
  branch_tfs <- intersect(motif_tfs_all, toupper(fData(cds[row.names(branchTest_res[branchTest_res[, 'pval'] <= p_thrsld, ]), ])$gene_short_name))
  branch_Tfs_id <- row.names(subset(fData(cds[row.names(branchTest_res[branchTest_res[, 'pval'] <= p_thrsld, ]), ]), toupper(gene_short_name) %in% motif_tfs_all))
  
  #find the genes binded by the branching TFs and build a network: 
  branch_tfs_mat <- matrix(rep(0, length(branch_tfs)^2), nrow = length(branch_tfs), dimnames = list(branch_tfs, branch_tfs))
  
  for(i in 1:length(branch_tfs)) {
    tmp <- TF_enrichment_gsc$gsc[[branch_tfs[i]]]   
    target <- intersect(toupper(tmp), branch_tfs)
    message(paste(branch_tfs[i], length(tmp), length(target), sep = ': '))
    if(length(target) > 0)
      branch_tfs_mat[branch_tfs[i], target] <- 1
  }
  
  #draw the network: 
  # runNetBioV(branch_tfs_mat)
  m <- as.matrix(branch_tfs_mat)
  net <- graph.adjacency(m, mode = 'direct', weighted=T, diag=FALSE)
  
  #write to a file: 
  adj_list <- get.edgelist(net, names=TRUE)
  adj_list <- as.data.frame(get.edgelist(net, names=TRUE))
  colnames(adj_list) <- c('Source', 'Target')
  
  adj_list$source_cluster <- as.numeric(clusters[adj_list[, 1]])
  adj_list$target_cluster <- as.numeric(clusters[adj_list[, 2]])
  adj_list$type <- adj_list[, 2] == 'EHF'
  adj_list$direction <- '+'
  
  # Source Target source_cluster target_cluster  type direction bif_time
  
  names(bifurcation_time) <- toupper(names(bifurcation_time))
  adj_list$bif_time <- bifurcation_time[adj_list[, 1]]
  no_out_degree_gene <- !(adj_list[, 2] %in% adj_list[, 1])
  adj_list_tmp <- adj_list[no_out_degree_gene, ]
  
  adj_list$qval <- branchTest_res[adj_list[, 1], 'qval']
  if(!is.null(ABCs_df))
    adj_list$ABCs <- ABCs_df[adj_list[, 1], 'ABCs'] #abs_AT12_cds_subset_all_gene_ABCs
  
  adj_list_tmp <- adj_list_tmp[, c('Target', 'Source', 'target_cluster', 'source_cluster', 'type', 'direction', 'bif_time')]
  adj_list_tmp[, 'direction'] <-  '-'
  adj_list_tmp$bif_time <- bifurcation_time[adj_list_tmp[, 1]]
  
  adj_list_tmp$qval <- branchTest_res[adj_list_tmp[, 1], 'qval']
  if(!is.null(ABCs_df))
    adj_list_tmp$ABCs <- ABCs_df[adj_list_tmp[, 1], 'ABCs']
  
  adj_list <- rbind(adj_list, adj_list_tmp)
  
  print(adj_list)
  
  save(adj_list, file = 'adj_list')
  write.table(adj_list, file = filename, sep = '\t', row.names = F, quote = F)
  
  return(list(branch_tfs = branch_tfs, branch_Tfs_id = branch_Tfs_id, adj_list = adj_list))
}

#' Function to compare the Poisson fit 
#' @export
#'
cmpr_poisson_fit <- function(index = 1) {
  VGAM_fit_test_data <- data.frame(Pseudotime = pData(new_cds)$Pseudotime,
                                   Lineage = pData(new_cds)$Lineage,
                                   expression = round(exprs(new_cds)[heatmap_genes[index], ] /
                                                        sizeFactors(new_cds)))
  
  p1 <- qplot(Pseudotime, expression, data = VGAM_fit_test_data, color = sizeFactors(new_cds), size = sizeFactors(new_cds))
  
  #add the dispersion parameter: 
  #test the consistency between plot_genes_branched_heatmap and the ad hoc poisson fitting:
  # test <- plot_genes_branched_heatmap(abs_AT12_cds_subset_all_gene[heatmap_genes[1:10], ], 
  #     stretch = T, file = paste(elife_directory, "eLife_fig3b.pdf", sep = ''))
  
  orig_x <- exprs(abs_AT12_cds_subset_all_gene)[heatmap_genes[index], ] 
  
  disp_func <- new_cds@dispFitInfo[['blind']]$disp_func
  disp_guess <- calulate_QP_dispersion_hint(disp_func, round(orig_x))
  backup_expression_family <- poissonff(dispersion=disp_guess)
  
  poisson_fit <- vglm(as.formula('expression~sm.ns(Pseudotime, df=3) * Lineage'), data = VGAM_fit_test_data, family = backup_expression_family) 
  quasi_poisson_fit <- vglm(as.formula('expression~sm.ns(Pseudotime, df=3) * Lineage'), data = VGAM_fit_test_data, family = quasipoissonff()) 
  
  newdataA <- data.frame(Pseudotime = seq(0, 100,
                                          length.out = 1000), Lineage = as.factor(unique(as.character(pData(new_cds)$Lineage))[1]))
  newdataB <- data.frame(Pseudotime = seq(0, 100,
                                          length.out = 1000), Lineage = as.factor(unique(as.character(pData(new_cds)$Lineage))[2]))
  
  predict_val <- predict(poisson_fit, type = 'response', newdata = rbind(newdataA, newdataB))
  predict_val2 <- predict(quasi_poisson_fit, type = 'response', newdata = rbind(newdataA, newdataB))
  
  p2 <- qplot(rbind(newdataA, newdataB)[, 1], predict_val + 1, colour = rbind(newdataA, newdataB)[, 2], log = 'y')  + 
    ggtitle(paste('Dispersion parameter is: ', disp_guess))
  
  p2.1 <- qplot(rbind(newdataA, newdataB)[, 1], predict_val2 + 1, colour = rbind(newdataA, newdataB)[, 2], log = 'y')  + 
    ggtitle("quasi-poisson fit")
  
  p3 <- qplot(1:200, c(all_AT12_heatmap$LineageA_exprs[heatmap_genes[index], ], 
                       all_AT12_heatmap$LineageB_exprs[heatmap_genes[index], ]))  + 
    ggtitle('Poisson fit from fit_model_helper')
  
  # qplot(predict_val, c(all_AT12_heatmap$LineageA_exprs[heatmap_genes[index], ], 
  #                      all_AT12_heatmap$LineageB_exprs[heatmap_genes[index], ]))
  dev.off()
  multiplot(p1, p2, p2.1, p3)
  return(list(p1 = p1, p2 = p2, p2.1 = p2.1, p2.2 = p2.2, p2.3 = p2.3, p3 = p3))
}

#' Save the hyper_df into a xls table 
#' @export
#'
save_hyper_df <- function(gsa_results, file_name) {
  hyper_df <- ldply(gsa_results, function(gsa_res)
  {
    data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues)
  })
  colnames(hyper_df)[1] <- "cluster_id"
  hyper_df$qval <- p.adjust(hyper_df$pval, method = "fdr")
  
  hyper_df <- subset(hyper_df, qval <= 1e-1)
  hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set), function(x) { nrow(x) }), by="gene_set")
  hyper_df$gene_set <- factor(hyper_df$gene_set, levels=unique(arrange(hyper_df, V1, cluster_id)$gene_set))
  
  write.table(hyper_df, sep = '\t', quote = F, row.names = F, file = file_name)
}

#' Perform hypergeometric test on each cluster of genes 
#' @export
#'
collect_gsa_hyper_results <- function(cds, gsc, clusters) {
  gene_universe <- unique(as.character(fData(cds)$gene_short_name))
  gsa_results <- list()
  for (i in (1:max(clusters))){
    cluster_genes <- unique(names(clusters[clusters == i])) #unique(fData(cds[names(clusters[clusters == i]),])$gene_short_name)
    gsaRes <- runGSAhyper(cluster_genes, gsc=gsc, universe=gene_universe)
    gsa_results[[length(gsa_results) + 1]] <- gsaRes
  }
  save(gsa_results, file = 'gsa_results')
  names(gsa_results) <- 1:max(clusters)
  gsa_results
}

#' load all the necessary libraries
#' @export
#' 
load_all_libraries <- function(){
  library(monocle)
  library(xacHelper)
  library(lmtest)
  library(MASS)
  library(DESeq)
  library(reshape2)
  library(DESeq2)
  library(fitdistrplus)
  library(VGAM)
  library(pscl)
  library(zoo) #calcualting the AUC
  library(VennDiagram)
  library(monocle)
  library(stringr)
  library(limma)
  library(reshape2)
  library(plyr)
  library(modeest)
  library(MASS)
  library(mixsmsn)
  library(doMC)
  library(data.table)
  library(boot)
  library(testthat)
  require(pheatmap)
  library(gplots)
  library(RColorBrewer)
  library(piano)
  library(ggdendro)
  library(stringr)
  library(grid)
  library(reshape2)
  library(snow)
  library(princurve)
  library(matrixStats)
  library(colorRamps)  
  library(edgeR) 
  library(plyr)
  library(pheatmap)
  library(stringr)
  library(piano)
  library(grid)
  library(colorRamps)
  library(RColorBrewer)
  library(R.utils)
  library(sp)
  library(raster)
  library(venneuler)
  library(colorRamps)
  library(scde)
  library(stringr)
  library(plyr)
  # library()
}


#' Function to recover the transcript counts with fixed c value 
#' 
#' 
relative2abs_optim_fix_c <- function (relative_expr_matrix, t_estimate = estimate_t(relative_expr_matrix), m = -3.652201, c = 2.263576, m_rng = c(-10, -0.1),
                                      detection_threshold = 0.01430512, ERCC_controls = NULL, ERCC_annotation = NULL,
                                      volume = 10, dilution = 40000, return_all = FALSE, cores = 1, alpha_v = 1, total_RNAs = 50000, weight = 0.5,
                                      mixture_type = 1, verbose = FALSE, optim_num = 1) {
  if (detection_threshold < 0.01430512 | detection_threshold >
      7500)
    stop("concentration detection limit should be between 0.01430512 and 7500")
  else mc_id <- round(detection_threshold/0.01430512)
  if (mixture_type == 1)
    mixture_name = "conc_attomoles_ul_Mix1"
  else mixture_name = "conc_attomoles_ul_Mix2"
  Cell <- NULL
  if (!is.null(ERCC_controls) | !is.null(ERCC_annotation)) {
    if (is.null(ERCC_controls) | is.null(ERCC_annotation))
      stop("If you want to transform the data to copy number with your spikein data, please provide both of ERCC_controls and ERCC_annotation data frame...")
    valid_ids <- which(ERCC_annotation[, mixture_name] >=
                         detection_threshold)
    if (verbose)
      message("Performing robust linear regression for each cell based on the spikein data...")
    molModels <- apply(ERCC_controls, 2, function(cell_exprs,
                                                  input.ERCC.annotation, valid_ids) {
      spike_df <- input.ERCC.annotation
      spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
      colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
      spike_df$numMolecules <- spike_df[, mixture_name] *
        (volume * 10^(-3) * 1/dilution * 10^(-18) * 6.02214129 *
           10^(23))
      spike_df$rounded_numMolecules <- round(spike_df[,
                                                      mixture_name] * (volume * 10^(-3) * 1/dilution *
                                                                         10^(-18) * 6.02214129 * 10^(23)))
      if (is.null(valid_ids))
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      else {
        spike_df <- spike_df[valid_ids, ]
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      }
      spike_df$log_fpkm <- log10(spike_df$FPKM)
      spike_df$log_numMolecules <- log10(spike_df$numMolecules)
      molModel <- tryCatch({
        molModel <- rlm(log_numMolecules ~ log_fpkm,
                        data = spike_df)
        molModel
      }, error = function(e) {
        print(e)
        NULL
      })
      molModel
    }, ERCC_annotation, valid_ids)
    if (verbose)
      message("Apply the fitted robust linear regression model to recovery the absolute copy number for all transcripts each cell...")
    norm_fpkms <- mcmapply(function(cell_exprs, molModel) {
      tryCatch({
        norm_df <- data.frame(log_fpkm = log10(cell_exprs))
        res <- 10^predict(molModel, type = "response",
                          newdata = norm_df)
      }, error = function(e) {
        rep(NA, length(cell_exprs))
      })
    }, split(as.matrix(relative_expr_matrix), rep(1:ncol(relative_expr_matrix),
                                                  each = nrow(relative_expr_matrix))), molModels, mc.cores = cores)
    k_b_solution <- data.frame(b = unlist(lapply(molModels,
                                                 FUN = function(x) {
                                                   intercept = x$coefficients[1]
                                                 })), k = unlist(lapply(molModels, FUN = function(x) {
                                                   slope = x$coefficients[2]
                                                 })))
    kb_model <- rlm(b ~ k, data = k_b_solution)
    m <- kb_model$coefficients[2]
    c <- kb_model$coefficients[1]
    if (return_all == T) {
      return(list(norm_cds = norm_fpkms, m = m, c = c,
                  k_b_solution = k_b_solution))
    }
    norm_fpkms
  }
  else {
    split_relative_exprs <- split(as.matrix(relative_expr_matrix),
                                  col(relative_expr_matrix, as.factor = T))
    names(t_estimate) <- colnames(relative_expr_matrix)
    
    if(verbose)
      message('optimizating mc values...')
    #the t_estimate may also need to optimized:
    for(optim_iter in 1:optim_num) {
      if(verbose)
        message(paste('optimization cycle', optim_iter, '...'))
      
      optim_para <- optim(par = c(m = m),
                          optim_mc_func_fix_c, gr = NULL, c = c, t_estimate = t_estimate,
                          alpha = alpha_v, total_RNAs = total_RNAs, cores = cores, weight = weight, pseudocnt = 0.01,
                          relative_expr_matrix = relative_expr_matrix, split_relative_expr_matrix = split_relative_exprs,
                          method = c("Brent"),
                          lower = c(rep(as.vector(t_estimate) - 0, 0), m_rng[1]), #search half low or up of the t_estimate
                          upper = c(rep(as.vector(t_estimate) + 0, 0), m_rng[2]), #m, c is between (-0.1 to -10 and 0.1 to 10)
                          control = list(factr = 1e12, pgtol = 1e-3, trace = 1, ndeps = c(1e-3) ), #as.vector(t_estimate) / 1000,
                          hessian = FALSE)
      if(verbose)
        message('optimization is done!')
      
      m <- optim_para$par[1]
      c <- c
      
      total_rna_df <- data.frame(Cell = colnames(relative_expr_matrix),
                                 t_estimate = t_estimate)
      if (verbose)
        message("Estimating the slope and intercept for the linear regression between relative expression value and copy number...")
      
      k_b_solution <- plyr::ddply(total_rna_df, .(Cell), function(x) {
        a_matrix <- matrix(c(log10(x[, "t_estimate"]), 1,
                             m, -1), ncol = 2, nrow = 2, byrow = T)
        colnames(a_matrix) <- c("k", "b")
        b_matrix <- matrix(c(0, -c), nrow = 2, byrow = T)
        k_b_solution <- t(solve(a_matrix, b_matrix))
      })
      
      rownames(k_b_solution) <- k_b_solution$Cell
      k_b_solution <- t(k_b_solution[, c(2, 3)])
      split_kb <- split(k_b_solution, col(k_b_solution, as.factor = T))
      if (verbose)
        message("Apply the estimated linear regression model to recovery the absolute copy number for all transcripts each cell...")
      adj_split_relative_expr <- mcmapply(norm_kb, split_kb,
                                          split_relative_exprs, mc.cores = cores)
      total_rna_df$estimate_k <- k_b_solution[1, ]
      total_rna_df$estimate_b <- k_b_solution[2, ]
      norm_cds <- adj_split_relative_expr
      row.names(norm_cds) <- row.names(relative_expr_matrix)
      colnames(norm_cds) <- colnames(relative_expr_matrix)
      
      #update t_estimate, alpha_v, total_RNAs
      t_estimate <- 10^(-(m + c / total_rna_df$estimate_k))
      alpha_v <- estimate_t(norm_cds) #apply(norm_cds, 2, function(x) mlv(round(x)[round(x) > .1], method = "mfv")$M) 
      total_RNAs <- apply(norm_cds, 2, sum)
    }
    
    if (verbose)
      message("Return results...")
    if (return_all == T) {
      return(list(norm_cds = norm_cds, m = m, c = c, k_b_solution = k_b_solution))
    }
    norm_cds
  }
}

#' function to retrieve m/c values based on the volume and dilution
#' @export
#' 
get_mc_list <- function(volume, dilution){
  mat <- matrix(
    c(-3.652201, 2.263576,
      -3.652201, 2.263576,
      -3.652201, 2.263576,
      -3.652347, 2.26371,
      -3.653535, 2.264639,
      -3.652076, 2.263407,
      -3.648284, 2.260313,
      -3.650168, 2.262497,
      -3.65139,  2.264297,
      -3.64543,  2.263617,
      -3.663548, 2.287196,
      -3.686309, 2.321314,
      -3.735227, 2.380282,
      -3.870832, 2.523883,
      -4.024396, 2.677024,
      -4.070794, 2.744178,
      -4.277778, 2.932929,
      -4.496089, 3.132498,
      -4.584481, 3.201793,
      -4.765763, 3.353782),
    ncol = 2, byrow = TRUE, dimnames = list(
      c(0.01430512,
        0.02861023,
        0.05722046,
        0.11444092,
        0.22888184,
        0.45776367,
        0.91552734,
        1.83105469,
        3.66210938,
        7.32421875,
        14.6484375,
        29.296875,
        58.59375,
        117.1875,
        234.375,
        468.75,
        937.5,
        1875,
        3750,
        7500), c('m', 'c')))
  mat[, 1] <- mat[, 1] + log10(volume / 10 * 40000 / dilution)
  return(mat)
}

#' algorithm to recover transcript counts with the detection threshold defined algoritm 
#' @export
#' 
relative2abs_mc <- function (relative_expr_matrix, t_estimate = estimate_t(relative_expr_matrix), m, c,
                             detection_threshold = 0.01430512, ERCC_controls = NULL, ERCC_annotation = NULL,
                             volume = 10, dilution = 40000, return_all = FALSE, cores = 1,
                             mixture_type = 1, verbose = FALSE)
{
  if (detection_threshold < 0.01430512 | detection_threshold >
      7500)
    stop("concentration detection limit should be between 0.01430512 and 7500")
  else mc_id <- round(detection_threshold/0.01430512)
  if (mixture_type == 1)
    mixture_name = "conc_attomoles_ul_Mix1"
  else mixture_name = "conc_attomoles_ul_Mix2"
  Cell <- NULL
  if (!is.null(ERCC_controls) | !is.null(ERCC_annotation)) {
    if (is.null(ERCC_controls) | is.null(ERCC_annotation))
      stop("If you want to transform the data to copy number with your spikein data, please provide both of ERCC_controls and ERCC_annotation data frame...")
    valid_ids <- which(ERCC_annotation[, mixture_name] >=
                         detection_threshold)
    if (verbose)
      message("Performing robust linear regression for each cell based on the spikein data...")
    molModels <- apply(ERCC_controls, 2, function(cell_exprs,
                                                  input.ERCC.annotation, valid_ids) {
      spike_df <- input.ERCC.annotation
      spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
      colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
      spike_df$numMolecules <- spike_df[, mixture_name] *
        (volume * 10^(-3) * 1/dilution * 10^(-18) * 6.02214129 *
           10^(23))
      spike_df$rounded_numMolecules <- round(spike_df[,
                                                      mixture_name] * (volume * 10^(-3) * 1/dilution *
                                                                         10^(-18) * 6.02214129 * 10^(23)))
      if (is.null(valid_ids))
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      else {
        spike_df <- spike_df[valid_ids, ]
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      }
      spike_df$log_fpkm <- log10(spike_df$FPKM)
      spike_df$log_numMolecules <- log10(spike_df$numMolecules)
      molModel <- tryCatch({
        molModel <- rlm(log_numMolecules ~ log_fpkm,
                        data = spike_df)
        molModel
      }, error = function(e) {
        print(e)
        NULL
      })
      molModel
    }, ERCC_annotation, valid_ids)
    if (verbose)
      message("Apply the fitted robust linear regression model to recovery the absolute copy number for all transcripts each cell...")
    norm_fpkms <- mcmapply(function(cell_exprs, molModel) {
      tryCatch({
        norm_df <- data.frame(log_fpkm = log10(cell_exprs))
        res <- 10^predict(molModel, type = "response",
                          newdata = norm_df)
      }, error = function(e) {
        rep(NA, length(cell_exprs))
      })
    }, split(as.matrix(relative_expr_matrix), rep(1:ncol(relative_expr_matrix),
                                                  each = nrow(relative_expr_matrix))), molModels, mc.cores = cores)
    k_b_solution <- data.frame(b = unlist(lapply(molModels,
                                                 FUN = function(x) {
                                                   intercept = x$coefficients[1]
                                                 })), k = unlist(lapply(molModels, FUN = function(x) {
                                                   slope = x$coefficients[2]
                                                 })))
    kb_model <- rlm(b ~ k, data = k_b_solution)
    m <- kb_model$coefficients[2]
    c <- kb_model$coefficients[1]
    if (return_all == T) {
      return(list(norm_cds = norm_fpkms, m = m, c = c,
                  k_b_solution = k_b_solution))
    }
    norm_fpkms
  }
  else {
    if (verbose)
      message("Estimating the slope and intercept for the linear regression between relative expression value and copy number based on the lowest detection limits...")
    mc_list <- get_mc_list(volume, dilution)
    # m <- mc_list[mc_id, 1]
    # c <- mc_list[mc_id, 2]
    split_relative_exprs <- split(as.matrix(relative_expr_matrix),
                                  col(relative_expr_matrix, as.factor = T))
    names(t_estimate) <- colnames(relative_expr_matrix)
    total_rna_df <- data.frame(Cell = colnames(relative_expr_matrix),
                               t_estimate = t_estimate)
    k_b_solution <- plyr::ddply(total_rna_df, .(Cell), function(x) {
      a_matrix <- matrix(c(log10(x[, "t_estimate"]), 1,
                           m, -1), ncol = 2, nrow = 2, byrow = T)
      colnames(a_matrix) <- c("k", "b")
      b_matrix <- matrix(c(0, -c), nrow = 2, byrow = T)
      k_b_solution <- t(solve(a_matrix, b_matrix))
    })
    rownames(k_b_solution) <- k_b_solution$Cell
    k_b_solution <- t(k_b_solution[, c(2, 3)])
    split_kb <- split(k_b_solution, col(k_b_solution, as.factor = T))
    
    if (verbose)
      message("Apply the estimated linear regression model to recovery the absolute copy number for all transcripts each cell...")
    adj_split_relative_expr <- mcmapply(norm_kb, split_kb,
                                        split_relative_exprs, mc.cores = cores)
    total_rna_df$estimate_k <- k_b_solution[1, ]
    total_rna_df$estimate_b <- k_b_solution[2, ]
    norm_cds <- adj_split_relative_expr
    row.names(norm_cds) <- row.names(relative_expr_matrix)
    colnames(norm_cds) <- colnames(relative_expr_matrix)
    if (verbose)
      message("Return results...")
    if (return_all == T) {
      return(list(norm_cds = norm_cds, m = m, c = c, k_b_solution = k_b_solution))
    }
    norm_cds
  }
}

#' Calculate the probability vector 
#' @export
#' 
makeprobsvec<-function(p){
  phat<-p/sum(p)
  phat[is.na(phat)] = 0
  phat
}

#' Calculate the probability matrix for a relative abundance matrix
#' @export
#' 
makeprobs<-function(a){
  colSums<-apply(a,2,sum)
  b<-t(t(a)/colSums)
  b[is.na(b)] = 0
  b
}

#' Calculate the Shannon entropy based on the probability vector
#' @export
#' 
shannon.entropy <- function(p) {
  if (min(p) < 0 || sum(p) <=0)
    return(Inf)
  p.norm<-p[p>0]/sum(p)
  -sum( log10(p.norm)*p.norm)
}

#' Calculate the Jessen-Shannon distance for two probability distribution 
#' @export
#' 
JSdistVec <- function (p, q) 
{
  JSdiv <- shannon.entropy((p + q)/2) - (shannon.entropy(p) + 
                                           shannon.entropy(q)) * 0.5
  JSdiv[is.infinite(JSdiv)] <- 1
  JSdiv[JSdiv < 0] <- 0
  JSdist <- sqrt(JSdiv)
  JSdist
}

#' Recover the absolute transcript counts based on m,c and t estimate for a single cell (Used in the optimization function)
#' @export
#' 
opt_norm_t <- function(t, fpkm, m, c, expr_thresh = 0.1, pseudocnt = NULL, return_norm = FALSE) {
  a_matrix <- matrix(c(log10(t), 1, m,
                       -1), ncol = 2, nrow = 2, byrow = T)
  colnames(a_matrix) <- c("k", "b")
  b_matrix <- matrix(c(0, -c), nrow = 2, byrow = T)
  kb <- t(solve(a_matrix, b_matrix))
  
  k <- kb[1]
  b <- kb[2]
  #print(kb)
  tmp <- k * log10(fpkm) + b
  abs_cnt <- 10^tmp
  
  if(return_norm) return(abs_cnt)
  
  if(!is.null(pseudocnt)){
    10^dmode(log10(abs_cnt[fpkm > expr_thresh] + pseudocnt)) #keep the original scale
    k * dmode(log10(fpkm[fpkm > expr_thresh])) + b
  }
  else
    10^dmode(log10(abs_cnt[abs_cnt > expr_thresh]))
}

#' recover transcript counts based on the algorithm with fix c and optimizing m 
#' @export
#' 
relative2abs_optim_fix_c <- function (relative_expr_matrix, t_estimate = estimate_t(relative_expr_matrix), m = -3.652201, c = 2.263576, m_rng = c(-10, -0.1),
                                      detection_threshold = 0.01430512, ERCC_controls = NULL, ERCC_annotation = NULL,
                                      volume = 10, dilution = 40000, return_all = FALSE, cores = 1, alpha_v = 1, total_RNAs = 50000, weight = 0.5,
                                      mixture_type = 1, verbose = FALSE, optim_num = 1) {
  if (detection_threshold < 0.01430512 | detection_threshold >
      7500)
    stop("concentration detection limit should be between 0.01430512 and 7500")
  else mc_id <- round(detection_threshold/0.01430512)
  if (mixture_type == 1)
    mixture_name = "conc_attomoles_ul_Mix1"
  else mixture_name = "conc_attomoles_ul_Mix2"
  Cell <- NULL
  if (!is.null(ERCC_controls) | !is.null(ERCC_annotation)) {
    if (is.null(ERCC_controls) | is.null(ERCC_annotation))
      stop("If you want to transform the data to copy number with your spikein data, please provide both of ERCC_controls and ERCC_annotation data frame...")
    valid_ids <- which(ERCC_annotation[, mixture_name] >=
                         detection_threshold)
    if (verbose)
      message("Performing robust linear regression for each cell based on the spikein data...")
    molModels <- apply(ERCC_controls, 2, function(cell_exprs,
                                                  input.ERCC.annotation, valid_ids) {
      spike_df <- input.ERCC.annotation
      spike_df <- cbind(spike_df, cell_exprs[row.names(spike_df)])
      colnames(spike_df)[length(colnames(spike_df))] <- "FPKM"
      spike_df$numMolecules <- spike_df[, mixture_name] *
        (volume * 10^(-3) * 1/dilution * 10^(-18) * 6.02214129 *
           10^(23))
      spike_df$rounded_numMolecules <- round(spike_df[,
                                                      mixture_name] * (volume * 10^(-3) * 1/dilution *
                                                                         10^(-18) * 6.02214129 * 10^(23)))
      if (is.null(valid_ids))
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      else {
        spike_df <- spike_df[valid_ids, ]
        spike_df <- subset(spike_df, FPKM >= 1e-10)
      }
      spike_df$log_fpkm <- log10(spike_df$FPKM)
      spike_df$log_numMolecules <- log10(spike_df$numMolecules)
      molModel <- tryCatch({
        molModel <- rlm(log_numMolecules ~ log_fpkm,
                        data = spike_df)
        molModel
      }, error = function(e) {
        print(e)
        NULL
      })
      molModel
    }, ERCC_annotation, valid_ids)
    if (verbose)
      message("Apply the fitted robust linear regression model to recovery the absolute copy number for all transcripts each cell...")
    norm_fpkms <- mcmapply(function(cell_exprs, molModel) {
      tryCatch({
        norm_df <- data.frame(log_fpkm = log10(cell_exprs))
        res <- 10^predict(molModel, type = "response",
                          newdata = norm_df)
      }, error = function(e) {
        rep(NA, length(cell_exprs))
      })
    }, split(as.matrix(relative_expr_matrix), rep(1:ncol(relative_expr_matrix),
                                                  each = nrow(relative_expr_matrix))), molModels, mc.cores = cores)
    k_b_solution <- data.frame(b = unlist(lapply(molModels,
                                                 FUN = function(x) {
                                                   intercept = x$coefficients[1]
                                                 })), k = unlist(lapply(molModels, FUN = function(x) {
                                                   slope = x$coefficients[2]
                                                 })))
    kb_model <- rlm(b ~ k, data = k_b_solution)
    m <- kb_model$coefficients[2]
    c <- kb_model$coefficients[1]
    if (return_all == T) {
      return(list(norm_cds = norm_fpkms, m = m, c = c,
                  k_b_solution = k_b_solution))
    }
    norm_fpkms
  }
  else {
    split_relative_exprs <- split(as.matrix(relative_expr_matrix),
                                  col(relative_expr_matrix, as.factor = T))
    names(t_estimate) <- colnames(relative_expr_matrix)
    
    if(verbose)
      message('optimizating mc values...')
    #the t_estimate may also need to optimized:
    for(optim_iter in 1:optim_num) {
      if(verbose)
        message(paste('optimization cycle', optim_iter, '...'))
      
      optim_para <- optim(par = c(m = m),
                          optim_mc_func_fix_c, gr = NULL, c = c, t_estimate = t_estimate,
                          alpha = alpha_v, total_RNAs = total_RNAs, cores = cores, weight = weight, pseudocnt = 0.01,
                          relative_expr_matrix = relative_expr_matrix, split_relative_expr_matrix = split_relative_exprs,
                          method = c("Brent"),
                          lower = c(rep(as.vector(t_estimate) - 0, 0), m_rng[1]), #search half low or up of the t_estimate
                          upper = c(rep(as.vector(t_estimate) + 0, 0), m_rng[2]), #m, c is between (-0.1 to -10 and 0.1 to 10)
                          control = list(factr = 1e12, pgtol = 1e-3, trace = 1, ndeps = c(1e-3) ), #as.vector(t_estimate) / 1000,
                          hessian = FALSE)
      if(verbose)
        message('optimization is done!')
      
      m <- optim_para$par[1]
      c <- c
      
      total_rna_df <- data.frame(Cell = colnames(relative_expr_matrix),
                                 t_estimate = t_estimate)
      if (verbose)
        message("Estimating the slope and intercept for the linear regression between relative expression value and copy number...")
      
      k_b_solution <- plyr::ddply(total_rna_df, .(Cell), function(x) {
        a_matrix <- matrix(c(log10(x[, "t_estimate"]), 1,
                             m, -1), ncol = 2, nrow = 2, byrow = T)
        colnames(a_matrix) <- c("k", "b")
        b_matrix <- matrix(c(0, -c), nrow = 2, byrow = T)
        k_b_solution <- t(solve(a_matrix, b_matrix))
      })
      
      rownames(k_b_solution) <- k_b_solution$Cell
      k_b_solution <- t(k_b_solution[, c(2, 3)])
      split_kb <- split(k_b_solution, col(k_b_solution, as.factor = T))
      if (verbose)
        message("Apply the estimated linear regression model to recovery the absolute copy number for all transcripts each cell...")
      adj_split_relative_expr <- mcmapply(norm_kb, split_kb,
                                          split_relative_exprs, mc.cores = cores)
      total_rna_df$estimate_k <- k_b_solution[1, ]
      total_rna_df$estimate_b <- k_b_solution[2, ]
      norm_cds <- adj_split_relative_expr
      row.names(norm_cds) <- row.names(relative_expr_matrix)
      colnames(norm_cds) <- colnames(relative_expr_matrix)
      
      #update t_estimate, alpha_v, total_RNAs
      t_estimate <- 10^(-(m + c / total_rna_df$estimate_k))
      alpha_v <- estimate_t(norm_cds) #apply(norm_cds, 2, function(x) mlv(round(x)[round(x) > .1], method = "mfv")$M) 
      total_RNAs <- apply(norm_cds, 2, sum)
    }
    
    if (verbose)
      message("Return results...")
    if (return_all == T) {
      return(list(norm_cds = norm_cds, m = m, c = c, k_b_solution = k_b_solution))
    }
    norm_cds
  }
}

#' use the deconvoluated linear regression parameters to normalize the log_relative_expr
#' Calculate the dimension mode
#' @export
norm_kb <- function(kb, exprs_cds) {
  k <- kb[1]
  b <- kb[2]
  tmp <- k * log10(exprs_cds) + b
  norm_exprs <- 10^tmp
  
  norm_exprs
}

#' Calculate the dimension mode
#' @export
dmode <- function(x, breaks="Sturges") {
  den <- density(x, kernel=c("gaussian"))
  ( den$x[den$y==max(den$y)] )
}


#' A function to perform the comparison between different datasets
#' @param pval_df The dataframe for the p-val we calculated with different differential gene expression tests
#' @param true_data The true (1) or false (0) DEG assignment for each gene based on permutation pval 
#' @param return_plot A logic argument determing whether or not we should return the plot 
#' @export
#'
compare_DEG_test <- function(pval_df, true_data, return_plot = FALSE, step_size = 0.01) {  
  #apply on a data.frame where each row will generate two rows 
  roc_mat <- matrix()
  pre_rec_mat <- matrix()
  num_gene <- matrix(rep(0, ncol(pval_df) * 4), ncol = 4, 
                     dimnames = list(colnames(pval_df), c("TP", "FP", "TN", "FN")))
  
  test_type <- paste('result_', colnames(pval_df), sep = '')
  
  for(i in 1:ncol(pval_df)) {
    p_vec <- pval_df[, i]
    roc_tmp <- ROC.curve(p_vec = p_vec, true_d = true_data, p_thrsld = seq(0, 1, by = step_size))
    pre_rec_tmp <- PRE_REC.curve(p_vec = p_vec, true_data = true_data, p_thrsld = seq(0, 1, by = step_size))
    
    dim(pre_rec_tmp)
    if(i == 1) {
      roc_mat = roc_tmp
      pre_rec_mat = pre_rec_tmp
    }
    else {
      roc_mat <- rbind(roc_mat, roc_tmp)
      pre_rec_mat <- rbind(pre_rec_mat, pre_rec_tmp)
    }
    num_gene[i, 1] <- sum(true_data * (p_vec <= p_thrsld), na.rm = T) #TP
    num_gene[i, 2] <- sum((1 - true_data) * (p_vec <= p_thrsld), na.rm = T) #FP
    num_gene[i, 3] <- sum((1 - true_data) * (p_vec > p_thrsld), na.rm = T) #TN
    num_gene[i, 4] <- sum(true_data * (p_vec > p_thrsld), na.rm = T) #FN
    
    #find the gene numbers in each categories
    TP_tmp <- which((true_data * (p_vec <= p_thrsld)) == 1) 
    FP_tmp <- which(((1 - true_data) * (p_vec <= p_thrsld)) == 1) 
    TN_tmp <- which(((1 - true_data) * (p_vec > p_thrsld)) == 1) 
    FN_tmp <- which((true_data * (p_vec > p_thrsld)) == 1) 
    list_tmp <- list(TP = TP_tmp, FP = FP_tmp, TN = TN_tmp, FN = FN_tmp)
    assign(test_type[i], list_tmp)
  }
  
  #set the row name for roc_mat, convert roc_mat to dataframe with each column represent one test and one category (FPR/TPR)
  #change roc_df row to column because we need to use mapply for calculting AUC
  pval_2n <- 2 * ncol(pval_df)
  roc_row_name <- rep(0, pval_2n)
  roc_row_name[seq(1, pval_2n, 2)] <- paste(names(pval_df), "FPR", sep = "_")
  roc_row_name[seq(2, pval_2n, 2)] <- paste(names(pval_df), "TPR", sep = "_")
  row.names(roc_mat) <- roc_row_name
  roc_df <- as.data.frame(t(roc_mat))
  
  #do the same for pre_rec_mat
  pre_rec_row_name <- rep(0, pval_2n)
  pre_rec_row_name[seq(1, pval_2n, 2)] <- paste(names(pval_df), "recall", sep = "_")
  pre_rec_row_name[seq(2, pval_2n, 2)] <- paste(names(pval_df), "precision", sep = "_")
  row.names(pre_rec_mat) <- pre_rec_row_name
  pre_rec_df <- as.data.frame(t(pre_rec_mat))
  
  # roc_df <- as.data.frame(cbind(t(M.ROC_abs), t(M.ROC_std))) 
  
  # colnames(roc_df) <- c("FPR_abs", "TPR_abs", "FPR_std", "TPR_std")
  
  #df for the ROC/pre_re curve
  mlt_roc_df <- data.frame(FPR = as.vector(as.matrix(roc_df[, seq(1, pval_2n, 2)])), 
                           TPR = as.vector(as.matrix(roc_df[, seq(2, pval_2n, 2)])),
                           Test_type = rep(colnames(pval_df), each = 1 / step_size + 1)) #each is the ncol of the roc_mat
  mlt_pre_rec_df <- data.frame(RECALL = as.vector(as.matrix(pre_rec_mat[seq(1, pval_2n, 2), ])), 
                               PRECISION = as.vector(as.matrix(pre_rec_mat[seq(2, pval_2n, 2), ])),
                               Test_type = rep(colnames(pval_df), each  = 1 / step_size + 1))
  message('calculating AUC')
  #calculate the AUC 
  roc_FPR_df <- (roc_df[, seq(1, pval_2n, by = 2)])
  roc_TPR_df <- (roc_df[, seq(2, pval_2n, by = 2)])
  
  auc <- mapply(AUC, roc_FPR_df, roc_TPR_df)
  
  p1 <- 
    ggplot(data = mlt_roc_df) + geom_line(aes(x = FPR, y = TPR, color = Test_type), alpha = .7) + 
    ggtitle("ROC curve for different gene expression test") + 
    geom_abline(color = "red") + scale_color_discrete(name = "Test", 
                                                      label = c(paste(sort(colnames(pval_df)), ':', " AUC = ", auc[order(colnames(pval_df))]))) + 
    xlab("FPR") + ylab("TPR") + 
    monocle_theme_opts()
  
  mlt_gene_num <- melt(num_gene)
  #mlt_gene_num$Test <- row.names(mlt_gene_num)
  
  p2 <- 
    ggplot(data = mlt_gene_num) + 
    geom_bar(aes(x = factor(Var1), y = value, group = Var1, fill = Var2), stat = "identity", alpha = 0.7) + 
    monocle_theme_opts() + 
    ylab("num") + xlab('Test') + 
    scale_color_discrete(name = "Test")
  
  # pdf("ROC_bar_8_26_.pdf", width = 25, height = 8)
  # dev.off()
  
  #calculate the AUC
  recall_df <- (pre_rec_df[, seq(1, pval_2n, by = 2)])
  precision_df <- (pre_rec_df[, seq(2, pval_2n, by = 2)])
  
  pr_AUC <- mapply(AUC, recall_df, precision_df)
  message('returning results')
  
  #return all the final variable generated in the calculation 
  if(return_plot)  return(list(roc_df = roc_df, num_gene = num_gene, mlt_roc_df = mlt_roc_df, mlt_gene_num = mlt_gene_num, 
                               pre_rec_df = pre_rec_df, AUC = auc, pr_AUC = pr_AUC, test_type = mget(test_type), p1 = p1, p2 = p2))
  else 
    return(list(roc_df = roc_df, num_gene = num_gene, mlt_roc_df = mlt_roc_df, mlt_gene_num = mlt_gene_num, 
                pre_rec_df = pre_rec_df, AUC = auc, pr_AUC = pr_AUC, test_type = mget(test_type)))
}

#' Perform pca analysis 
#' @param data
#' @export
PCA <- function(data, ...) {
  res <- prcomp(data, center = F, scale = F)
  t(res$rotation[, 1:2])
}

#' Generate a data.frame for making roc curves
#' @param p_value Pvalue from a test
#' @param classification Classification from the gold dataset
#' @export
generate_roc_df <-function(p_value, classification) {
  pred_p_value <- prediction(p_value, classification)
  perf_tpr_fpr <- performance(pred_p_value, "tpr", "fpr")
  
  fpr = perf_tpr_fpr@y.values
  
  tpr = perf_tpr_fpr@x.values
  
  perf_auc <- performance(pred_p_value, "auc")
  auc <- perf_auc@y.values
  
  data.frame(tpr = tpr, fpr = fpr, auc = auc)
}
