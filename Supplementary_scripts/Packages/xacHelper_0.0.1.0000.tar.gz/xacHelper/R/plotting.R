# Multiple plot function
#
#' param ... ggplot object
#' @param plotlist plotlist (as a list of ggplot objects)
#' @param file Category for each gene shown in the element_all vector, the order of the two vectors should be the same
#' @param cols Number of columns in layout
#' @param layout A matrix specifying the layout. If present, 'cols' is ignored.
#' If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
#' then plot 1 will go in the upper left, 2 will go in the upper right, and
#' 3 will go all the way across the bottom.
#' @export
#' 
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

#3 different ways to make the venn-diagram plot 
#' Five way venn diagarm (ugly but can provide number of genes at each intersection region)
#' 
#' @param deg_list a list of character vectors used for the venn diagram, usually the list of significant genes' name from different Differential Gene Tests
#' @export

overlap_venn <- function(deg_list) {
  if(length(deg_list) > 5) {
    stop('Only support intersection of groups up to five groups!')
  }
  source("http://faculty.ucr.edu/~tgirke/Documents/R_BioCond/My_R_Scripts/overLapper.R")
  OLS <- overLapper(setlist = deg_list, sep="_", type="vennsets")
  counts <- sapply(OLS$Venn_List, length)
  vennPlot(counts=counts, ccol=c(rep(1,30),2), lcex=1.5, ccex=c(rep(1.5,5), rep(0.6,25),1.5)) 
}

#' Pretty venn diagram based on the venneuler package
#' 
#' @param element_all Character vector used for the venn diagram, usually the list of significant genes' name from different Differential Gene Tests
#' @param sets_all Category for each gene shown in the element_all vector, the order of the two vectors should be the same
#' @export

venneuler_venn <- function(element_all, sets_all) {
  # vd <- venneuler(c(A=0.3, B=0.3, C=1.1, "A&B"=0.1, "A&C"=0.2, "B&C"=0.1 ,"A&B&C"=0.1)) #sets, & is the interaction 
  # plot(vd)
  # same as c(A=1, ‘A&B&C‘=1, C=1)
  # element_all <- c(deg_abs_name, deg_abs_name_lib, deg_std_name, deg_gene_name, deg_iso_name, deg_tpm_adj_name, deg_tpm_gene_name, deg_tpm_iso_name)
  # sets_all <- c(rep('spike_abs', length(deg_abs_name)), seq('spike_lib', length(deg_abs_name_lib)), seq('fpkm', length(deg_std_name)), seq('fpkm_norm_gene', length(deg_gene_name)), 
  # seq('fpkm_norm_isoform', length(deg_iso_name)), seq('tpm_norm_adjust', length(deg_tpm_adj_name)), seq('tpm_norm_gene', length(deg_tpm_gene_name)), seq('tpm_norm_isoform', length(deg_tpm_iso_name)))
  
  m <- data.frame(elements=element_all, sets=sets_all) #first column is element while each column is the mapping to the sets 
  v <- venneuler(m)
  plot(v)
  
  # m <- as.matrix(data.frame(A=c(1.5, 0.2, 0.4, 0, 0), 
  #                           # without weight
  #                           v <- venneuler(m > 0)
  #                           plot(v)
  #                           # with weights
  #                           v <- venneuler(m)
  #                           plot(v)
  #                           m <- as.matrix(data.frame(A=c(1.5, 0.2, 0.4, 0, 0), B = c(0,  0.2, 0  , 1, 0), C=c(0  , 0  , 0.3, 0, 1))) #each column is the set where each element in a row is the co-ocurrence 
  #                           v <- venneuler(m > 0)
  #                           plot(v)
  #                           v <- venneuler(m)
  #                           plot(v)
}

#venn diagram to show the overlapping between different methods 
#this seems not generalizable...

#' 3 way venn diagram based on vennDiagram package 
#' 
#' @param deg_list a list of three character vectors used for venn diagram, usually the list of significant genes' name from different Differential Gene Tests
#' @param category a character vector for the corresponding names for each vector in the deg_list 
#' @export

vendiag_venn <- function(deg_list, category = c("spike", "fpkm", "trick")) {
  deg_abs <- deg_list[[1]]
  deg_std <- deg_list[[2]]
  deg_gene <- deg_list[[3]]
  
  overlap_deg_abs_std <- intersect(deg_abs, deg_std)
  overlap_deg_std_gene <- intersect(deg_std, deg_gene)
  overlap_deg_abs_gene <- intersect(deg_abs, deg_gene)
  overlap_deg_abs_std_gene <- intersect(deg_abs, deg_std, deg_gene)
  
  grid.newpage()
  venn.plot <- draw.triple.venn(
    area1    = nrow(deg_abs),
    area2    = nrow(deg_std),
    area3    = nrow(deg_gene),
    n12      = length(overlap_deg_abs_std),
    n23      = length(overlap_deg_std_gene),
    n13      = length(overlap_deg_abs_gene),
    n123     = length(overlap_deg_abs_std_gene),
    category = category,
    fill = c("blue", "red", "green"),
    lty = "blank",
    cex = 2,
    cat.cex = 2,
    cat.col = c("blue", "red", "green"),
    euler.d = TRUE,
    scaled = TRUE,
    alpha = c(0.5)
  );
  grid.draw(venn.plot)
}        

#' a function for plotting the 3d landscape based on the rgl package as well as the countour plot
#' 
#' @param X, Y, Z, x, y, z the data.frame for the values on the x, y, z axis
#' @param color_len the number of the colors used for coloring the surface based on the Z-axis
#' @export

plot3D <- function(X = X, Y = Y, Z = Z, coord_lab = c('x', 'y', 'z'), color_len = 100, file_name = '3d_mc_rmse.png') { #x, y: x, y coordinate values, Z: the height 
  open3d()
  colorjet <- jet.colors(color_len)
  
  rgl.surface(x = X, y = Z, 
              z = Y, 
              color=colorzjet[findInterval(Z, seq(min(Z), max((Z)), length = color_len))], 
              xlab = coord_lab[1], ylab = coord_lab[3], zlab = coord_lab[2]
  )
  axes3d()
  clear3d(type = "lights")
  light3d(theta=0, phi=0)
  grid3d("x")
  grid3d("y")
  grid3d("z") + xlab('m')
  #grid3d("z+") + xlab('m') 
  
  rgl.snapshot(file_name)
  
  #contour plot
  filled.contour(x = X, y = Y, z = Z)  
}

#' a function to plot 15 figures for comparing the performance of different DEG tests 
#'  
#' @param cb_mlt_roc_df a data.frame with 'FPR', 'TPR', 'Test_type', 'thrsld' for each column
#' @param cb_mlt_gene_num a data.frame with 'Var1' (DEG test type), 'Var2' (TP, FP, TN, FN), 'Value' (gene number), 'thrsld' (pval threshold for calculating the gene numbers)
#' @param DEG_test_list a list of differntial gene test
#' @param thrsld
#' @param test_type
#' @param xlim
#' @param permutation_pval abs_permutate_pval
#' @export
#' 
DEG_test_plot <- function(cb_mlt_roc_df, cb_mlt_gene_num, DEG_test_list = mget(ls(pattern = 'Test$')), thrsld = unique(cb_mlt_roc_df$thrsld)[5], 
                          test_type = c("std_dtable_condition_gene_nbinomTest", "diff_fpkm", "diff_DESeq2", "diff_scde"), xlim = 0.1, permutation_pval = abs_permutate_pval) {
  #Internal comparsion or external conparsion on the following plots
  #ROC, barplot, F1 score, alpha-FDR plot
  cb_mlt_roc_df_ori <- cb_mlt_roc_df
  cb_mlt_gene_num_ori <- cb_mlt_gene_num
  cb_mlt_gene_num_ori_TPFN <- cb_mlt_gene_num[cb_mlt_gene_num$Var1 %in% test_type, ]
  
  if(length(thrsld)) {
    
    #cb_mlt_roc_df <- subset(cb_mlt_roc_df, thrsld == unique(cb_mlt_roc_df$thrsld)[5] & 
    #                                       Test_type %in% c("std_dtable_condition_gene_nbinomTest", "diff_fpkm", "diff_DESeq2", "diff_scde"))
    cb_mlt_roc_df <- cb_mlt_roc_df[cb_mlt_roc_df$thrsld == unique(cb_mlt_roc_df$thrsld)[5] & cb_mlt_roc_df$Test_type %in% test_type, ]
    
    #cb_mlt_gene_num <- subset(cb_mlt_gene_num, thrsld == unique(cb_mlt_roc_df$thrsld)[5] &
    #                                           Test_type %in% c("std_dtable_condition_gene_nbinomTest", "diff_fpkm", "diff_DESeq2", "diff_scde"))
    cb_mlt_gene_num <- cb_mlt_gene_num[cb_mlt_gene_num$thrsld == unique(cb_mlt_gene_num$thrsld)[5] & cb_mlt_gene_num$Var1 %in% test_type, ]
    
    print(head(cb_mlt_gene_num))
  }
  
  p1 <- 
    ggplot(data = cb_mlt_roc_df) + geom_line(aes(x = FPR, y = TPR, linetype = Test_type, color = Test_type), alpha = .7) + 
    ggtitle("ROC curve for different gene expression test") + 
    geom_abline(color = "red") + #scale_color_discrete(name = "Test", label = c(paste(sort(colnames(pval_df)), ':', " AUC = ", auc[order(colnames(pval_df))]))) + 
    xlab("FPR") + ylab("TPR") + 
    monocle_theme_opts() + facet_wrap(~thrsld, ncol = 1)
  
  p1.1 <- 
    ggplot(data = subset(cb_mlt_roc_df, FPR <= 0.1)) + geom_line(aes(x = FPR, y = TPR, linetype = Test_type, color = Test_type), alpha = .7) + 
    ggtitle("ROC curve for different gene expression test") + 
    geom_abline(color = "red") + #scale_color_discrete(name = "Test", label = c(paste(sort(colnames(pval_df)), ':', " AUC = ", auc[order(colnames(pval_df))]))) + 
    xlab("FPR") + ylab("TPR") + 
    monocle_theme_opts() + facet_wrap(~thrsld, ncol = 1)
  
  #facet by Test type
  p2 <- 
    ggplot(data = cb_mlt_roc_df) + geom_line(aes(x = FPR, y = TPR, group = thrsld, linetype = Test_type, color = Test_type), alpha = .7) + 
    ggtitle("ROC curve for different gene expression test") + 
    geom_abline(color = "red") + #scale_color_discrete(name = "Test", label = c(paste(sort(colnames(pval_df)), ':', " AUC = ", auc[order(colnames(pval_df))]))) + 
    xlab("FPR") + ylab("TPR") + 
    monocle_theme_opts() + facet_wrap(~Test_type, ncol = 1)
  
  p2.1 <- 
    ggplot(data = subset(cb_mlt_roc_df, FPR <= 0.1)) + geom_line(aes(x = FPR, y = TPR, group = thrsld, linetype = Test_type, color = Test_type), alpha = .7) + 
    ggtitle("ROC curve for different gene expression test") + 
    geom_abline(color = "red") + #scale_color_discrete(name = "Test", label = c(paste(sort(colnames(pval_df)), ':', " AUC = ", auc[order(colnames(pval_df))]))) + 
    xlab("FPR") + ylab("TPR") + 
    monocle_theme_opts() + facet_wrap(~Test_type, ncol = 1) 
  
  p3 <- 
    #ggplot(data = cb_mlt_gene_num[cb_mlt_gene_num$Var2 !=  'TN', ]) + #    
    ggplot(data = cb_mlt_gene_num) + 
    geom_bar(aes(x = factor(Var1), y = value, group = Var1, fill = Var2), stat = "identity", alpha = 0.7) + 
    monocle_theme_opts() + 
    ylab("num") + xlab('Test') + 
    scale_color_discrete(name = "Test") + facet_wrap(~thrsld, ncol = 1, scales = "free_y")
  
  p4 <- 
    #ggplot(data = cb_mlt_gene_num[cb_mlt_gene_num$Var2 !=  'TN', ]) + #    
    ggplot(data = cb_mlt_gene_num) + 
    geom_bar(aes(x = factor(thrsld), y = value,  group = Var1, fill = Var2), stat = "identity", alpha = 0.7) + 
    monocle_theme_opts() + 
    ylab("num") + xlab('Test') + 
    scale_color_discrete(name = "Test") + facet_wrap(~Var1, ncol = 1, scales = "free_y")
  
  #calculating the F-score
  cb_gene_num <- dcast(cb_mlt_gene_num_ori, Var1 + thrsld  ~ Var2, value.var = 'value')
  cb_gene_num$F1_score <- apply(cb_gene_num, 1, function(x) F_score(as.numeric(x[c(3:6)])))
  cb_gene_num$method <- rep(0, nrow(cb_gene_num))
  cb_gene_num$sharing <- rep(0, nrow(cb_gene_num))
  
  blind_id <- grep("blind", cb_gene_num$Var1)
  pool_id <- grep("pool", cb_gene_num$Var1)
  condition_id <- grep("condition", cb_gene_num$Var1)
  cb_gene_num$method[blind_id] <- 'blind'
  cb_gene_num$method[pool_id] <- 'pool'
  cb_gene_num$method[condition_id] <- 'condition'
  
  fit_id <- grep("fit", cb_gene_num$Var1)
  max_id <- grep("max", cb_gene_num$Var1)
  gene_id <- grep("gene", cb_gene_num$Var1)
  cb_gene_num$sharing[fit_id] <- 'fit'
  cb_gene_num$sharing[max_id] <- 'max'
  cb_gene_num$sharing[gene_id] <- 'gene'
  #plot the F-score
  p5 <- 
    qplot(x = thrsld, y = F1_score, color = Var1, linetype = Var1, data = cb_gene_num, geom = 'line', size = I(2)) + monocle_theme_opts()
  #facet the above result: 
  p5.1 <- 
    qplot(x = thrsld, y = F1_score, color = Var1, linetype = Var1, data = cb_gene_num, geom = 'line', size = I(2)) + monocle_theme_opts() + 
    facet_wrap(~ method, scale = 'fix', ncol = 2)
  p5.2 <- 
    qplot(x = thrsld, y = F1_score, color = Var1, linetype = Var1, data = cb_gene_num, geom = 'line', size = I(2)) + monocle_theme_opts() + 
    facet_wrap(~ sharing, scale = 'fix', ncol = 2)
  #plot the TP/FP along the time 
  p6 <- 
    qplot(x = thrsld, y = value, color = Var1, linetype = Var1, data = cb_mlt_gene_num_ori_TPFN, geom = 'line', size = I(2)) + monocle_theme_opts()  + facet_wrap(~ Var2, scale = 'free_y', ncol = 2)
  
  #show also the dispersion value 
  
  #show FDR as a function of alpha 
  #improve this
  precision_recall_cal <- function(est_pval, true_pval, type = c('precision', 'recall', 'fdr'), q_thrsld = 0.1, true_q_thrsld = 0.1){
    qval <- p.adjust(est_pval, method = 'BH')
    names(qval) <- est_pval_name
    true_qval <- p.adjust(true_pval, method = 'BH')
    
    fp <- setdiff(names(qval[qval <= q_thrsld]), names(true_pval[true_qval <= true_q_thrsld])) #false positive
    tp <- intersect(names(qval[qval <= q_thrsld]), names(true_qval[true_qval <= true_q_thrsld])) #true positive
    fn <- setdiff(names(qval[qval > q_thrsld]), names(true_qval[true_qval > true_q_thrsld]))
    
    if(type == 'precision') length(tp) / length(union(fp, tp)) #precision = tp / (tp + fp)
    else if(type == 'recall') length(tp) / length(union(fp, fn)) #precision = tp / (tp + fn)
    else if(type == 'fdr')  length(tp) / length(union(tp, fn))
  }
  
  alpha_fdr <- function(alpha_vec, est_pval, true_pval, est_pval_name, type = c('precision', 'recall', 'fdr')) {
    qval <- p.adjust(est_pval, method = 'BH')
    names(qval) <- est_pval_name
    true_qval <- p.adjust(true_pval, method = 'BH')
    
    #FDR = v / (v + s)
    unlist(lapply(alpha_vec, function(alpha, true_q_thrsld = 0.1) {
      fp <- setdiff(names(qval[qval <= alpha]), names(true_pval[true_qval <= true_q_thrsld])) #false positive
      tp <- intersect(names(qval[qval <= alpha]), names(true_qval[true_qval <= true_q_thrsld])) #true positive
      fn <- setdiff(names(qval[qval > alpha]), names(true_qval[true_qval > true_q_thrsld]))
      
      if(type == 'precision') length(tp) / length(union(fp, tp)) #precision = tp / (tp + fp)
      else if(type =='recall') length(tp) / length(union(fp, fn)) #precision = tp / (tp + fn)
      else if(type == 'fdr')  length(tp) / length(union(tp, fn))
      
    })) #/ sum(true_pval < alpha, na.rm = T)
  }
  
  alpha_vec <- seq(0, 1, length.out = 1000)
  true_pval <- permutate_pval #permutation_pval
  true_pval <- true_pval[gene_list] #gene_list
  #pval_df
  
  # fdr <- lapply(alpha_vec, function(x) alpha_fdr(pval_df[, 1], p.adjust(true_pval, method = 'BH'), x))
  # result <- mcmapply(alpha_fdr, split(t(alpha_vec), col(t(alpha_vec), as.factor = T)), split(as.matrix(pval_df), col(as.matrix(pval_df), as.factor = T)), true_pval, mc.cores = 8)
  alpha_precision_res <- apply(pval_df, 2, function(x) alpha_fdr(alpha_vec, x, true_pval, row.names(pval_df)))
  alpha_recall_res <- apply(pval_df, 2, function(x) alpha_fdr(alpha_vec, x, true_pval, row.names(pval_df), type = 'recall'))
  alpha_fdr_res <- apply(pval_df, 2, function(x) alpha_fdr(alpha_vec, x, true_pval, row.names(pval_df), type = 'fdr'))
  
  p7 <- 
    qplot(Var1 / 1000, value, geom = 'line', data = melt(alpha_fdr_res), color = Var2, linetype = Var2) + monocle_theme_opts() + 
    geom_abline(color = 'red') + ggtitle('alpha VS fdr') + facet_wrap(~Var2, scale = 'free_y', ncol = round(sqrt(dim(alpha_fdr_res)))) + xlab('alpha') + ylab('fdr')
  
  p8 <- 
    qplot(Var1 / 1000, value, geom = 'line', data = melt(alpha_precision_res), color = Var2, linetype = Var2) + monocle_theme_opts() + 
    geom_abline(color = 'red') + ggtitle('alpha VS precision') + facet_wrap(~Var2, scale = 'free_y', ncol = round(sqrt(dim(alpha_precision_res)))) + xlab('alpha') + ylab('precision')
  
  p9 <- 
    qplot(Var1 / 1000, value, geom = 'line', data = melt(alpha_recall_res), color = Var2, linetype = Var2) + monocle_theme_opts() + 
    geom_abline(color = 'red') + ggtitle('alpha VS recall') + facet_wrap(~Var2, scale = 'free_y', ncol = round(sqrt(dim(alpha_recall_res)))) + xlab('alpha') + ylab('recall')
  
  #plot precision-recall curve: 
  mlt_alpha_fdr_res <- melt(alpha_fdr_res)
  mlt_alpha_precision_res <- melt(alpha_precision_res)
  mlt_alpha_recall_res <- melt(alpha_recall_res)
  pre_rec_df <- cbind(mlt_alpha_precision_res[, c('Var2', 'value')], mlt_alpha_recall_res[, 'value'])
  colnames(pre_rec_df) <- c('Type', 'precision', 'recall')
  
  p10 <- 
    qplot(recall, precision, geom = 'line', data = pre_rec_df, color = Type, linetype = Type) + monocle_theme_opts() + 
    geom_abline(color = 'red') + ggtitle('recall VS precision') + facet_wrap(~Var2, scale = 'free_y', ncol = round(sqrt(dim(pre_rec_df)))) + xlab('recall') + ylab('precision')
  
  #add the precision-recall F1 score bar plots: 
  pre_rec_f1_df <- t(rbind(precision = alpha_precision_res[100, ], recall = alpha_recall_res[100, ], F1_score = cb_gene_num[cb_gene_num$thrsld == 0.1, 'F1_score']))
  pre_rec_f1_df <- as.data.frame(pre_rec_f1_df)
  pre_rec_f1_df$Type <- row.names(pre_rec_f1_df)
  
  p11 <- 
    qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = Type, data = melt(pre_rec_f1_df)) + facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('')
  
  message('pass p10')
  #Venn diagram
  # message('test this', names(DEG_test_list))
  # make_deg_list <- function(DEG_test_list, q_thrsld = q_thrsld) {
  #   # message(i, ": ", names(DEG_test_list))
  #   deg_list <- list()
  #   length(deg_list) <- length(DEG_test_list)
  #   for(i in 1:length(DEG_test_list)) {
  #     message(i, ": ", names(DEG_test_list)[i])
  #     if(names(DEG_test_list)[i] == 'nbinomTest') next;
  #     if("padj" %in% colnames(DEG_test_list[[i]])) {
  #       deg_list[[i]] <- row.names(DEG_test_list[[i]][which(DEG_test_list[[i]][, 'padj'] <0.1), ])
  #       names(deg_list)[i] <- names(DEG_test_list)[i]
  #     }
  #     else if("qval" %in% colnames(DEG_test_list[[i]])) {
  #       deg_list[[i]] <- row.names(DEG_test_list[[i]][which(DEG_test_list[[i]][, 'qval'] <0.1), ])
  #       names(deg_list)[i] <- names(DEG_test_list)[i]
  #     }
  #     else if(!is.data.frame(DEG_test_list[[i]])) {
  #       deg_list[[i]] <-DEG_test_list[[i]]$deg_name 
  #       names(deg_list)[i] <- names(DEG_test_list)[i]            
  #     }
  #     else  message("qval not found: ", names(DEG_test_list)[i])
  #   }
  #   return(deg_list)
  # }
  
  # deg_list <- make_deg_list(DEG_test_list)
  # names(deg_list)
  # overlap_venn(deg_list[c(1, 2, 3)])
  #plot clustering 
  
  return(list(p1, p2, p3, p4, p5, p5.1, p5.2, p6, p1.1, p2.1, p7, p8, p9, p10))
}

#' plot goodness of fit 
#' 
#' @param gd_fit_res a data.frame with the p_vals for Differential Gene Test based on different fitting models (negative binomial or zero-inflated negative binomial used in our paper) 
#' @param percentage A logic argument, either show the row counts or the percentages 
#' @param gene_list a character vector for selecting the genes used for the calculation
#' @export
#' 
plot_gd_fit <- function(gd_fit_res, return = T, percentage = T, gene_list = valid_gene_id_cell) {
  valid_id <- which(apply(apply(gd_fit_res[, c('nb_pvalue', 'zinb_pvalue')], 2, function(x) !is.na(x)), 1, all))
  message('all successfully fitting gene number: ', length(valid_id))
  
  gd_fit_num <- apply(gd_fit_res[valid_id, ], 2, function(x) {sum(x > 0.01, na.rm = T)} )
  if(percentage)
    gd_fit_num <- gd_fit_num / length(valid_id) 
  
  na_num <- apply(gd_fit_res[gene_list, ], 2, function(x) {sum(!is.na(x))} )
  message('number of valid genes for fitting is ', length(gene_list))
  
  if(percentage)
    na_num <- na_num / length(gene_list)
  
  mlt_gd_fit_num <- melt(gd_fit_num)
  mlt_gd_fit_num$type <- names(gd_fit_num)
  mlt_na_num <- melt(na_num)
  mlt_na_num$type <- names(na_num)
  
  p1 <- 
    qplot(factor(type), value, geom = 'bar', stat = 'identity', fill = type, data = mlt_gd_fit_num) +
    ggtitle("goodness of fit for different distribution") + xlab('Type of fit') + ylab('number of genes') + monocle_theme_opts() + 
    theme(axis.text.x = element_text(angle = 30))
  
  p2 <- 
    qplot(factor(type), value, geom = 'bar', stat = 'identity', fill = type, data = mlt_na_num) +
    ggtitle("Distribution of fitting success") + xlab('Type of fit') + ylab('number of successful fitting') + monocle_theme_opts() + 
    theme(axis.text.x = element_text(angle = 30))
  
  if(return)
    multiplot(p1, p2, cols = 2)
  else 
    return(list(p1 = p1, p2 = p2))
}

#' plot the correlation between mc/spikein regression for the quake marker / spike in transcripts 
#' @param absolute_cds CellDataFrame for the transcript counts based on spike-in regression
#' @param mc_adj_cds CellDataFrame for the transcript counts based on new algorithm
#' @param marker_ids Emsemble ids for the marker genes to test for correlation 
#' @param ercc_ids The name for the ERCC spike-in transcripts 
#' @param gene_name The official name for the marker genes corresponding to the marker_ids
#' @param facetting A logic argument for wheter or not we should facet the data by Time
#' @export
#'  
abs_mc_gene_correltion <- function(absolute_cds = absolute_cds, mc_adj_cds = mc_adj_cds, 
                                   marker_ids = marker_ids, ercc_ids = ercc_ids, gene_name = quake_molecular_switch, sample_id = 1, facetting = F) {
  marker_abs <- as.vector(exprs(absolute_cds)[marker_ids, ])
  marker_mc <- as.vector(exprs(mc_adj_cds )[marker_ids, ])
  ERCC_spike <- as.vector(exprs(absolute_cds)[ercc_ids, ])
  ERCC_mc <- as.vector(exprs(mc_adj_cds)[ercc_ids, ])
  
  ercc_num <- nrow(input.ERCC.annotation) #ercc
  
  ERCC_df <- data.frame(ERCC_spike = ERCC_spike, ERCC_mc = ERCC_mc, 
                        time = rep(pData(absolute_cds)[, 'Time'],  time = ercc_num), 
                        gene = rep(ercc_ids, time = ncol(absolute_cds)))
  
  gene_df <- data.frame(marker_abs = marker_abs, marker_mc = marker_mc, 
                        time = rep(pData(absolute_cds)[, 'Time'],  time = length(marker_ids)), 
                        gene = rep(marker_ids, time = ncol(absolute_cds)))
  
  p1 <- #ERCC transcript correlation between two approaches
    qplot(ERCC_spike + 1, ERCC_mc + 1, color = time, data = ERCC_df, log = "xy", alpha = I(.3)) + 
    geom_smooth(method = "rlm", color = "red", se = T) + #geom_smooth(method = "loess", color = "black", se = F) + 
    xlab("ERCC transcript absolute copy number based on spikein regression") + ylab("ERRCC transcript in absolute copy number based on mc optimization") + 
    monocle_theme_opts() + geom_abline(color = 'blue', slope = 1) + ggtitle('all spikein transcripts')
  
  p1.1 <-   qplot(ERCC_spike + 1, ERCC_mc + 1, color = time, data = subset(ERCC_df, gene == ercc_ids[sample_id]), log = "xy") + 
    geom_smooth(method = "rlm", color = "red", se = T) + #geom_smooth(method = "loess", color = "black", se = F) + 
    xlab("Marker absolute copy number based on spikein regression") + ylab("Marker transcript in absolute copy number based on mc optimization") + 
    monocle_theme_opts() + geom_abline(color = 'blue', slope = 1) + ggtitle(ercc_ids[sample_id]) + 
    theme(legend.position = 'none')
  
  
  p2 <- #marker genes
    qplot(marker_abs + 1, marker_mc + 1, color = time, data = gene_df, log = "xy", alpha = I(.3)) + 
    geom_smooth(method = "rlm", color = "red", se = T) + #geom_smooth(method = "loess", color = "black", se = F) + 
    xlab("Marker absolute copy number based on spikein regression") + ylab("Marker transcript in absolute copy number based on mc optimization") + 
    monocle_theme_opts() + geom_abline(color = 'blue', slope = 1) + ggtitle('all marker genes')
  
  p2.1 <- 
    qplot(marker_abs + 1, marker_mc + 1, color = time, data = subset(gene_df, gene == marker_ids[sample_id]), log = "xy") + 
    geom_smooth(method = "rlm", color = "red", se = T) + #geom_smooth(method = "loess", color = "black", se = F) + 
    xlab("Marker absolute copy number based on spikein regression") + ylab("Marker transcript in absolute copy number based on mc optimization") + 
    monocle_theme_opts() + geom_abline(color = 'blue', slope = 1) + ggtitle(gene_name[sample_id]) + 
    theme(legend.position = 'none')
  
  melt_gene_df <- melt(gene_df)
  melt_ERCC_df <- melt(ERCC_df)
  
  #show distribution of each gene by different normalization 
  p3 <- #marker expression distribution
    ggplot(data = melt_gene_df) + geom_histogram(aes(x = value, fill = variable), alpha = 0.7, binwidth = 1) + 
    monocle_theme_opts()
  
  if(facetting) {
    p1 <- p1 + facet_wrap(~time, scale = 'free')
    p1.1 <- p1.1 + facet_wrap(~time, scale = 'free')
    p2 <- p2 + facet_wrap(~time, scale = 'free')
    p2.1 <- p2.1 + facet_wrap(~time, scale = 'free')
    p3 <- p3 + facet_wrap(~gene, scale = 'free')
  }
  
  return(list(ERCC_df = ERCC_df, gene_df = gene_df, p1 = p1, p1.1 = p1.1, p2 = p2, p2.1 = p2.1, p3 = p3))
} 

#' violin plot for the gene expression acroos different categories
#' @param pval the pval calculated in the differentialGeneTest, which will show on the legend. All other terms will be the same as the ones from the plot_genes_jitter
#' @export
#' 
plot_genes_violin <- function (cds_subset, pvalue, grouping = "State", min_expr = 0.1, cell_size = 0.75,
                               nrow = NULL, ncol = 1, panel_order = NULL, color_by = NULL,
                               plot_trend = FALSE, label_by_short_name = TRUE, outlier_rm_type = NULL) {
  
  if(!is.null(outlier_rm_type)) {
    outlier_mat <- apply(exprs(cds_subset), 1, function(x) {
      #print(x)
      res <- outlier_rem(x, type = outlier_rm_type, k_val = 5)
      #print(res)
      #1:ncol(cds_subset) %in% res$valid_cells #outlier cell or not?
    })
  }
  
  cds_exprs <- melt(exprs(cds_subset))
  colnames(cds_exprs) <- c("f_id", "Cell", "expression")
  cds_exprs$expression[cds_exprs$expression < min_expr] <- min_expr
  cds_exprs$pval <- rep(format(pvalue, digits = 3), ncol(cds_subset))
  if(!is.null(outlier_rm_type)) cds_exprs$outlier <- as.vector(t(outlier_mat))
  
  #message(melt(outlier_mat)[1, ])
  
  cds_pData <- pData(cds_subset)
  cds_fData <- fData(cds_subset)
  cds_exprs <- merge(cds_exprs, cds_fData, by.x = "f_id", by.y = "row.names")
  cds_exprs <- merge(cds_exprs, cds_pData, by.x = "Cell", by.y = "row.names")
  cds_exprs$adjusted_expression <- log10(cds_exprs$expression)
  if (label_by_short_name == TRUE) {
    if (is.null(cds_exprs$gene_short_name) == FALSE)
    {
      #paste(ensemble, ' (pval = ', format(pval, digits = 3), ')', sep = '')
      cds_exprs$feature_label <- paste(cds_exprs$gene_short_name, ' (pval = ', cds_exprs$pval, ')', sep = '') #paste(ensemble, ' (pval = ', format(pval, digits = 3), ')', sep = '')
      cds_exprs$feature_label[is.na(cds_exprs$feature_label)] <- cds_exprs$f_id
      print(unique(cds_exprs$gene_short_name))
      #print(paste(cds_exprs$gene_short_name, ' (pval = ', rep(format(pvalue, digits = 3), ncol(cds_subset)), ')', sep = ''))
    }
    else {
      cds_exprs$feature_label <- cds_exprs$f_id
    }
  }
  else {
    cds_exprs$feature_label <- #cds_exprs$f_id
      paste(cds_exprs$f_id, ' (pval = ', cds_exprs$pval, ')', sep = '')
  }
  if (is.null(panel_order) == FALSE) {
    cds_subset$feature_label <- factor(cds_subset$feature_label,
                                       levels = panel_order)
  }
  q <- ggplot(aes_string(x = grouping, y = "expression"), data = cds_exprs)
  if (is.null(color_by) == FALSE) {
    q <- q + geom_jitter(aes_string(color = I(color_by)), size = I(cell_size)) + 
      geom_violin(aes_string(fill = I(color_by)), alpha = I(0.3))
  }
  else {
    q <- q + geom_jitter(size = I(cell_size)) + 
      geom_violin(aes_string(fill = I("State")), alpha = I(0.3))
  }
  if (plot_trend == TRUE) {
    q <- q + stat_summary(aes_string(color = NULL), fun.data = "mean_cl_boot",
                          size = 0.35)
    q <- q + stat_summary(aes_string(x = grouping, y = "expression",
                                     color = NULL, group = grouping), fun.data = "mean_cl_boot",
                          size = 0.35, geom = "line")
  }
  q <- q + scale_y_log10() + facet_wrap(~feature_label, nrow = nrow,
                                        ncol = ncol, scales = "free_y")
  q <- q + ylab("Expression") + xlab(grouping)
  q <- q + monocle_theme_opts()
  q
}

#' function to plot the fitting for different distributions: 
#' 
#' @param Thomas_test_data Data.frame storing information for comparing the fitting for each distribution  
#' @param high_exprs_gene Gene ids for high expression genes 
#' @param type Type of data will be used (either spike-in transcript counts, transcript counts estimated from algorithm and the original FPKM values)
#' @param facetting Logic argument for whether or not we need to facet into different time points
#' @param xmax Maximum value for the X-axis
#' @param Time_point The time points selected
#' @export
#' 
plot_fitting_distribution <- function(Thomas_test_data = Thomas_test_data, high_exprs_gene = high_exprs_genes[1], type = c('abs', 'mc', 'std'), facetting = T, xmax = 100, Time_point = NULL) {
  if(type == 'abs'){
    Thomas_test_data$expression <- (as.numeric(exprs(absolute_cds[high_exprs_gene, ])))
    title = 'absolute'
  }
  else if(type == 'mc'){
    Thomas_test_data$expression <- (as.numeric(exprs(mc_adj_cds[high_exprs_gene, ])))
    title = 'mc optimization'
  }
  else if(type == 'std'){
    Thomas_test_data$expression <- (as.numeric(exprs(standard_cds[high_exprs_gene, ])))
    title = 'realtive expression'
  }
  
  if(!is.null(Time_point)) 
    Thomas_test_data <- subset(Thomas_test_data, Time == Time_point)
  
  #the boxplot:
  if(type == 'std'){
    sample_table <- read.delim(paste(dir, "/samples.table", sep = ''))
    norm_count <- read.delim(paste(dir, "/genes.count_table", sep = ''))
    row.names(norm_count) <- norm_count$tracking_id
    norm_count <- norm_count[, -1]  
    
    countdata <- round(t(t(norm_count) * sample_table$internal_scale)) #convert back to the raw counts 
    
    read_data <- Thomas_test_data
    read_data$expression <- countdata[high_exprs_gene, as.numeric(row.names(Thomas_test_data))]
    fit1 <- vglm(round(expression) ~ 1, data = Thomas_test_data, family = negbinomial()) 
  }
  
  else 
    fit1 <- vglm(round(expression) ~ 1, data = Thomas_test_data, family = negbinomial()) 
  
  sim_df <- simulate(fit1, nsim = 1000) 
  negbin_range <- quantile(as.numeric(as.matrix(sim_df)), probs = seq(0, 1, 0.05), na.rm = FALSE,
                           names = TRUE, type = 7)[c(2, 20)]
  
  #tobit (tobit cannot run simulation)
  fit2 <- vglm(expression + pseudo_cnt ~ 1, data = Thomas_test_data, family = tobit()) 
  # tobit_sim_df <- simulate(fit2, nsim = 1000) 
  # tobit_range <- quantile(as.numeric(as.matrix(tobit_sim_df)), probs = seq(0, 1, 0.05), na.rm = FALSE,
  # names = TRUE, type = 7)[c(2, 20)]
  
  #lognormal
  fit2.1 <- vglm(expression + pseudo_cnt ~ 1, data = Thomas_test_data, family = lognormal()) 
  lognormal_sim_df <- simulate(fit2.1, nsim = 1000) 
  lognormal_range <- quantile(as.numeric(as.matrix(tobit_sim_df)), probs = seq(0, 1, 0.05), na.rm = FALSE,
                              names = TRUE, type = 7)[c(2, 20)]
  
  #zinegbinomial
  if(type == 'std')
    fit3 <- vglm(round(expression) ~ 1, data = read_data, family = zinegbinomial()) 
  else 
    fit3 <- vglm(round(expression) ~ 1, data = Thomas_test_data, family = zinegbinomial()) 
  
  zin_sim_df <- simulate(fit3, nsim = 1000) 
  zin_range <- quantile(as.numeric(as.matrix(zin_sim_df)), probs = seq(0, 1, 0.05), na.rm = FALSE,
                        names = TRUE, type = 7)[c(2, 20)]
  
  #zanegbinomial
  if(type == 'std')
    fit4 <- vglm(round(expression) ~ 1, data = read_data, family = zanegbinomial()) 
  else
    fit4 <- vglm(round(expression) ~ 1, data = Thomas_test_data, family = zanegbinomial()) 
  zan_sim_df <- simulate(fit4, nsim = 1000) 
  zan_range <- quantile(as.numeric(as.matrix(zan_sim_df)), probs = seq(0, 1, 0.05), na.rm = FALSE,
                        names = TRUE, type = 7)[c(2, 20)]
  
  ori_df <- rbind(Thomas_test_data, Thomas_test_data, Thomas_test_data, Thomas_test_data, Thomas_test_data)
  ori_df$type <- rep(c('negbinomial', 'lognormal', 'tobit', 'zinegbinomial', 'zanegbinomial'), each = nrow(Thomas_test_data))
  
  fit_df <- data.frame(fit = c(seq(negbin_range[1], negbin_range[2], length.out = 1000), seq(lognormal_range[1], lognormal_range[2], length.out = 1000), rep(NA, length.out = 1000), seq(zin_range[1], zin_range[2], length.out = 1000), seq(zan_range[1], zan_range[2], length.out = 1000)), 
                       type = c(rep('negbinomial', 1000), rep('lognormal', 1000), rep('tobit', 1000), rep('zinegbinomial', 1000), rep('zanegbinomial', 1000)), 
                       ymin = c(rep(negbin_range[1], 1000), rep(lognormal_range[1], 1000), rep(NA, length.out = 1000), rep(zin_range[1], 1000), rep(zan_range[1], 1000)), 
                       ymax = c(rep(negbin_range[2], 1000), rep(lognormal_range[2], 1000), rep(NA, length.out = 1000), rep(zin_range[2], 1000), rep(zan_range[2], 1000)))
  
  p1 <- 
    qplot(x = type, y = expression, geom = 'jitter', data = ori_df, color = type) + 
    geom_pointrange(aes(x = type, y = fit, ymin = ymin, ymax = ymax, color = type), data = fit_df) + scale_y_log10() + 
    xlab('Type') + ylab('absolute copy number') + ggtitle(paste(title, " (", high_exprs_gene, ")", sep = ''))
  #geom_linerange, geom_crossbar, geom_errorbar
  
  # geom_pointrange(aes(x = 'Test', y = seq(negbin_range[1], negbin_range[2], lengthout = 1000), ymin = negbin_range[1], ymax = negbin_range[2]), color = 'red', alpha = I(0.3)) + 
  # geom_pointrange(aes(x = 'Test', y = seq(tobit_range[1], tobit_range[2], lengthout = 1000), ymin = tobit_range[1], ymax = tobit_range[2]), color = 'blue', alpha = I(0.3)) + 
  # geom_pointrange(aes(x = 'Test', y = seq(zin_range[1], zin_range[2], lengthout = 1000), ymin = zin_range[1], ymax = zin_range[2]), color = 'green', alpha = I(0.3)) + 
  # geom_pointrange(aes(x = 'Test', y = seq(zan_range[1], zan_range[2], lengthout = 1000), ymin = zan_range[1], ymax = zan_range[2]), color = 'yellow', alpha = I(0.3)) + 
  # scale_y_log10()
  
  #this following function cannot work  
  # qplot(Pseudotime, expression, data = Thomas_test_data) + 
  #     stat_smooth(method="glm", family="gaussian", formula = Pseudotime ~ ns(expression, 2)) #use glm.nb 
  
  #add confidence interval for the glm fitting curves: 
  
  #plot the density function for different distribution
  max_cnt_thomas <- max(Thomas_test_data$expression)
  # max_cnt_thomas <- nrow(Thomas_test_data)
  fit1_obs <- data.frame(obs = dnbinom(1:max_cnt_thomas, mu = exp(coef(fit1)[1]), size = exp(coef(fit1)[2])))
  fit2_obs <- data.frame(obs = dtobit(1:max_cnt_thomas, mean = coef(fit2)[1], sd = exp(coef(fit2)[2])))
  fit2.1_obs <- data.frame(obs = dlnorm(1:max_cnt_thomas, meanlog = coef(fit2)[1], sdlog = exp(coef(fit2)[2])))
  fit3_obs <- data.frame(obs = dzinegbin(1:max_cnt_thomas, pstr0 = inv.logit(coef(fit3)[1]), munb = exp(coef(fit3)[2]), size = exp(coef(fit3)[3])))
  fit4_obs <- data.frame(obs = dzanegbin(1:max_cnt_thomas, pobs0 = inv.logit(coef(fit4)[1]), munb = exp(coef(fit4)[2]), size = exp(coef(fit4)[3])))
  
  test_fit_df <- cbind(fit1_obs, fit2_obs, fit2.1_obs, fit3_obs, fit4_obs)
  colnames(test_fit_df) <- c('negbinomial', 'tobit', 'lognormal', 'zinegbinomial', 'zanegbinomial')
  mlt_test_fit_df <- melt(test_fit_df, variable.name = "type")
  
  if(type == 'std' | facetting){
    facet_formula = "~type"
    if(type == 'std'){
      Thomas_test_data <- rbind(read_data, Thomas_test_data, Thomas_test_data, read_data, read_data)
      Thomas_test_data$datatype = rep(c('read_counts', 'FPKM', 'FPKM', 'read_counts', 'read_counts'), each = nrow(Thomas_test_data) / 5)
      mlt_test_fit_df$datatype = rep(c('read_counts', 'FPKM', 'FPKM', 'read_counts', 'read_counts'), each = max_cnt_thomas)
      facet_formula = "~datatype"
    }
    else
      Thomas_test_data <- rbind(Thomas_test_data, Thomas_test_data, Thomas_test_data, Thomas_test_data, Thomas_test_data)
    
    Thomas_test_data$type = rep(c('negbinomial', 'tobit', 'lognormal', 'zinegbinomial', 'zanegbinomial'), each = nrow(Thomas_test_data) / 5)
    
    p2 <- 
      qplot(expression, ..density.., geom = 'histogram', binwidth = 1, fill = I('blue'), alpha = I(0.7), data = Thomas_test_data) + facet_wrap(as.formula(facet_formula), scales="free") + 
      geom_line(aes(rep(1:max_cnt_thomas, 5), value, color = type), data = mlt_test_fit_df, size = 1) + xlim(0, xmax) + ggtitle(title)
    # ggplot(Thomas_test_data) + geom_histogram(aes(x = expression, y = ..density..), fill = I('red'), alpha = I(0.3)) + geom_line(aes(x = 1:29, y = obs), color = 'red', data = fit_obs)
  }
  else { 
    p2 <- 
      qplot(expression, ..density.., geom = 'histogram', binwidth = 1, fill = I('blue'), alpha = I(0.7), data = Thomas_test_data) + 
      geom_line(aes(rep(1:max_cnt_thomas, 5), value, color = type), data = mlt_test_fit_df, size = 1) + xlim(0, xmax) + ggtitle(paste(title, " (", high_exprs_gene, ")", sep = ''))
  }
  
  return(list(p1 = p1, p2 = p2))
}

#' this function is used to plot the dropout event in our data 
#'
#' @param data Data.frame for showing the scatter plot for two cells  
#' @param h parameter for stat_density2d
#' @export

cell_wise_scatter <- function(data = std_cell_exprs_mat, h = 1) {
  qplot(SRR1033854_0, SRR1033855_0, data=data, log="xy", size=I(1)) + 
    #   stat_density2d(aes(fill = ..level..), geom="polygon", h  = 1) + 
    stat_density2d(geom="tile", aes(fill = ..density..), contour = FALSE, h = h) + #
    geom_point(color=I("darkgray"), size=I(0.85)) +
    #facet_wrap(~Cell.Type) + 
    #scale_color_brewer(palette="Set1") +
    scale_fill_gradientn(colours=buylrd) +
    ylab(colnames(absolute_cds)[2]) +
    xlab(colnames(absolute_cds)[1]) +
    theme(strip.background = element_rect(colour = 'white', fill = 'white')) + 
    theme(panel.border = element_blank(), axis.line = element_line()) +
    theme(legend.position="none") +
    theme(axis.title.y=element_text(size=10)) +
    theme(axis.title.x=element_text(size=10)) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) 
}

#' function for setting figure style for nature method
#' 
nm_theme <- function() {
  theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
    theme(panel.border = element_blank(), axis.line = element_line()) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + 
    theme(panel.background = element_rect(fill='white')) + 
    #theme(text = element_text(size=6)) + 
    theme(axis.text.y=element_text(size=6)) + 
    theme(axis.text.x=element_text(size=6)) +
    theme(axis.title.y=element_text(size=6)) + 
    theme(axis.title.x=element_text(size=6)) +
    theme(panel.border = element_blank(), axis.line = element_line(size = .1), axis.ticks = element_line(size = .1)) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) +
    theme(legend.position = "none") +
    theme(strip.text.x = element_text(colour="black", size=6)) + 
    theme(strip.text.y = element_text(colour="black", size=6)) + 
    theme(legend.title = element_text(colour="black", size = 6)) + 
    theme(legend.text = element_text(colour="black", size = 6)) + 
    theme(plot.margin=unit(c(0,0,0,0), "lines")) 
}

#landscape plot: (still need some work!!)
#' Make the landscape plot for the cells embeded in the two ICA reduced spaces
#' @param landscape_subset
#' @export

landscape_plot <- function(landscape_subset) {
  
  bifurcation_ids <- row.names(subset(fData(absolute_cds), gene_short_name %in% gene_list))
  landscape_subset <- exprs(absolute_cds)[bifurcation_ids, ]
  
  test_res <- kde2d(x = landscape_subset[1, ], y = landscape_subset[2, ])
  test_res <- kde2d(x = log2(round(landscape_subset[1, ]  + 1)), y = log2(round(landscape_subset[2, ] + 1)) )
  
  library('rgl')
  source('my_ploting.R')
  
  plot3D(X = test_res$x, Y = test_res$y, Z = test_res$z)
  
  qplot(round(landscape_subset[1, ]), round(landscape_subset[2, ]), geom = c('point', 'density2d'), log = 'xy')
  res <- kde2d(x = log2(round(landscape_subset[1, ]  + 1)), y = log2(round(landscape_subset[2, ] + 1)) )
  return(res)  
}

#' Make heatmap 
#' @param cds CellDataSet for the experiment
#' @param rowgenes Gene ids or short names to be arrayed on the vertical axis.
#' @param colgenes Gene ids or short names to be arrayed on the horizontal axis
#' @param relative_expr Whether to transform expression into relative values
#' @param min_expr The minimum level of expression to show in the plot
#' @return a ggplot2 plot object
#' @import ggplot2
#' @importFrom plyr ddply
#' @importFrom reshape2 melt
#' @export 
#' 
cole_make_heatmap <- function(dat.all = str_logfc_df, emsemble_ids = row.names(str_logfc_df), ABC_df = abs_AT12_cds_subset_all_gene_ABCs, qval_res = relative_abs_AT12_cds_subset_quake_gene, 
                              dist_method = 'euclidean', hclust_method = 'ward', fc_limit = 3, separate = F, ...) { 
  
  emsemble_ids <- emsemble_ids[!is.na(dat.all[, 1])] #first remove NA's ids
  dat.all <- dat.all[!is.na(dat.all[, 1]), ]
  
  #scale (not good); change limits
  dat.all <- dat.all[row.names(dat.all) != '-', ]
  dat.all[which(dat.all <= -fc_limit)] <- -fc_limit
  dat.all[which(dat.all >= fc_limit)] <- fc_limit
  
  #separate into two lineages: 
  if(separate) {
    branch_gene_ABCs <- subset(ABC_df, gene_short_name %in% row.names(dat.all))
    AT1_data <- dat.all[unique(as.character(subset(branch_gene_ABCs, ABCs > 0)[, 'gene_short_name'])), ]
    AT2_data <- dat.all[unique(as.character(subset(branch_gene_ABCs, ABCs < 0)[, 'gene_short_name'])), ]
    
    #AT1
    test <- pheatmap(AT1_data, cluster_cols=FALSE, clustering_distance_rows = dist_method, clustering_method = hclust_method, filename = 'test.pdf', ...)
    
    #pheatmap(dat.all[test$tree_row$order, ], cluster_cols = FALSE, cluster_rows = TRUE, show_rownames = T, show_colnames = F, border_color = NA, ...)
    annotation <- data.frame(class = as.factor(cutree(test$tree_row, 3)), row.names = names(cutree(test$tree_row, 3)))
    pheatmap(t(AT1_data[test$tree_row$order, ]), cluster_cols = T, cluster_rows = F, show_rownames = F, show_colnames = F, 
             border_color = NA, clustering_distance_cols = dist_method, clustering_method = hclust_method, annotation = annotation, 
             annotation_legend = T)
    
    #AT2
    #row.names(dat.all) <- fData(absolute_cds[emsemble_ids[!is.na(dat.all[, 1])], ])$gene_short_name
    test <- pheatmap(AT2_data, cluster_cols=FALSE, clustering_distance_rows = dist_method, clustering_method = hclust_method, filename = 'test.pdf', ...)
    
    #pheatmap(dat.all[test$tree_row$order, ], cluster_cols = FALSE, cluster_rows = TRUE, show_rownames = T, show_colnames = F, border_color = NA, ...)
    annotation <- data.frame(class = as.factor(cutree(test$tree_row, 3)), row.names = names(cutree(test$tree_row, 3)))
    pheatmap(t(AT2_data[test$tree_row$order, ]), cluster_cols = T, cluster_rows = F, show_rownames = F, show_colnames = F, 
             border_color = NA, clustering_distance_cols = dist_method, clustering_method = hclust_method, annotation = annotation, 
             annotation_legend = T, ...)
  }
  else {
    #all genes: 
    test <- pheatmap(dat.all, cluster_cols=FALSE, clustering_distance_rows = dist_method, clustering_method = hclust_method, filename = 'test.pdf', ...)
    annotation <- data.frame(class = as.factor(cutree(test$tree_row, 4)), row.names = names(cutree(test$tree_row, 4)))
  
    example_ids <- row.names(annotation)
    log_qval <- log10(qval_res[example_ids, 'qval'])
    annotation$log_qval <- -log_qval
    
    pheatmap(t(dat.all[test$tree_row$order, ]), cluster_cols = T, cluster_rows = F, show_rownames = F, show_colnames = F, 
             border_color = NA, clustering_distance_cols = dist_method, clustering_method = hclust_method, annotation = annotation, 
             annotation_legend = T, legend = F)    
  }
}

#' Plot the heatmap with the log-ratio of gene expression from the two fitting lineage curve of branch genes 
#' Note that there are five different plots are included (Use the first one)
#' TO DO: add the confidence interval, add p-val, fix error when we cannot generate fitting for the data
#' @param cds CellDataSet for the lineage specific genes after the branchTest
#' @param rowgenes Gene ids or short names to be arrayed on the vertical axis.
#' @param colgenes Gene ids or short names to be arrayed on the horizontal axis
#' @param relative_expr Whether to transform expression into relative values
#' @param min_expr The minimum level of expression to show in the plot
#' @return a ggplot2 plot object
#' @import ggplot2
#' @importFrom plyr ddply
#' @importFrom reshape2 melt
#' @export 
#' 
cole_plot_heatmap <- function(cds = cds, file = 'bifurcation_heatmap',
                              lineage_states = c(2, 3),
                              cores = detectCores(),
                              trend_formula = "~sm.ns(Pseudotime, df = 3)",
                              fc_limit = 3,
                              relative_expr = TRUE,
                              weighted = FALSE,
                              label_by_short_name = TRUE,
                              useVST = FALSE, 
                              round_exprs = FALSE,
                              pseudocount=0,
                              ...) {
  t_bifurcation <- as.integer(min(pData(cds[, c(which(pData(cds)$State == lineage_states[1]),
                                                which(pData(cds)$State == lineage_states[2]))])$Pseudotime))
  cds_subset <- buildLineageBranchCellDataSet(cds, lineage_states, NULL, "fitting", TRUE, weighted, NULL, ...)
  
  #generate cds for branches
  cds_branchA <- cds_subset[, pData(cds_subset)$Lineage == lineage_states[1]]
  cds_branchB <- cds_subset[, pData(cds_subset)$Lineage == lineage_states[2]]
  
  #fit bs spline curve for branches
  #is this the same as sm.ns(Pseudotime, df = 3) * Lineage
  closeAllConnections()
  branchA_full_model_fits <- fitModel(cds_branchA, modelFormulaStr = trend_formula,
                                      cores = cores, relative_expr = relative_expr, pseudocount=pseudocount)
  closeAllConnections()
  branchB_full_model_fits <- fitModel(cds_branchB, modelFormulaStr = trend_formula,
                                      cores = cores, relative_expr = relative_expr, pseudocount=pseudocount)
  closeAllConnections()
  
  #generate 100 evenly spaced points from the spline line
  t_rng <- range(pData(cds_branchA)$Pseudotime)
  
  #stretched data
  # if(stretch) {
  str_new_cds_branchA <- data.frame(Pseudotime = seq(0, max(pData(cds_branchA)$Pseudotime), length.out = 100))
  print (sort(pData(cds_branchA)$Pseudotime))
  
  str_new_cds_branchB <- data.frame(Pseudotime = seq(0, max(pData(cds_branchB)$Pseudotime), length.out = 100))
  print (sort(pData(cds_branchB)$Pseudotime))
  
  str_branchA_expression_curve_matrix <- responseMatrix(branchA_full_model_fits, newdata = str_new_cds_branchA)
  str_branchB_expression_curve_matrix <- responseMatrix(branchB_full_model_fits, newdata = str_new_cds_branchB)
  
  if(useVST) {
    # print (str_branchA_expression_curve_matrix["ENSMUSG00000000215.4",])
    print ("###")
    str_branchA_expression_curve_matrix <- vstExprs(cds, expr_matrix = str_branchA_expression_curve_matrix, round_vals=round_exprs)
    # print (str_branchA_expression_curve_matrix["ENSMUSG00000000215.4",])
    print ("***")
    # print (str_branchB_expression_curve_matrix["ENSMUSG00000000215.4",])
    print ("###")
    str_branchB_expression_curve_matrix <- vstExprs(cds, expr_matrix = str_branchB_expression_curve_matrix, round_vals=round_exprs)
    # print (str_branchB_expression_curve_matrix["ENSMUSG00000000215.4",])
    #divergence between two lineages
    str_logfc_df <- str_branchA_expression_curve_matrix - str_branchB_expression_curve_matrix
  }else{
    
    #divergence between two lineages
    str_logfc_df <- log2((str_branchA_expression_curve_matrix + 1) / (str_branchB_expression_curve_matrix + 1))
  }
  
  #short names:
  if(label_by_short_name) {
    row.names(str_logfc_df) <- fData(cds[, ])$gene_short_name
  }
  
  str_logfc_df[which(str_logfc_df <= -fc_limit)] <- -fc_limit
  str_logfc_df[which(str_logfc_df >= fc_limit)] <- fc_limit
  
  save(str_logfc_df, str_branchA_expression_curve_matrix, str_branchB_expression_curve_matrix, file = file)
  #include all stages
}

#' ggplot style of the bifurcation heatmap (Note that use load('bifurcation_heatmap')) to get the str_logfc_df for now
#' @export 
#' 
cole_make_heatmap_cluster <- function(m = str_logfc_df) {
  m <- m[!is.na(m[, 1]), ]
  rows = dim(m)[1]
  cols = dim(m)[2]
  
  test <- hclust(dist(m), method = 'ward.D2')
  m <- m[test$order, ]
  
  melt.m = cbind(rowInd = rep(1:rows, times = cols), colInd = rep(1:cols,
                                                                  each = rows), reshape2::melt(m))
  
  g = ggplot(data = melt.m)
  if (border == TRUE)
    g2 = g + geom_rect(aes(xmin = colInd - 1, xmax = colInd,
                           ymin = rowInd - 1, ymax = rowInd, fill = value),
                       colour = "grey")
  if (border == FALSE)
    g2 = g + geom_rect(aes(xmin = colInd - 1, xmax = colInd,
                           ymin = rowInd - 1, ymax = rowInd, fill = value))
  if (labCol == TRUE) {
    g2 = g2 + scale_x_continuous(breaks = (1:cols) - 0.5,
                                 labels = colnames(m))
  }
  if (labCol == FALSE) {
    g2 = g2 + scale_x_continuous(breaks = (1:cols) - 0.5,
                                 labels = rep("", cols))
  }
  if (labRow == TRUE) {
    g2 = g2 + scale_y_continuous(breaks = (1:rows) - 0.5,
                                 labels = rownames(m))
  }
  if (labRow == FALSE) {
    g2 = g2 + scale_y_continuous(breaks = (1:rows) - 0.5,
                                 labels = rep("", rows))
  }
  g2 <- g2 + theme(axis.ticks = element_blank())
  g2 = g2 + theme(panel.grid.minor = element_line(colour = NA),
                  panel.grid.major = element_line(colour = NA), panel.background = element_rect(fill = NA,
                                                                                                colour = NA))
  g2 = g2 + theme(axis.text.x = element_text(angle = -90, hjust = 0))
  if (is.function(rescaling)) {
  }
  else {
    if (rescaling == "row" || rescaling == "column") {
      legendTitle <- "Relative\nexpression"
    }
    else {
      if (logMode) {
        legendTitle <- bquote(paste(log[10], " FPKM + ",
                                    .(pseudocount), sep = ""))
      }
      else {
        legendTitle <- "FPKM"
      }
    }
  }
  if (length(heatscale) == 2) {
    g2 <- g2 + scale_fill_gradient(low = heatscale[1], high = heatscale[2],
                                   name = legendTitle)
  }
  else if (length(heatscale) == 3) {
    if (is.null(heatMidpoint)) {
      heatMidpoint = (max(m) + min(m))/2
    }
    g2 <- g2 + theme(panel.border = element_blank())
    g2 <- g2 + scale_fill_gradient2(low = heatscale[1], mid = heatscale[2],
                                    high = heatscale[3], midpoint = heatMidpoint, name = legendTitle)
  }
  else {
    g2 <- g2 + scale_fill_gradientn(colours = heatscale,
                                    name = legendTitle)
  }
  
  #add the row dendrogram and cluster
  #more aesthetics:
  
  dd.col <- as.dendrogram(test)
  col.ord <- order.dendrogram(dd.col)
  ddata_y <- dendro_data(dd.col)
  
  theme_none <- theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.title.x = element_text(colour=NA),
    axis.title.y = element_blank(),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    axis.line = element_blank()
    #axis.ticks.length = element_blank()
  )
  
  g3 <- ggplot(segment(ddata_y)) +
    geom_segment(aes(x=x, y=y, xend=xend, yend=yend)) + coord_flip() +
    theme_none + theme(axis.title.x=element_blank())
  
  # grid.newpage()
  # print(g2, vp=viewport(0.8, 0.8, x=0.4, y=0.4))
  # print(g3, vp=viewport(0.2, 0.8, x=0.9, y=0.4))
  
  grid.newpage()
  print(test$g2, vp=viewport(0.8, 0.8, x=0.4, y=0.5))
  print(test$g3, vp=viewport(0.2, 0.8, x=0.9, y=0.5))
  
  return(list(g2 = g2, g3 = g3))
}

#' make performance plot with a pval df, a gene names vector and the permutation pval vector 
#' @param pval_df Data.frame for the pvals from the DEG test
#' @param gene_id The ids for the selected genes under certain mild criteria  
#' @param perm_pval The Pval calculated from the permutation test 
#' @export

make_performance_plots <- function(pval_df = cmpr_pseudotime_pval_df, 
                                   gene_id = valid_gene_id_cell, perm_pval = abs_glm_perm_res_df[valid_gene_id_cell, 1]) {
  row.names(pval_df) <- valid_gene_id_cell
  
  perm_pval_df <- cbind(pval_df, perm_pval = perm_pval)#, 
  
  na_num <- apply(perm_pval_df, 2, function(x) {sum(is.na(x))} )
  mlt_na_num <- melt(na_num)
  mlt_na_num$type <- names(na_num)
  
  #plot NA barplots: 
  qplot(factor(type), value, geom = 'bar', stat = 'identity', fill = type, data = mlt_na_num) +
    ggtitle("Distribution of fitting failures") + xlab('Type of fit') + ylab('number of fitting failures') + monocle_theme_opts() + 
    theme(axis.text.x = element_text(angle = 30))
  
  #plot the pval distribution 
  mlt_pval_df <- melt(pval_df)
  qplot(value, color = variable, ..density.., geom = 'density', data = mlt_pval_df) + facet_wrap(~variable, scale = 'free')
  
  row.names(pval_df) <- valid_gene_id_cell  
  
  cmpr_pval_df_DEG_res <- 
    testing_DEG(golden_std_type = 'DEG_permutation', fc_thrsld_vec = NULL, permuation_p = perm_pval, 
                input_pval_df = pval_df[, ], data_type = 'absolute', quake_list = F)
  
  test_type_list <- colnames(pval_df)
  cmpr_pval_df_DEG_res_DEG_plot_res <- 
    DEG_test_plot(cmpr_pval_df_DEG_res$cb_mlt_roc_df, cmpr_pval_df_DEG_res$cb_mlt_gene_num, DEG_test_list = DEG_test_list, 
                  test_type = test_type_list)
  
  return(cmpr_pval_df_DEG_res_DEG_plot_res)
}

#' function to generate a string for the regression model, which can be added in the ggplot 
#'
#' @param m The regression model
#' @export

lm_eqn = function(m) {
  
  l <- list(a = format(coef(m)[1], digits = 2),
            b = format(abs(coef(m)[2]), digits = 2),
            r2 = format(sqrt(mean(summary(m)$residuals^2)), digits = 3));
  
  if (coef(m)[2] >= 0)  {
    eq <- substitute(italic(y) == a + b %.% italic(x)*","~~italic(RMSD)~"="~r2,l)
  } else {
    eq <- substitute(italic(y) == a - b %.% italic(x)*","~~italic(RMSD)~"="~r2,l)    
  }
  
  as.character(as.expression(eq));                 
}

#' show the density plot with two different colors for each estimate
#'
#' @param fpkm A vector for the fpkm values in a cell
#' @param best_cov Mode of log10(FPKm) estimated from different mode estimation algorithms 
#' @export

plot_fpkm_dist_for_cell <- function(fpkm, best_cov){
  log_fpkm <- log10(fpkm)
  log_fpkm_p <- log_fpkm[log_fpkm > 1e-1]
  pre_best_cov <- best_cov[1]
  dmode <- best_cov[2]
  smsn_min <- best_cov[3]
  smsn_max <- best_cov[4]
  
  print(c(pre_best_cov, dmode, smsn_min, smsn_max))
  q <- 
    qplot(x = log_fpkm_p, y = ..density.., geom = 'density') + 
    geom_vline(xintercept=log10(pre_best_cov), color = 'blue') + 
    geom_vline(xintercept = log10(dmode), color = 'red') + 
    geom_vline(xintercept = log10(smsn_min), color = 'green') + 
    geom_vline(xintercept = log10(smsn_max), color = 'black') + 
    
    #stat_function(fun = dnorm, args = list(mean = , sd = )) + #add the distribution from the smsn fitting  
    #stat_function(fun = dnorm, args = list(mean = , sd = )) +
    #q <- qplot(x = 1, y = 2)
    monocle_theme_opts() 
  q
  
  #code to generate all fpkm distribution with t-estimates
  # for(i in 1:199) {
  #   p1 <- plot_fpkm_dist_for_cell(split_gene[[i]], gene_split_cov[[i]])
  #   p1 <- p1 + ggtitle(paste(Cell[i], " (", iso_total_rna_df$Input_frags[i], ")", sep = ""))
  #   assign(paste('compr_mode_', i, sep = ""), p1)
  # }
  
  # pdf('cmpr_mode.pdf', width = 100, height = 80)
  # multiplot(plotlist = mget(ls(pattern = "^compr_mode_")), cols = 20)
  # dev.off()
}

#' compare different pseudotime ordering approaches (use highest pca loading genes, differential expressed genes between groups and marker gene list if known)
#'
#' @param cds CellDataFrame for constructing the spanning tree 
#' @param marker_gene_list A vector of marker genes 
#' @param color_by Use this to color the cells in the spanning tree
#' @export

cmpr_pseduotime <- function(cds = std_HSMM, marker_gene_list = cole_gene_list, color_by = 'Time'){
  pca_ordering <- pseudo_ordering(cds, type = 'pca', dim = 1)
  q1 <- plot_spanning_tree(pca_ordering, color_by=color_by, show_backbone=T, show_cell_names = T)
  q1 <- q1 + ggtitle('pca') 
  
  diff_gene_ordering <- pseudo_ordering(cds, type = 'diff_gene')
  q2 <- plot_spanning_tree(diff_gene_ordering, color_by=color_by, show_backbone=T, show_cell_names = T)
  q2 <- q2 + ggtitle('DEGs') 
  
  marker_gene_list <- row.names(subset(fData(cds), gene_short_name %in% marker_gene_list))
  marker_gene_ordering <- pseudo_ordering(cds, type = 'marker', marker_gene_list = marker_gene_list)
  q3 <- plot_spanning_tree(marker_gene_ordering, color_by=color_by, show_backbone=T, show_cell_names = T)
  q3 <- q3 + ggtitle('marker genes') 
  
  multiplot(q1, q2, q3) 
  return(list(pca_ordering = pca_ordering, diff_gene_ordering = diff_gene_ordering, marker_gene_ordering = test_res_marker))
}

#' pre/rec/f1 barplot 
#'
#' @param test_p_list A list of pvals from different DEG test approaches, names of the pval vector should be the gene names
#' @param permutate_pval A list of permutation pval corresponding to each vector in test_p_list
#' @param gene_list A vector of genes used for access the performance of each test based on the permutation result and the pval 
#' @param p_thrsld Pval threshold to determine the significant genes
#' @param title Title for the figure 
#' @param rownames the row names for the data frame of pre_rec_f1_df
#' @param fill The column name for the fill in the ggplot
#' @param return_df A logic argument to determine whether or not we should return the data.frame
#' @export

plot_pre_rec_f1 <- function(test_p_list = list(monocle_p = monocle_p, deseq_p = deseq_p, scde_p = scde_p), permutate_pval, gene_list, na.rm = T, 
                            p_thrsld = 0.05, title = 'Comparison of the two-group DEG tests', rownames = NULL, fill = NULL, return_df = F) {
  if(is.list(permutate_pval)) {
    if(length(permutate_pval) != length(test_p_list))
      stop('Error: if using permuation pval for each bar, make sure the permuation list matches with the DEG pval list')
    pre_rec_f1_df <- NULL
    for(ind in 1:length(permutate_pval)) {
      gene_list_true_data_list <- gene_list_true_data(p_thrsld = p_thrsld, permutate_pval = permutate_pval[[ind]][gene_list], na.rm = na.rm)
      gene_list_new <- gene_list_true_data_list$gene_list
      true_data <- gene_list_true_data_list$true_data
      # print(head(gene_list))
      
      test_p_vec <- test_p_list[[ind]][gene_list_new]
      
      TF_PN <- TF_PN_vec(true_data, test_p_vec)
      mc_abs_two_grp <- pre_rec_f1(test_p_vec, permutate_pval[[ind]][gene_list], TF_PN)  
      
      pre_rec_f1_df <- rbind(mc_abs_two_grp, pre_rec_f1_df)
    }
  }
  else {
    gene_list_true_data_list <- gene_list_true_data(p_thrsld = p_thrsld, permutate_pval = permutate_pval[gene_list])
    gene_list <- gene_list_true_data_list$gene_list
    true_data <- gene_list_true_data_list$true_data
    
    test_p_list <- lapply(test_p_list, function(x) x[gene_list])
    
    pre_rec_f1_list <- lapply(test_p_list, function(x, true_data, permutate_pval) {
      TF_PN <- TF_PN_vec(true_data, x)
      mc_abs_two_grp <- pre_rec_f1(x, permutate_pval, TF_PN)  
    }, true_data = true_data, permutate_pval = permutate_pval[gene_list])
    pre_rec_f1_df <- do.call(rbind.data.frame, pre_rec_f1_list)
  }
  
  print(pre_rec_f1_df)
  
  if(!is.null(rownames)) {
    row.names(pre_rec_f1_df) <- rownames
    names(test_p_list) <- rownames
  }
  
  print(row.names(pre_rec_f1_df))
  
  if(is.list(permutate_pval))
    pre_rec_f1_df$Type <- rev(names(test_p_list)) #reverse the names
  else 
    pre_rec_f1_df$Type <- row.names(pre_rec_f1_df) #reverse the names
  
  print(pre_rec_f1_df)
  if(return_df)
    return(pre_rec_f1_df)
  
  if(is.null(fill))
    p1 <- 
    qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = Type, data = melt(pre_rec_f1_df)) + facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('')
  else
    p1 <- 
    qplot(factor(Type), value, stat = "identity", geom = 'bar', position = 'dodge', fill = fill, data = melt(pre_rec_f1_df)) + facet_wrap(~variable) + 
    ggtitle(title) + scale_fill_discrete('Type') + xlab('Type') + ylab('')
  
  return(p1)
}

#' this function is used to compare the DEG analysis on the muscle data, using the precision/recall/F1 score: 
#' @param pval_list 
#' @param all_other_list 
#' @param scde_res_list 
#' @export
##enable the barplot for each type are based on a specific permuation (ex: absolute from absolute, fpkm from fpkm, etc. )

test_muscle_fig3_plot <- function(pval_list, all_other_list, scde_res_list, muscle_permutate_pval, 
                                  deseq_method_op = 1, monocle_method_op = 2, size_monocle_op = 11, filename = 'test.pdf', 
                                  title = 'Comparison of the two-group DEG tests on mc-optimization absolute copy data (MUSCLE DATA)') {
  deseq_p <- pval_list[[deseq_method_op]]$dtalbe[, 'pval']
  names(deseq_p) <- row.names(pval_list[[deseq_method_op]]$dtalbe)
  if(monocle_method_op == 1) { #first matrix is the original DEG test results
    monocle_p <- as.numeric(as.character(all_other_list[[1]][, 'pval']))
    names(monocle_p) <- row.names(all_other_list[[1]])
  }
  else {
    monocle_p <- as.numeric(as.character(all_other_list[[monocle_method_op]][, 'pval']))
    names(monocle_p) <- row.names(all_other_list[[monocle_method_op]])
  }
  size_monocle_p <- single_size_media_all_other_absolute_pval_list[[size_monocle_op]][, 'pval']
  names(size_monocle_p) <- row.names(single_size_media_all_other_absolute_pval_list[[size_monocle_op]])
  
  scde_p <- scde_res_list$pval
  
  head(monocle_p)
  head(size_monocle_p)
  
  p1 <- plot_pre_rec_f1(list(monocle_p = monocle_p, size_monocle_p = size_monocle_p, deseq_p = deseq_p, scde_p = scde_p), muscle_permutate_pval, gene_list = names(monocle_p),
                        title = title) + ylim(0, 1)
  ggsave(filename, p1)
  
  return(p1)
}

#' this function is used to compare the DEG analysis on the quake lung data, using the precision/recall/F1 score: 
#'
#' @param dtable_nbinomTest
#' @param diff_test_res
#' @export

test_lung_fig3_plot <- function(dtable_nbinomTest, diff_test_res, scde_res_list, permutate_pval, gene_list, title) {
  deseq_p <- dtable_nbinomTest$dtalbe[, 'pval']
  names(deseq_p) <- row.names(dtable_nbinomTest$dtalbe)
  monocle_p <- as.numeric(as.character(diff_test_res$diff_test_res[, 'pval']))
  names(monocle_p) <- row.names(diff_test_res$diff_test_res)
  scde_p <- scde_res_list$pval
  p1 <- plot_pre_rec_f1(monocle_p, deseq_p, scde_p, permutate_pval, gene_list,
                        title = title)
  p1 <- p1 + ylim(c(0, 1))
  
  return(p1)
}

#' Function to plot the pairwise correlation between two tree construction algorithms
#' @param std_tree_cds CellDataFrame for the spanning tree calculated from FPKM  
#' @param absolute_tree_cds CellDataFrame for the spanning tree calculated from transcript counts with Variance Stabilization Transformation (VST) 
#' @export

plot_tree_pairwise_cor <- function(std_tree_cds, absolute_tree_cds) {
  maturation_df <- data.frame(cell = rep(colnames(std_tree_cds), 2), 
                              maturation_level = 100 * c(pData(std_tree_cds)$Pseudotime / max(pData(std_tree_cds)$Pseudotime), 
                                                         pData(absolute_tree_cds)$Pseudotime / max(pData(absolute_tree_cds)$Pseudotime)), 
                              Type = rep(c('FPKM', 'Transcript counts (vst)')),
                              rownames = colnames(absolute_tree_cds))
  
  cor.coeff <- cor(pData(absolute_tree_cds)$Pseudotime, pData(std_tree_cds)$Pseudotime, method = "spearman")
  
  p <- ggplot(aes(x = maturation_level, y = Type, group = cell), data = maturation_df) + geom_point(size = 1) + geom_line(color = 'blue') + xlab('Maturation level') + 
    ylab('Type of tree construction') + annotate("text", x = 80, y = 2.2, label = paste("Spearman correlation:", round(cor.coeff, 2))) + monocle_theme_opts()
  
  return(p)
}

#' function stole from comoundbund to make the scatterplots between two cells and the density plot
#' 
#' @param data The matrix for the expression measurements for several cells
#' @export

plotmatrix2 <- function (data, myLab = 'Transcript Counts', hexbin=FALSE, mapping = aes(), logMode = T, pseudocount = 1, scales_free = T,  alpha = 0.2, ...)
  #Modified from original ggplot2 plotmatrix
{
  
  if(logMode)
  {
    data <- log10(data + pseudocount)
    myLab = paste("log10 (", myLab, " + ", pseudocount, ")", sep = "")
  }
  
  grid <- expand.grid(x = 1:ncol(data), y = 1:ncol(data))
  grid <- subset(grid, x != y)
  all <- do.call("rbind", lapply(1:nrow(grid), function(i) {
    xcol <- grid[i, "x"]
    ycol <- grid[i, "y"]
    data.frame(xvar = names(data)[ycol], yvar = names(data)[xcol], 
               x = data[, xcol], y = data[, ycol], data)
  }))
  all$xvar <- factor(all$xvar, levels = names(data))
  all$yvar <- factor(all$yvar, levels = names(data))
  densities <- do.call("rbind", lapply(1:ncol(data), function(i) {
    data.frame(xvar = names(data)[i], yvar = names(data)[i], 
               x = data[, i])
  }))
  mapping <- plyr::defaults(mapping, aes_string(x = "x", y = "y"))
  class(mapping) <- "uneval"
  
  if(scales_free)
    p <-ggplot(all) + facet_wrap(xvar ~ yvar, scales = "free")
  else
    p <-ggplot(all) + facet_wrap(xvar ~ yvar)
  if(hexbin){ 
    p<- p + geom_hex(mapping,size=1.5,na.rm = TRUE) 
  }else{
    p<- p + geom_point(mapping, alpha=alpha,size=0.8,na.rm=TRUE)
  }
  
  p<- p + stat_density(aes(x = x, 
                           y = ..scaled.. * diff(range(x)) + min(x)), data = densities, 
                       position = "identity", geom = "line") # colour = "buylrd", 
  
  p<- p + geom_abline(intercept=0,slope=1,linetype=2)
  
  p <- p + theme_bw() + ylab(myLab) + xlab(myLab)
  
  p
}

#' plot the gsa hypergeometric test heatmap, originally from Cole
#' 
#' @param cds CellDataFrame 
#' @param gsa_results  The result from using runGSA 
#' @param significance Significance threshold to determine the significant terms 
#' @param sign_type Type of significance (pval or qval)
#' @export
#' 
plot_gsa_hyper_heatmap <- function(cds, gsa_results, significance=0.05)
{
  hyper_df <- ldply(gsa_results, function(gsa_res)
  {
    data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues)
  })
  colnames(hyper_df)[1] <- "cluster_id"
  hyper_df$qval <- p.adjust(hyper_df$pval, method = "fdr")
  #hyper_df 
  
  hyper_df <- subset(hyper_df, qval <= significance)
  print (head(hyper_df))
  hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set), function(x) { nrow(x) }), by="gene_set")
  hyper_df$gene_set <- factor(hyper_df$gene_set, levels=unique(arrange(hyper_df, V1, cluster_id)$gene_set))
  
  save(hyper_df, file = 'hyper_df')   
  print(dim(hyper_df))
  qplot(cluster_id, gene_set, fill=-log10(qval), geom="tile", data=hyper_df) + scale_fill_gradientn(colours=rainbow(7))
}

#' automate loading data, and make the plot and then save 
#' 
#' @param gsa_res The file to be loaded 
#' @param gene_num The number of gene selected for display on the barplot
#' @param selection A logic argument to determine whether or not we should select "GASEOUS" or "LIPID" associated terms 
#' @param custom_p_adjust A logic argument to determine whether or not we should take the significant gene out and perform the pval adjustment separately
#' @param add_terms A logic argument to determine whether or not we should add the terms with GASEOUS" or "LIPID" associated terms 
#' @export

auto_make_enrichment <- function (gsa_res = gsaRes_ABCs, gene_num = 20, selection = F,
                                  custom_p_adjust = F, add_terms = F, direction = T, select_top_stats = F) {
  go_data <- make_enrichment_df(gsa_res, gene_num, custom_p_adjust, add_terms, direction, select_top_stats)
  save(go_data, file = 'go_data')
  if (selection) {
    AT1_id <- grep(go_data[, 1], pattern = "GASEOUS")
    AT2_id <- grep(go_data[, 1], pattern = "^LIPID")
    ids <- sort(unique(c(AT1_id, AT2_id, 1:10, (nrow(go_data) -
                                                  9):nrow(go_data))))
    go_data <- go_data[ids, ]
    gsa_res <- paste(gsa_res, "_selection", sep = "")
  }
  if (custom_p_adjust)
    gsa_res <- paste(gsa_res, "_custom_p_adj", sep = "")
  if (add_terms)
    gsa_res <- paste(gsa_res, "_add_terms", sep = "")
  # go_data <- unique(go_data[, ])
  
  if(is.null(go_data$colour)){
    colour = 'black'
    p1 <- ggplot(aes(x = 1:nrow(go_data), y = abs(as.numeric(stat))),
                 data = go_data) + geom_bar(stat = "identity", aes(fill = colour)) +
      coord_flip() + scale_x_discrete(limits = 1:nrow(go_data),
                                      labels = str_split_fixed(go_data$Name, "%", 2)[, 1]) +
      xlab("") + ylab("Normalized Enrichment Score")
  }
  else {
    colour <- go_data$colour; names(colour) <- go_data$colour
    p1 <- ggplot(aes(x = 1:nrow(go_data), y = abs(as.numeric(stat)) + 1),
                 data = go_data) + geom_bar(stat = "identity", aes(fill = colour)) +
      coord_flip() + scale_x_discrete(limits = 1:nrow(go_data),
                                      labels = str_split_fixed(go_data$Name, "%", 2)[, 1]) + scale_y_log10() + 
      xlab("") + ylab("Normalized Enrichment Score") +  
      scale_fill_manual(name = "Type", values = colour, labels = c("AT1", "AT2"))
  }
  
  p1
}

#' Function to plot the permutation pval
#' @param permutation_p
#' @export

plot_genes_permutation_p <- function(x, permutation_p, type = 'Pos') {
  leng_x <- length(x)
  
  if(x[length(x)] == 'pseudotime_permutate') 
    cds <- mc_abs_14_18
  else
    cds <- get(x[leng_x])
  
  pval <- permutation_p[x[1:(leng_x - 1)]]
  
  if(length(grep('^pse', x[leng_x]))){ #if the dataset is pseudotime, plot the pseudotime 
    p <- plot_genes_in_pseudotime(cds[x[1:length(x) - 1], ])
  }
  else {
    p <-
      plot_genes_jitter(cds[x[1:length(x) - 1], ], grouping = "Time", plot_trend = T, label_by_short_name = F, ncol = 4, nrow = 3, pvalue = pval) + 
      ggtitle(paste(x[length(x)], '(', type, ')', sep = ''))
  }
  p
}

#' Function to plot the optimization landscape 
#' @param mc_minimization the data frame storing all the result returned from the otpimization function  
#' @param parameter_list The list of parmeters (columns in the data.frame)
#' @param plot_parameter The parameters to be used in the plot
#' @param return_res A logic flag to determine whether or not the result will also be returned
#' @param weight A numberic value range from 0 to 1 to determine the weights for each part
#' @param alpha The alpha value used in the object function in the optimization 
#' @param total_RNAs assumed total mRNA numbers in the cells 
#' @param verbose A logic flag to determine whether or not the details should be returned
#' @export
#' 
plot_optimization_parameters <- function(mc_minimization, parameter_list = c('dmode_rmse_weight_total', 'mode_mean', 'diff_k', 'dmode_rmse', 'dmode_rmse_norm', 'dmode_rmse_norm_total', 'dmode_rmse_minus_total'),
                                         plot_parameter = c('part1', 'part2', 'dmode_rmse_weight_total'), return_res = FALSE, weight = 0.5,
                                         alpha = 1, total_RNAs = 50000, verbose = FALSE) {
  #function to determine whether or mc_minimization is a list or matrix
  if(is.matrix(mc_minimization)) {
    tmp <- t(mc_minimization)
    
    optimization_all_parts <- apply(tmp, 1,  function(x){
      if(is.na(x) | length(x) == 1)
        return(NA)
      else{
        tmp <- c()
        for(i in 1:length(parameter_list))
          tmp <- c(tmp, mean(x[[parameter_list[i]]]))
        names(tmp) <- parameter_list
        #         tmp[is.na(tmp)] <- -1
        
        if(all(c('sum_total_cells_rna', 'cell_dmode') %in% names(x)))
          res_tmp <- data.frame(m = x['m'], c = x['c'], part1 = mean(weight * (x[['cell_dmode']] - alpha)^2), part2 = mean((1-weight) *((x[['sum_total_cells_rna']] - total_RNAs)/total_RNAs)^2), 
                                dmode_rmse_weight_total = x[['dmode_rmse_weight_total']])
        else
          res_tmp <- data.frame(m = x[['m']], c = x[['c']])
        
        res <- cbind(res_tmp, t(tmp))
        res
      }
    })
    
    optimization_all_parts <- do.call(rbind.data.frame, optimization_all_parts)
  }
  else if(is.list(mc_minimization)) {
    optimization_all_parts <- do.call(rbind.data.frame, lapply(mc_minimization, function(x){
      if(is.na(x) | length(x) == 1)
        return(NA)
      else{
        tmp <- c()
        for(i in 1:length(parameter_list))
          tmp <- c(tmp, mean(x[[parameter_list[i]]]))
        names(tmp) <- parameter_list
        #         tmp[is.na(tmp)] <- -1
        
        if(all(c('sum_total_cells_rna', 'cell_dmode') %in% names(x)))
          res_tmp <- data.frame(m = x['m'], c = x['c'], part1 = mean(weight * (x[['cell_dmode']] - alpha)^2), part2 = mean((1-weight) *((x[['sum_total_cells_rna']] - total_RNAs)/total_RNAs)^2), 
                                dmode_rmse_weight_total = x[['dmode_rmse_weight_total']])
        else
          res_tmp <- data.frame(m = x[['m']], c = x[['c']])
        
        res <- cbind(res_tmp, t(tmp))
        res
      }
    }))
  }
  
  optimization_all_parts <- optimization_all_parts[!is.na(optimization_all_parts[, 3]), ]
  tmp_optimization_all_parts <- optimization_all_parts[optimization_all_parts[, plot_parameter] < 40000000000, ]
  plot3d(tmp_optimization_all_parts[, 1], tmp_optimization_all_parts[, 2], log10(tmp_optimization_all_parts [, plot_parameter]), col = 'red', xlab = 'm', ylab = 'c', zlab = plot_parameter)
  
  if(return_res)
    return(optimization_all_parts)
}

#' Function to plot the enrichmented terms from the data retrieved from DAVID 
#' @export
#' 
plot_BP_David <- function(file = 'AT2_BP_David.txt', value = 'black', select_terms = c("monosaccharide catabolic process", "cellular lipid catabolic process", "glucose catabolic process", "RNA splicing, via transesterification reactions", "lipid catabolic process", "hexose metabolic process", "ribonucleoprotein complex biogenesis", "fatty acid catabolic process")) {
  BP_David <- read.table(file = file, header = T, sep = '\t')
  
  #add the barplot: 
  BP_David$Term <- str_split_fixed(BP_David$Term, "~", 2)[, 2]
  BP_David_subset <- subset(BP_David, Term %in% select_terms)
  
  p1 <- qplot(x = 1:nrow(BP_David_subset), y = abs(log(PValue)),
              data = BP_David_subset, geom = "bar", stat = "identity", fill = 'black') +
    coord_flip() + scale_x_discrete(limits = 1:nrow(BP_David_subset),
                                    labels = BP_David_subset$Term) +
    xlab("") + ylab("Normalized Enrichment Score") + scale_fill_manual(name = "Type", values = value)
  
  p1
}

plot_enrichment <- function(enriched_terms = gsaRes_go, num = 25, direction = F, select_top_stats = T){
  data <- make_enrichment_df(gsa_res = enriched_terms, gene_num = num, custom_p_adjust = F, add_terms = F, direction = direction, select_top_stats = T)
  
  p <- qplot(x = 1:nrow(data), y = abs(as.numeric(stat)), data = data,
             geom = "bar", stat = "identity") + coord_flip() +
    scale_x_discrete(limits = 1:nrow(data), labels = str_split_fixed(data$Name,
                                                                     "%", 2)[, 1]) + xlab("") + ylab("Normalized Enrichment Score") 
  
  p
}

#' Function to plot the trajectories of two genes  
#' @export
#' 
plot_gene_pair_trajectory2<- function(data = abs_AT12_cds_subset_all_gene, gene_pairs = c("Ager", "Sftpc"), h = 1) {
  gene_pairs_ids <- row.names(subset(fData(abs_AT12_cds_subset_all_gene), gene_short_name %in% gene_pairs))
  exprs_data <- data[gene_pairs_ids, ]
  exprs_data <- as.data.frame(t(exprs_data))
  
  #add the principial curves: 
  # ini_path <- exprs_data[sort(pData(data)$Pseudotime, index.return = T)$ix, ] #from the MST/pc tree 
  # ini_path <- loess(exprs_data[, 1] ~ exprs_data[, 2])#from the lowess curve
  ini_path <- lowess(exprs_data[, 1], exprs_data[, 2]); ini_path <- as.matrix(data.frame(x = ini_path$x, y = ini_path$y))
  
  gene_pair_pc <- principal.curve(as.matrix(exprs_data), start = ini_path)
  
  qplot(exprs_data[, 1], exprs_data[, 2], geom = 'point', log = 'xy', 
        size = I(1), #color = pData(data)$State, 
        size = 2) + stat_density2d(geom = "tile", aes(fill = ..density..),
                                   contour = FALSE, h = h) + geom_point(color = I("darkgray"),
                                                                        size = I(0.85)) + scale_fill_gradientn(colours = buylrd) +
    ylab(gene_pairs[1]) + xlab(gene_pairs[2]) +
    geom_path(aes(gene_pair_pc$s[gene_pair_pc$tag, 1], gene_pair_pc$s[gene_pair_pc$tag, 2]), color = 'black') + 
    theme(strip.background = element_rect(colour = "white",
                                          fill = "white")) + theme(panel.border = element_blank(),
                                                                   axis.line = element_line()) + theme(legend.position = "none") +
    theme(axis.title.y = element_text(size = 10)) + theme(axis.title.x = element_text(size = 10)) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank())
  
  # save(exprs_data, file = 'exprs_data')
}

#' Function to make the gsa hypergeometric enrichment plots 
#' @export
#'
plot_gsa_hyper_heatmap2 <- function(cds, gsa_results, significance=0.05)
{
  hyper_df <- ldply(gsa_results, function(gsa_res)
  {
    data.frame(gene_set = names(gsa_res$pvalues), pval = gsa_res$pvalues, qval = gsa_res$p.adj)
  })
  colnames(hyper_df)[1] <- "cluster_id"
  
  #hyper_df 
  
  hyper_df <- subset(hyper_df, qval <= significance)
  print (head(hyper_df))
  hyper_df <- merge(hyper_df, ddply(hyper_df, .(gene_set), function(x) { nrow(x) }), by="gene_set")
  #print (hyper_df)
  hyper_df$gene_set <- factor(hyper_df$gene_set, levels=unique(arrange(hyper_df, V1, cluster_id)$gene_set))
  
  qplot(cluster_id, gene_set, fill=-log10(qval), geom="tile", data=hyper_df) + scale_fill_gradientn(colours=rainbow(7))
}

#' Function to make the ILR enrichment heatmap plots 
#' @export
#'
plot_ILRs_clusters <- function (cds, clustering, drawSummary = TRUE, sumFun = mean_cl_boot,
                                ncol = NULL, nrow = NULL, row_samples = NULL, callout_ids = NULL,
                                conf_int = 0.68)
{
  m <- as.data.frame(clustering$exprs)
  m$ids <- rownames(clustering$exprs)
  if (is.null(clustering$labels) == FALSE) {
    m$cluster = factor(clustering$labels[clustering$clustering],
                       levels = levels(clustering$labels))
  }
  else {
    m$cluster <- factor(clustering$clustering)
  }
  cluster_sizes <- as.data.frame(table(m$cluster))
  cluster_sizes$Freq <- paste("(", cluster_sizes$Freq, ")")
  facet_labels <- str_join(cluster_sizes$Var1, cluster_sizes$Freq,
                           sep = " ")
  facet_wrap_labeller <- function(gg.plot, labels = NULL) {
    require(gridExtra)
    g <- ggplotGrob(gg.plot)
    gg <- g$grobs
    strips <- grep("strip_t", names(gg))
    for (ii in seq_along(labels)) {
      modgrob <- getGrob(gg[[strips[ii]]], "strip.text",
                         grep = TRUE, global = TRUE)
      gg[[strips[ii]]]$children[[modgrob$name]] <- editGrob(modgrob,
                                                            label = labels[ii])
    }
    g$grobs <- gg
    class(g) = c("arrange", "ggplot", class(g))
    g
  }
  m.melt <- melt(m, id.vars = c("ids", "cluster"))
  m.melt <- merge(m.melt, pData(cds), by.x = "variable", by.y = "row.names")
  if (is.null(row_samples) == FALSE) {
    m.melt <- m.melt[sample(nrow(m.melt), row_samples), ]
  }
  c <- ggplot(m.melt) + facet_wrap("cluster", ncol = ncol,
                                   nrow = nrow, scales = "free_y")
  if (drawSummary) {
    c <- c + stat_summary(aes(x = Pseudotime, y = value,
                              group = 1), fun.data = sumFun, color = "red", alpha = 0.2,
                          size = 0.5, geom = "smooth")
  }
  c <- c + scale_color_hue(l = 50, h.start = 200) + theme(axis.text.x = element_text(angle = 0,
                                                                                     hjust = 0)) + xlab("Pseudo-time") + ylab("Expression")
  c <- c + theme(strip.background = element_rect(colour = "white",
                                                 fill = "white")) + theme(panel.border = element_blank()) +
    theme(legend.position = "none") + theme(panel.grid.minor.x = element_blank(),
                                            panel.grid.minor.y = element_blank()) + theme(panel.grid.major.x = element_blank(),
                                                                                          panel.grid.major.y = element_blank())
  if (is.null(callout_ids) == FALSE) {
    callout_melt <- subset(m.melt, ids %in% callout_ids)
    c <- c + geom_line(aes(x = Pseudotime, y = value), data = callout_melt,
                       color = I("steelblue"))
  }
  c <- c + monocle_theme_opts()
  c
}

#' Function to make the derivative of the log-fc, etc.  
#' @export
#'
plot_derivatives <- function(str_logfc_df, id = 1) {
  p1 <- qplot(1:98, diff(diff(str_logfc_df[id, ])))
  p2 <- qplot(1:99, diff(str_logfc_df[id, ]))
  p3 <- qplot(1:100, str_logfc_df[id, ])
  multiplot(plotlist = list(p1, p2, p3))
}

#' Plot the branch genes in pseduotime with separate lineage curves (This function provide the p-val and null models comparing to plot_genes_branched_pseudotime2).
#' 
#' This plotting function is used to make the branching plots for a lineage dependent gene goes through the progenitor state
#' and bifurcating into two distinct lineages (Similar to the pitch-fork bifurcation in dynamic systems). In order to make the  
#' bifurcation plot, we first duplicated the progenitor states and by default stretch each lineage into maturation level 0-100.  
#' Then we fit two nature spline curves for each lineages using VGAM package.  
#'
#' @param cds CellDataSet for the experiment
#' @param lineage_states The states for two branching lineages
#' @param lineage_labels The names for each branching lineage
#' @param method The method to draw the curve for the gene expression branching pattern, either loess ('loess') or VGLM fitting ('fitting') 
#' @param stretch A logic flag to determine whether or not the pseudotime trajectory for each lineage should be stretched to the same range or not 
#' @param min_expr the minimum (untransformed) expression level to use in plotted the genes.
#' @param cell_size the size (in points) of each cell used in the plot
#' @param nrow number of columns used to layout the faceted cluster panels
#' @param ncol number of columns used to layout the faceted cluster panels
#' @param panel_order the order in which genes should be layed out (left-to-right, top-to-bottom)
#' @param color_by the cell attribute (e.g. the column of pData(cds)) to be used to color each cell 
#' @param trend_formula the model formula to be used for fitting the expression trend over pseudotime
#' @param label_by_short_name label figure panels by gene_short_name (TRUE) or feature id (FALSE)
#' @param weighted  A logic flag to determine whether or not we should use the navie logLikelihood weight scheme for the duplicated progenitor cells
#' @param add_ABC A logic flag to determine whether or not we should add the ABC score for each gene 
#' @param relative_expr A logic flag to determine whether or not we should use the relative expression values
#' @return a ggplot2 plot object
#' @import ggplot2
#' @importFrom plyr ddply
#' @importFrom reshape2 melt
#' @export 
#' @examples
#' \dontrun{
#' full_model_fits <- fitModel(HSMM_filtered[sample(nrow(fData(HSMM_filtered)), 100),],  modelFormulaStr="~VGAM::bs(Pseudotime)")
#' expression_curve_matrix <- responseMatrix(full_model_fits)
#' clusters <- clusterGenes(expression_curve_matrix, k=4)
#' plot_clusters(HSMM_filtered[ordering_genes,], clusters)
#' }
plot_genes_branched_pseudotime2 <- function(cds, lineage_states = c(2, 3), lineage_labels = NULL, relative_expr = T, 
                                             method = "fitting", stretch = TRUE, min_expr = NULL, cell_size = 0.75,
                                             nrow = NULL, ncol = 1, panel_order = NULL, cell_color_by = "State", trajectory_color_by = "State", 
                                             fullModelFormulaStr = "~ sm.ns(Pseudotime, df=3) * Lineage", reducedModelFormulaStr = NULL, 
                                             label_by_short_name = TRUE, weighted = TRUE, add_ABC = FALSE, add_pval = FALSE, normalize = TRUE, bifurcation_time = NULL, ...)
{
  if (add_ABC) {
    ABCs_df <- calABCs(cds, fullModelFormulaStr = fullModelFormulaStr,
                       lineage_states = lineage_states, stretch = stretch,
                       weighted = weighted, min_expr = min_expr, lineage_labels = lineage_labels,
                       ...)
    fData(cds)[, "ABCs"] <- ABCs_df$ABCs
  }
  if (add_pval) {
    pval_df <- branchTest(cds, fullModelFormulaStr = fullModelFormulaStr, relative_expr = relative_expr, weighted = weighted,  
                          reducedModelFormulaStr = "~ sm.ns(Pseudotime, df=3)")
    fData(cds)[, "pval"] <- pval_df[row.names(cds), 'pval']
  }
  if("Lineage" %in% all.vars(terms(as.formula(fullModelFormulaStr)))) {
    cds_subset <- buildLineageBranchCellDataSet(cds = cds, lineage_states = lineage_states,
                                                lineage_labels = lineage_labels, method = method, stretch = stretch,
                                                weighted = weighted, ...)
  }
  else {
    cds_subset <- cds
    pData(cds_subset)$Lineage <- pData(cds_subset)$State
  }
  
  cds_subset@dispFitInfo[['blind']] <- cds@dispFitInfo[['blind']]    
  if (cds_subset@expressionFamily@vfamily %in% c("zanegbinomialff",
                                                 "negbinomial", "poissonff", "quasipoissonff")) {
    integer_expression <- TRUE
  }
  else {
    integer_expression <- FALSE
  }
  if (integer_expression) {
    CM <- exprs(cds_subset)
    if (normalize)
      CM <- t(t(CM)/sizeFactors(cds_subset))
    cds_exprs <- reshape2::melt(round(CM))
  }
  else {
    cds_exprs <- reshape2::melt(exprs(cds_subset))
  }
  if (is.null(min_expr)) {
    min_expr <- cds_subset@lowerDetectionLimit
  }
  colnames(cds_exprs) <- c("f_id", "Cell", "expression")
  cds_pData <- pData(cds_subset)
  if (add_ABC)
    cds_fData <- ABCs_df
  else cds_fData <- fData(cds_subset)
  cds_exprs <- merge(cds_exprs, cds_fData, by.x = "f_id", by.y = "row.names")
  cds_exprs <- merge(cds_exprs, cds_pData, by.x = "Cell", by.y = "row.names")
  if (integer_expression) {
    cds_exprs$adjusted_expression <- round(cds_exprs$expression)
  }
  else {
    cds_exprs$adjusted_expression <- log10(cds_exprs$expression)
  }
  if (label_by_short_name == TRUE) {
    if (is.null(cds_exprs$gene_short_name) == FALSE) {
      cds_exprs$feature_label <- as.character(cds_exprs$gene_short_name)
      cds_exprs$feature_label[is.na(cds_exprs$feature_label)] <- cds_exprs$f_id
    }
    else {
      cds_exprs$feature_label <- cds_exprs$f_id
    }
  }
  else {
    cds_exprs$feature_label <- cds_exprs$f_id
  }
  cds_exprs$feature_label <- as.factor(cds_exprs$feature_label)
  # trend_formula <- paste("adjusted_expression", trend_formula,
  #     sep = "")
  cds_exprs$Lineage <- as.factor(cds_exprs$Lineage)
  # merged_df_with_vgam <- plyr::ddply(cds_exprs, .(feature_label),
  #     function(x) {
  #         fit_res <- tryCatch({
  #             expressionFamily <- cds@expressionFamily
  #             if (expressionFamily@vfamily == "negbinomial") {
  #               if (!is.null(cds@dispFitInfo[["blind"]]$disp_func)) {
  #                 disp_guess <- calulate_NB_dispersion_hint(cds@dispFitInfo[["blind"]]$disp_func,
  #                   x$adjusted_expression)
  #                 if (is.null(disp_guess) == FALSE && disp_guess >
  #                   0 && is.na(disp_guess) == FALSE) {
  #                   expressionFamily <- negbinomial(isize = 1/disp_guess)
  #                 }
  #               }
  #             }
  #             vg <- suppressWarnings(vglm(formula = as.formula(trend_formula),
  #               family = expressionFamily, data = x, maxit = 30,
  #               checkwz = FALSE, trace = T))
  #             if (integer_expression) {
  #               res <- predict(vg, type = "response")
  #               res[res < min_expr] <- min_expr
  #             }
  #             else {
  #               res <- 10^(predict(vg, type = "response"))
  #               res[res < log10(min_expr)] <- log10(min_expr)
  #             }
  #             res
  #         }, error = function(e) {
  #             print("Error!")
  #             print(e)
  #             res <- rep(NA, nrow(x))
  #             res
  #         })
  #         df <- cbind(x, expectation = fit_res)
  
  #         df
  #     })
  
  new_data <- data.frame(Pseudotime = pData(cds_subset)$Pseudotime, Lineage = pData(cds_subset)$Lineage)
  full_model_expectation <- genSmoothCurves(cds_subset, cores=1, trend_formula = fullModelFormulaStr, weights = pData(cds_subset)$weight, 
                                            relative_expr = relative_expr, pseudocount = 0, new_data = new_data)
  colnames(full_model_expectation) <- colnames(cds_subset)
  
  cds_exprs$full_model_expectation <- apply(cds_exprs,1, function(x) full_model_expectation[x[2], x[1]])
  if(!is.null(reducedModelFormulaStr)){
    reduced_model_expectation <- genSmoothCurves(cds_subset, cores=1, trend_formula = reducedModelFormulaStr, weights = pData(cds_subset)$weight, 
                                                 relative_expr = relative_expr, pseudocount = 0, new_data = new_data)
    colnames(reduced_model_expectation) <- colnames(cds_subset)
    cds_exprs$reduced_model_expectation <- apply(cds_exprs,1, function(x) reduced_model_expectation[x[2], x[1]])
  }
  
  if(!is.null(bifurcation_time)){
    cds_exprs$bifurcation_time <- bifurcation_time[as.vector(cds_exprs$gene_short_name)]
  }
  # merged_df_with_vgam <- cds_exprs
  # save(full_model_expectation, new_data, file = 'full_model_expectation')
  if (method == "loess")
    cds_exprs$expression <- cds_exprs$expression + cds@lowerDetectionLimit
  if (label_by_short_name == TRUE) {
    if (is.null(cds_exprs$gene_short_name) == FALSE) {
      cds_exprs$feature_label <- as.character(cds_exprs$gene_short_name)
      cds_exprs$feature_label[is.na(cds_exprs$feature_label)] <- cds_exprs$f_id
    }
    else {
      cds_exprs$feature_label <- cds_exprs$f_id
    }
  }
  else {
    cds_exprs$feature_label <- cds_exprs$f_id
  }
  cds_exprs$feature_label <- factor(cds_exprs$feature_label)
  if (is.null(panel_order) == FALSE) {
    cds_exprs$feature_label <- factor(cds_exprs$feature_label,
                                      levels = panel_order)
  }
  
  #save(cds_exprs, cds_subset, file = 'cds_exprs')
  #fix the bug to have NA or 0 values in the expression / expectation values: 
  cds_exprs$expression[is.na(cds_exprs$expression)] <- min_expr
  cds_exprs$expression[cds_exprs$expression < min_expr] <- min_expr
  cds_exprs$full_model_expectation[is.na(cds_exprs$full_model_expectation)] <- min_expr
  cds_exprs$full_model_expectation[cds_exprs$full_model_expectation < min_expr] <- min_expr
  
  if(!is.null(reducedModelFormulaStr)){
    cds_exprs$reduced_model_expectation[is.na(cds_exprs$reduced_model_expectation)] <- min_expr
    cds_exprs$reduced_model_expectation[cds_exprs$reduced_model_expectation < min_expr] <- min_expr
  }
  
  cds_exprs$State <- as.factor(cds_exprs$State)
  cds_exprs$Lineage <- as.factor(cds_exprs$Lineage)
  # q <- ggplot(aes(Pseudotime, expression), data = cds_exprs)
  # cds_exprs <- cbind(cds_exprs, cds_exprs)
  # cds_exprs$State <- as.factor(cds_exprs$State)
  # cds_exprs$Lineage <- as.factor(cds_exprs$Lineage)
  q <- ggplot(aes(Pseudotime, expression), data = cds_exprs)
  
  if (!is.null(bifurcation_time)){
    q <- q + geom_vline(aes(xintercept = bifurcation_time), color = 'black', linetype = "longdash")
  }
  
  if (is.null(cell_color_by) == FALSE) {
    q <- q + geom_point(aes_string(color = cell_color_by), size = I(cell_size))
  }
  if (add_ABC)
    q <- q + scale_y_log10() + facet_wrap(~feature_label +
                                            ABCs, nrow = nrow, ncol = ncol, scales = "free_y")
  else if (add_pval)
    q <- q + scale_y_log10() + facet_wrap(~feature_label +
                                            pval, nrow = nrow, ncol = ncol, scales = "free_y")
  else q <- q + scale_y_log10() + facet_wrap(~feature_label,
                                             nrow = nrow, ncol = ncol, scales = "free_y")
  if (method == "loess")
    q <- q + stat_smooth(aes(fill = Lineage, color = Lineage),
                         method = "loess")
  else if (method == "fitting") {
    save(q, file = 'q')
    q <- q + geom_line(aes_string(x = "Pseudotime", y = "full_model_expectation",
                                  color = trajectory_color_by), data = cds_exprs) + scale_color_manual(name = "Type", values = c(colour_cell, colour) )#, labels = c("Progenitor", lineage_labels, lineage_labels))
  }
  
  if(!is.null(reducedModelFormulaStr)) {
    q <- q + geom_line(aes_string(x = "Pseudotime", y = "reduced_model_expectation"),
                       color = 'black', linetype = 2, data =  cds_exprs)   
  }
  if (stretch)
    q <- q + ylab("Expression") + xlab("Maturation levels")
  else q <- q + ylab("Expression") + xlab("Pseudotime")
  q <- q + monocle_theme_opts()
  # q + expand_limits(y = min_expr)
}

#' functions for formating the plot
#' @export
monocle_theme_opts <- function() {
  theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
    theme(panel.border = element_blank(), axis.line = element_line()) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + 
    theme(panel.background = element_rect(fill='white'))
}

#' functions for formating the plot for nature method or nature biotech papers:
#' @export
nm_theme <- function() {
  theme(strip.background = element_rect(colour = 'white', fill = 'white')) +
    theme(panel.border = element_blank(), axis.line = element_line()) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) + 
    theme(panel.background = element_rect(fill='white')) + 
    #theme(text = element_text(size=6)) + 
    theme(axis.text.y=element_text(size=6)) + 
    theme(axis.text.x=element_text(size=6)) +
    theme(axis.title.y=element_text(size=6)) + 
    theme(axis.title.x=element_text(size=6)) +
    theme(panel.border = element_blank(), axis.line = element_line(size = .1), axis.ticks = element_line(size = .1)) +
    theme(panel.grid.minor.x = element_blank(), panel.grid.minor.y = element_blank()) +
    theme(panel.grid.major.x = element_blank(), panel.grid.major.y = element_blank()) +
    theme(legend.position = "none") +
    theme(strip.text.x = element_text(colour="black", size=6)) + 
    theme(strip.text.y = element_text(colour="black", size=6)) + 
    theme(legend.title = element_text(colour="black", size = 6)) + 
    theme(legend.text = element_text(colour="black", size = 6)) + 
    theme(plot.margin=unit(c(0,0,0,0), "lines")) 
}

#' functions for formating the plot for nature method or nature biotech papers:
#' @export
plot_gene_set_enrichment <- function(gsa_res, gene_num = 20, selection = F,
            custom_p_adjust = F, add_terms = F) {
    # Extract gene set enrichment data for more genes than needed (ensures will get equal AT1 and AT2 numbers)
    go_data <- make_enrichment_df(gsa_res, 1000000, custom_p_adjust, add_terms)
    go_data <- unique(go_data[, ])
    
    # Get only the significant values and assign to lineages based on adjusted pvalues
    AT1_values = go_data[go_data$"p adj (dist.dir.up)" < 0.05, ]
    AT1_values$lineage = 'Lineage 2'
    
    AT2_values = go_data[go_data$"p adj (dist.dir.dn)" < 0.05, ]
    AT2_values$lineage = 'Lineage 3'
    
    # Get the top significant values by stat
    top_AT1 = tail(AT1_values, gene_num)
    top_AT2 = head(AT2_values, gene_num)
    
    top_go_data = rbind(top_AT2, top_AT1)
    
    print(AT1_values$stat)
    print(AT2_values$stat)
    
    gsea_plot <- qplot(x = 1:nrow(top_go_data), y = abs(as.numeric(stat)), data = top_go_data, geom = "bar", stat = "identity", fill = lineage) +
      coord_flip() +
      scale_x_discrete(limits = 1:nrow(top_go_data), labels = str_split_fixed(top_go_data$Name, "%", 2)[, 1]) +
      xlab("") +
      ylab("Normalized Enrichment Score") +
      scale_fill_discrete(name = "Type", labels = c("Lineage 2", "Lineage 3"))
    
    return(gsea_plot)
}

#plot SOM 

#violin plot / pole plot 

#ggtern for triangle plot 

