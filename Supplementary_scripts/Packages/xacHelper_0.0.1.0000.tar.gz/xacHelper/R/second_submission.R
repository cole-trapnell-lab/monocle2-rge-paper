#' Calculate the dimension mode
#' make the hierarchical clustering 
#' @export
plot_clustering_heatmap <- function(cds, num_clusters = 3) {
  exprs_df <- exprs(cds)
  exprs_df <- exprs_df[apply(exprs_df, 1,function(x) !any(is.na(x))), ]
  
  #scaling the data: 
  exprs_df <- t(scale(t(exprs_df)))
  exprs_df[exprs_df > 3] <- 3
  exprs_df[exprs_df < -3] <- -3
  
  row_dist <- as.dist((1 - cor(t(exprs_df)))/2)
  row_dist[is.na(row_dist)] <- 1
  
  bk <- seq(-3.1, 3.1, by = 0.1)
  hmcols <- blue2green2red(length(bk) - 1)
  
  row.names(exprs_df) <- fData(cds[row.names(exprs_df), ])$gene_short_name
  ph <- pheatmap(exprs_df, 
                 cluster_cols = T, 
                 cluster_rows = TRUE,
                 show_rownames = T, 
                 show_colnames = T,  
                 clustering_distance_rows = row_dist,
                 clustering_method = "ward.D2", 
                 color = hmcols, 
                 fontsize = 3,
                 cutree_cols = num_clusters,
                 file = './tmp/hc_unstimulated_cells.pdf')
  
  #return ph: 
  return(ph)
}

#' LLE
#' perform LLE dimension reduction
#' @export
LLE <- function(data = X, max_components = 2, reg = 2, ss = FALSE, id = TRUE, v = 0.9, iLLE = FALSE) {
  num_neigh_list <- calc_k(data, m = max_components, kmin = 1, kmax = 20, plotres = TRUE, 
                           parallel = T, cpus = 2, iLLE = iLLE) 
  # weights <- find_weights(X = data, m = 2, reg = 2)
  # weights$wgts[1:6, 1:6]
  
  num_neigh <- num_neigh_list$k[which(num_neigh_list$rho == min(num_neigh_list$rho))]
  
  lle_reduced_data <- lle(t(data), m = max_components, k = num_neigh, reg = reg, ss = ss, id = id, v = v, iLLE = iLLE)
  
  return(t(lle_reduced_data$Y))
}

#' tSNE
#' perform tSNE dimension reduction
#' @export
tSNE <- function(data = X, max_components = 2, max_iter = 500, min_cost = 0, whiten = TRUE, epoch=100) {
  # # initialize counter to 0
  # epc <- function(x) {
  #     x <<- x + 1
  #     filename <- paste("d:\\plot", x, "jpg", sep=".")
  #     cat("> Plotting TSNE to ", filename, " ")
  
  #     # plot to d:\\plot.x.jpg file of 2400x1800 dimension
  #     jpeg(filename, width=2400, height=1800)
  
  #     plot(x, t='n', main="T-SNE")
  #     text(x, labels=rownames(mydata))
  #     dev.off()
  # }
  
  # run tsne (maximum iterations:500, callback every 100 epochs, target dimension k=5)
  tsne_data <- tsne(t(data), k = max_components, epoch_callback = NULL, max_iter = max_iter, min_cost = min_cost, whiten = whiten, epoch = epoch)
  
  return(t(tsne_data))
}

#diffusion map: 
#' diffusion map algorithm based on the German group
#'
#' @param cds a matrix of relative expression values for
#' values with each row and column representing genes/isoforms and cells,
#' respectively. Row and column names should be included.
#' Expression values should not be log-transformed.
#' @param pseudo_cnt parameter for the intended return results. If setting TRUE,
#' matrix of dmode as well as max mu and min mu of two gaussian distribution
#' mixture will be returned
#' @param neighbours Relative expression values below this threshold
#' are considered zero.
#' @param bw_ini
#' @param iter
#' @param step
#' @param log2_data
#' @return an vector of most abundant relative_expr value corresponding to the
#' RPC 1. If setting return_all = TRUE, the mode based on gaussian
#' density function and the max or min
#' mode from the mixture gaussian model
#' @details This function estimates the most abundant relative expression value
#' (t^*) using a gaussian kernel density function. It can also optionally
#' output the t^* based on a two gaussian mixture model
#' based on the smsn.mixture from mixsmsn package
#' @export
#' @examples
#' \dontrun{
#' HSMM_fpkm_matrix <- exprs(HSMM)
#' t_estimate = estimate_t(HSMM_fpkm_matrix)
#'}
#'
#'
diffusion_maps_bw <- function(data, pseudo_cnt = 1, neighbours = 1, bw_ini = 0, iter = 100, step = .02, log2_data = F){
  if(log2_data)
    data <- t(log2_data(data + pseudo_cnt))
  else
    data <- t(data)
  
  log_z_x <- rep(0, iter)
  log_d_sigma <- rep(0, iter)
  for(i in 1:iter) {
    sigma = 10^(bw_ini + i * step)
    
    nn <- ceiling(nrow(data) * neighbours)
    d2 <- as.matrix(dist(data)^2)
    
    W <- exp(-d2 / (2 * sigma^2))
    
    D <- colSums(W, na.rm = T)
    
    log_z_x[i] <- (sum(log10(D/nrow(data))/(D)))/sum(1/D)
    log_d_sigma[i] <- log10(sigma)
  }
  
  av_d_sigma <- diff(log_z_x) / diff(log_d_sigma)
  
  return(list(log_d_sigma = log_d_sigma, av_d_sigma = av_d_sigma))
}

#' disconnected map and noisy map:
#'
#' @param cds a matrix of relative expression values for
#' values with each row and column representing genes/isoforms and cells,
#' respectively. Row and column names should be included.
#' Expression values should not be log-transformed.
#' @param bw parameter for the intended return results. If setting TRUE,
#' matrix of dmode as well as max mu and min mu of two gaussian distribution
#' mixture will be returned
#' @param pseudo_cnt Relative expression values below this threshold
#' are considered zero.
#' @param neighbours
#' @param iter
#' @param log2_data
#' @return an vector of most abundant relative_expr value corresponding to the
#' RPC 1. If setting return_all = TRUE, the mode based on gaussian
#' density function and the max or min
#' mode from the mixture gaussian model
#' @details This function estimates the most abundant relative expression value
#' (t^*) using a gaussian kernel density function. It can also optionally
#' output the t^* based on a two gaussian mixture model
#' based on the smsn.mixture from mixsmsn package
#' @export
#' @examples
#' \dontrun{
#' HSMM_fpkm_matrix <- exprs(HSMM)
#' t_estimate = estimate_t(HSMM_fpkm_matrix)
#'}
#'
#'
diffusion_maps <- function(data, bw_ini = 0, pseudo_cnt = 1, neighbours = .2, log2_data = F, max_components = 2) {
  if(log2_data)
    data <- t(log2(data + pseudo_cnt))
  else
    data <- t(data)
  
  data_dm_bw_res <- diffusion_maps_bw(data, pseudo_cnt = pseudo_cnt, neighbours = neighbours, bw_ini = 0, iter = 100, step = .02, log2_data = log2_data)
  #get the best parameters you want: 
  bw = 10^(0.2 * (which(data_dm_bw_res$av_d_sigma == max(data_dm_bw_res$av_d_sigma)) + 1))
  
  nn <- ceiling(nrow(data) * neighbours)
  d2 <- as.matrix(dist(data)^2)
  sigma <- bw^2
  W <- exp(-d2 / (2 * sigma))
  R <- apply(d2, 2, function(x) sort(x)[nn])
  R <- matrix(rep(R,ncol(d2)), ncol=ncol(d2))
  W <- (d2<R) * W
  W <- W+t(W)
  D <- colSums(W, na.rm = T)
  q <- D %*% t(D)
  diag(W) <- 0
  H <- W / q
  colS <- colSums(H)
  Hp <- t(t(H) / colS)
  E <- eigen(Hp)
  eigOrd <- order(Re(E$values), decreasing = TRUE)     # New part to re-order by real part
  E$values <- E$values[eigOrd][-1]
  E$vectors <- E$vectors[,eigOrd][,-1]
  rownames(E$vectors) <- rownames(data)
  colnames(E$vectors) <- 1:ncol(E$vectors)
  diffMap <- t(E$vectors)
  
  #scatterplot3d(diffMap[, 2], diffMap[, 4], diffMap[, 1]) #
  # qplot(diffMap[,1], diffMap[,2], color = pData(cds)$Time)
  
  return(diffMap[1:max_components, ])
}

#' MAST_deg 
#' use MAST for differential gene expression tests
#' @export
MAST_deg <- function(cds, grp = 'Time', test.type = 'hurdle', normalization = F) {
  data <- as.matrix(exprs(cds))
  
  if(normalization)
    data <- t(t(data) / sizeFactors(cds))
  else
    data <- data
  
  data <- melt(data)
  colnames(data) <- c('Gene', 'Cell', 'exprs')
  data[, grp] <- c(pData(cds)[data[, 2], grp])
  data$ncells <- 1 
  
  mast_cds <- FluidigmAssay(data, idvars="Cell", 
                            primerid='Gene', measurement='exprs', geneid="Gene", 
                            ncells = 'ncells', phenovars=grp)
  
  zlm.output <- zlm.SingleCellAssay(as.formula(paste("~ ", grp)), mast_cds, method='glm', ebayes=TRUE) #
  # show(zlm.output)
  zlm.lr <- lrTest(zlm.output, grp)
  # dimnames(zlm.lr)
  
  pval_df <- zlm.lr[,,'Pr(>Chisq)']
  pval <- pval_df[, test.type]
  
  return(pval)
}