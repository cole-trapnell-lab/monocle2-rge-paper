# DDRTree
An R implementation of the DDRTree algorithm for learning principal graphs
