#' calculate the square distance between a, b
#' @param a a matrix with \eqn{D \times N} dimension
#' @param b a matrix with \eqn{D \times N} dimension
#' @return a numeric value for the different between a and b
#' @export
sqdist_R_R <- function(a, b) {
  aa <- colSums(a^2)
  bb <- colSums(b^2)
  #print (max(a))
  #print (max(b))
  ab <- t(a) %*% b

  aa_repmat <- matrix(rep(aa, times = ncol(b)), ncol = ncol(b), byrow = F)
  bb_repmat <- matrix(rep(bb, times = ncol(a)), nrow = ncol(a), byrow = T)
  dist <- abs(aa_repmat + bb_repmat - 2 * ab)
}

#' function to reproduce the behavior of eye function in matlab
#' @param n number of rows in the returned eye matrix
#' @param m number of columns in the returned eye matrix
#' @return a matrix with diagonal element as 1 while other elements as zero (eye matrix)
#' @export
eye <- function(n, m) {
  mat <- matrix(rep(0, n * m), nrow = n)
  diag(mat) <- 1
  return(mat)
}

#' function to reproduce the behavior of repmat function in matlab
#' @param X a matrix
#' @param m a number specifies how many copies are arranged in the first dimension
#' @param n a number specifies how many copies are arranged in the second dimension
#' @return an matrix containing m copies and n copies of A in the row and column dimensions
#' @export
repmat <- function(X,m,n) {
  if (is.matrix(X))
  {
    mx = dim(X)[1]
    nx = dim(X)[2]
    out <- matrix(t(matrix(X,mx,nx*n)),mx*m,nx*n,byrow=T)
  }
  else if (is.vector(X)) {
    mx = 1
    nx = length(X)
    out <- matrix(t(matrix(X,mx,nx*n)),mx*m,nx*n,byrow=T)
  }
  else if (length(X) == 1)
  {
    out <- matrix(X,m, n)
  }
  return (out)
}

#' Learn the principal tree from the same dimension of the noisy data
#' @param X a matrix containing the original noisy data points
#' @param MU a matrix
#' @param lambda
#' @param bandwidth
#' @param maxIter maximal number of iteraction of principal tree algorithm
#' @param verbose a logic flag to determine whether or not running information should be returned
#' @return an list of final MU, stree, param.sigma, lambda and running history
#' @export
principal_tree <- function(X, MU = NULL, lambda = 1, bandwidth = NULL, maxIter = 100, verbose = F) {
    dim_tmp <- dim(X)
    D <- dim_tmp[1]
    N <- dim_tmp[2]

   # initialize MU, lmabda,
   if(is.null(MU)) {
        K = N
        MU = X
    } else {
        K = ncol(MU)
    }

    lambda <- lambda * N #scale the parameter by N

    if(is.null(bandwidth)) {
        distsqX <- sqdist_R(X, X)
        sigma <- 0.01 * sum(sum(distsqX)) / (N^2)
    }
    else
        sigma <- bandwidth

    history <- data.frame(mu = rep(NA, 100), stree = rep(NA, 100), obj = rep(NA, 100))
    for(iter in 1:maxIter) {
        # Kruskal method to find a spanning tree
        distsMU <- sqdist_R(MU, MU)
        gp <- graph.adjacency(distsMU, mode = 'lower', diag = T, weighted = T)
        g_mst <- minimum.spanning.tree(gp)
        stree <- get.adjacency(g_mst, attr = 'weight', type = 'lower')
        stree_ori <- stree
        stree <- as.matrix(stree)
        stree <- stree + t(stree)
        e <- stree != 0

        history$mu[iter] <- MU
        history$mu[iter] <- MU

        # update data assignment matrix
        distMUX <- sqdist_R(MU,X)
        min_dist <- repmat(t(as.matrix(apply(distMUX, 1, min))), K,1)
        tmp_distMUX <- distMUX - min_dist
        tmp_R <- exp(-t(tmp_distMUX) / sigma)
        R <- tmp_R / repmat( t(t(rowSums(tmp_R))), 1, K )

        # compute objective function
        obj1 <- - sigma * sum( log( t(colSums( exp(- tmp_distMUX /sigma)) ) )
            - min_dist[1, ] / sigma )
        reg <- sum(as(stree, 'matrix')) #full
        obj <- (obj1 + 0.5 * lambda * reg)/N
        history$objs[iter] <- obj

        # projected mean square error
        #  mse = sum(sum( R .* distMUX'));
        #  mse = obj1 + sigma *N* log(K);

        projd <- as.matrix(apply(distMUX, 2, min))
        mse <- mean(projd)

        history$mse[iter] <- mse

        # length of the structure
        history$length[iter] <- reg

        # terminate condition
        if(verbose)
            message('iter=', iter, ', obj=', obj, ', mse=',  mse, ', len=', reg)
        if(iter > 1){
            if(abs((obj - old_obj)/old_obj) < 1e-3){
                break
            }
        }

        # compute the means
        L <- diag(colSums(e)) - e
        MU <- X %*% R %*% solve( lambda * L + diag(colSums(R)) )

        old_obj <- obj

    }

    return(list(MU = MU, stree = stree, sigma = sigma, lambda = lambda, history = history))
}
