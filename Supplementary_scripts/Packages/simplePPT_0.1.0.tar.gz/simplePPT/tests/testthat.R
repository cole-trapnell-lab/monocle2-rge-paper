library(testthat)
library(simplePPT)

# test_check("simplePPT")

library(R.matlab)

# params = [];
params.maxIter = 100;

# load data
tree_300 <- R.matlab::readMat('/Users/xqiu/Dropbox (Personal)/bifurcation_path/simplePPT/data/tree_300.mat')
params.lambda = 0.0464; s = 0.05;
X <- tree_300$X
X = t(X);
D = nrow(X); N <- ncol(X)

# % learn the bandwidth of kernel density estimation
# [logp,s] = kde(X',X',s);

params.bandwidth = 2 * s * s;

# #initialized by scms method and maintain the same bandwidth paramter
# pc_projection=pc_project_multidim(X,X,s,1);
# params.MU = pc_projection';

# #gap statistic for parameter selection
# Lambda_opt = gapstats(X, params, 1e-8, 1e2);
# params.lambda = Lambda_opt(1);

# #principal tree method
pt_res <- principal_tree(X, MU = NULL, lambda = params.lambda, bandwidth = params.bandwidth, verbose = T);

# plot the learned principal tree
qplot(X[1, ], X[2, ]) + geom_point(aes( x = pt_res$MU[1, ], y = pt_res$MU[2, ]), color = 'red')
